'use client';

import { useEffect, useRef, useState } from 'react';

interface LazyMapProps {
  src: string;
  title: string;
  height?: number;
}

export default function LazyMap({ src, title, height = 600 }: LazyMapProps) {
  const [loaded, setSrc] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = wrapperRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setSrc(true);
          observer.disconnect();
        }
      },
      { rootMargin: '200px' },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={wrapperRef} className="bg-white rounded-2xl overflow-hidden shadow-xl" style={{ height }}>
      {loaded ? (
        <iframe
          src={src}
          width="100%"
          height={height}
          style={{ border: 0, display: 'block' }}
          allowFullScreen
          referrerPolicy="no-referrer-when-downgrade"
          title={title}
          className="w-full h-full"
        />
      ) : (
        <div className="w-full h-full bg-gray-100 flex items-center justify-center">
          <div className="text-center text-gray-400">
            <svg className="w-10 h-10 mx-auto mb-2 opacity-40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
            </svg>
            <span className="text-sm">Map loading...</span>
          </div>
        </div>
      )}
    </div>
  );
}
