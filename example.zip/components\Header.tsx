'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { AnimatePresence, motion } from 'framer-motion';
import { Menu, X, ChevronDown, Sofa, BedDouble, Refrigerator, Armchair, Trash2 } from 'lucide-react';

const SERVICES = [
  { name: 'Couch Removal', slug: 'couch-removal', icon: Sofa, desc: 'Sofas, sectionals & loveseats' },
  { name: 'Mattress Removal', slug: 'mattress-removal', icon: BedDouble, desc: 'Any size, certified recycling' },
  { name: 'Appliance Removal', slug: 'appliance-removal', icon: Refrigerator, desc: 'Fridges, washers, dryers & more' },
  { name: 'Furniture Removal', slug: 'furniture-removal', icon: Armchair, desc: 'Full rooms & estate clearouts' },
  { name: 'Junk Removal', slug: 'junk-removal', icon: Trash2, desc: 'Garage cleanouts & mixed hauls' },
];

export default function Header() {
  const [isMainMenuOpen, setIsMainMenuOpen] = useState(false);
  const [isStickyMenuOpen, setIsStickyMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isStickyServicesOpen, setIsStickyServicesOpen] = useState(false);
  const [isMobileServicesOpen, setIsMobileServicesOpen] = useState(false);
  const [isStickyMobileServicesOpen, setIsStickyMobileServicesOpen] = useState(false);
  const servicesRef = useRef<HTMLDivElement>(null);
  const stickyServicesRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  const navItems = [
    { name: 'HOME', path: '/' },
    { name: 'HOW IT WORKS', path: '/how-it-works' },
    { name: 'BLOG', path: '/blog' },
    { name: 'CONTACT', path: '/contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
      if (isStickyMenuOpen) setIsStickyMenuOpen(false);
      if (isMainMenuOpen) setIsMainMenuOpen(false);
      setIsServicesOpen(false);
      setIsStickyServicesOpen(false);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isStickyMenuOpen, isMainMenuOpen]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (servicesRef.current && !servicesRef.current.contains(e.target as Node)) {
        setIsServicesOpen(false);
      }
      if (stickyServicesRef.current && !stickyServicesRef.current.contains(e.target as Node)) {
        setIsStickyServicesOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isActivePage = (path: string) => {
    if (path === '/') return pathname === '/';
    return pathname.startsWith(path);
  };

  const ServicesDropdown = ({ sticky = false }: { sticky?: boolean }) => {
    const isOpen = sticky ? isStickyServicesOpen : isServicesOpen;
    const setOpen = sticky ? setIsStickyServicesOpen : setIsServicesOpen;
    const ref = sticky ? stickyServicesRef : servicesRef;
    const isActive = pathname.startsWith('/services');
    const textClass = sticky
      ? isActive ? 'text-blue-700' : 'text-gray-800 hover:text-blue-700'
      : isActive ? 'text-blue-700' : 'text-gray-800 hover:text-blue-700';

    return (
      <div ref={ref} className="relative">
        <button
          onClick={() => setOpen(!isOpen)}
          className={`flex items-center gap-1 font-medium transition-colors duration-200 text-xs uppercase tracking-wide ${textClass}`}
        >
          SERVICES
          <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </button>

        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.97 }}
              transition={{ duration: 0.15 }}
              className="absolute top-full left-1/2 -translate-x-1/2 mt-3 w-72 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-[200]"
            >
              <div className="p-2">
                {SERVICES.map((service) => {
                  const Icon = service.icon;
                  return (
                    <Link
                      key={service.slug}
                      href={`/services/${service.slug}`}
                      onClick={() => setOpen(false)}
                      className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors group"
                    >
                      <div className="w-9 h-9 bg-green-600 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:bg-green-700 transition-colors">
                        <Icon className="h-4 w-4 text-white transition-colors" />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900 text-sm group-hover:text-green-700 transition-colors">
                          {service.name}
                        </div>
                        <div className="text-gray-500 text-xs">{service.desc}</div>
                      </div>
                    </Link>
                  );
                })}
                <div className="border-t border-gray-100 mt-2 pt-2 px-1">
                  <Link
                    href="/services"
                    onClick={() => setOpen(false)}
                    className="block text-center text-sm font-semibold text-green-600 hover:text-green-700 py-2 transition-colors"
                  >
                    View All Services →
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  const MobileServicesSection = ({ onClose, inSticky = false }: { onClose: () => void; inSticky?: boolean }) => {
    const isOpen = inSticky ? isStickyMobileServicesOpen : isMobileServicesOpen;
    const setOpen = inSticky ? setIsStickyMobileServicesOpen : setIsMobileServicesOpen;
    const isActive = pathname.startsWith('/services');
    const textClass = inSticky
      ? isActive ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700'
      : isActive ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700';

    return (
      <div>
        <button
          onClick={() => setOpen(!isOpen)}
          className={`flex items-center justify-between w-full text-left font-medium transition-colors duration-200 text-xs uppercase tracking-wide p-3 min-h-[44px] ${textClass}`}
        >
          SERVICES
          <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </button>

        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="pl-4 pb-2 space-y-1">
                {SERVICES.map((service) => {
                  const Icon = service.icon;
                  return (
                    <Link
                      key={service.slug}
                      href={`/services/${service.slug}`}
                      onClick={onClose}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <div className="w-7 h-7 bg-green-600 rounded-md flex items-center justify-center flex-shrink-0">
                        <Icon className="h-3.5 w-3.5 text-white" />
                      </div>
                      <span className="text-gray-700 text-xs font-medium">{service.name}</span>
                    </Link>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  return (
    <>
      <div className="py-6 bg-gray-50 w-full relative z-50">
        <div className="w-[95%] sm:w-[90%] max-w-7xl mx-auto bg-gray-200 rounded-full shadow-2xl relative z-50">
          <div className="flex justify-between items-center px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center space-x-2">
              <Link href="/" className="flex items-center space-x-2 hover:opacity-90 transition-opacity">
                <Image
                  src="/images/Full_Logo.webp"
                  alt="Junk Removals 365"
                  width={160}
                  height={40}
                  className="h-10 w-auto object-contain"
                  priority
                />
              </Link>
            </div>

            <div className="hidden lg:flex items-center space-x-6">
              <Link
                href="/"
                className={`font-medium transition-colors duration-200 text-xs uppercase tracking-wide ${
                  isActivePage('/') ? 'text-blue-700' : 'text-gray-800 hover:text-blue-700'
                }`}
              >
                HOME
              </Link>
              <ServicesDropdown />
              {navItems.filter((item) => item.path !== '/').map((item) => (
                <Link
                  key={item.name}
                  href={item.path}
                  className={`font-medium transition-colors duration-200 text-xs uppercase tracking-wide ${
                    isActivePage(item.path)
                      ? 'text-blue-700'
                      : 'text-gray-800 hover:text-blue-700'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
              <Link
                href="/book"
                className="bg-blue-500 text-white px-6 py-2 rounded-full font-semibold text-sm hover:bg-blue-600 active:scale-95 transition-all duration-200"
              >
                BOOK ONLINE
              </Link>
            </div>

            <div className="lg:hidden">
              <button
                onClick={() => setIsMainMenuOpen(!isMainMenuOpen)}
                className="text-gray-600 hover:text-blue-600 transition-colors duration-200 p-2 min-w-[44px] min-h-[44px] flex items-center justify-center"
                aria-label="Toggle menu"
              >
                {isMainMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>

          <AnimatePresence>
            {isMainMenuOpen && (
              <motion.div
                className="lg:hidden bg-gray-300 rounded-b-3xl border-t border-gray-400 absolute top-full left-0 right-0 z-[100]"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="px-6 py-6 space-y-1">
                  <Link
                    href="/"
                    onClick={() => setIsMainMenuOpen(false)}
                    className={`block w-full text-left font-medium transition-colors duration-200 text-xs uppercase tracking-wide p-3 min-h-[44px] ${
                      isActivePage('/') ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700'
                    }`}
                  >
                    HOME
                  </Link>
                  <MobileServicesSection onClose={() => setIsMainMenuOpen(false)} />
                  {navItems.filter((item) => item.path !== '/').map((item) => (
                    <Link
                      key={item.name}
                      href={item.path}
                      onClick={() => setIsMainMenuOpen(false)}
                      className={`block w-full text-left font-medium transition-colors duration-200 text-xs uppercase tracking-wide p-3 min-h-[44px] ${
                        isActivePage(item.path)
                          ? 'text-blue-700'
                          : 'text-gray-700 hover:text-blue-700'
                      }`}
                    >
                      {item.name}
                    </Link>
                  ))}
                  <div className="pt-4 border-t border-gray-400">
                    <Link
                      href="/book"
                      onClick={() => setIsMainMenuOpen(false)}
                      className="block w-full bg-blue-500 text-white px-6 py-3 rounded-full font-semibold hover:bg-blue-600 transition-colors duration-200 min-h-[44px] text-center"
                    >
                      BOOK ONLINE
                    </Link>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div
        className={`fixed top-0 left-0 right-0 z-50 transition-transform duration-300 ${
          isScrolled ? 'translate-y-0' : '-translate-y-full'
        }`}
      >
        <div className="bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-lg">
          <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-2">
                <Link href="/" className="flex items-center space-x-2 hover:opacity-90 transition-opacity">
                  <Image
                    src="/images/Full_Logo.webp"
                    alt="Junk Removals 365"
                    width={160}
                    height={40}
                    className="h-10 w-auto object-contain"
                  />
                </Link>
              </div>

              <div className="hidden lg:flex items-center space-x-6">
                <Link
                  href="/"
                  className={`font-medium transition-colors duration-200 text-xs uppercase tracking-wide ${
                    isActivePage('/') ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700'
                  }`}
                >
                  HOME
                </Link>
                <ServicesDropdown sticky />
                {navItems.filter((item) => item.path !== '/').map((item) => (
                  <Link
                    key={item.name}
                    href={item.path}
                    className={`font-medium transition-colors duration-200 text-xs uppercase tracking-wide ${
                      isActivePage(item.path)
                        ? 'text-blue-700'
                        : 'text-gray-700 hover:text-blue-700'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>

              <div className="hidden lg:flex items-center space-x-4">
                <Link
                  href="/book"
                  className="bg-blue-500 text-white px-6 py-2 rounded-full font-semibold text-sm hover:bg-blue-600 active:scale-95 transition-all duration-200"
                >
                  BOOK ONLINE
                </Link>
              </div>

              <div className="lg:hidden">
                <button
                  onClick={() => setIsStickyMenuOpen(!isStickyMenuOpen)}
                  className="text-gray-600 hover:text-blue-600 transition-colors duration-200 p-2 min-w-[44px] min-h-[44px] flex items-center justify-center"
                  aria-label="Toggle menu"
                >
                  {isStickyMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {isStickyMenuOpen && (
            <motion.div
              className="lg:hidden bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-lg z-[100]"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="px-4 py-6 space-y-1">
                <Link
                  href="/"
                  onClick={() => setIsStickyMenuOpen(false)}
                  className={`block w-full text-left font-medium transition-colors duration-200 text-xs uppercase tracking-wide p-3 min-h-[44px] ${
                    isActivePage('/') ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700'
                  }`}
                >
                  HOME
                </Link>
                <MobileServicesSection onClose={() => setIsStickyMenuOpen(false)} inSticky />
                {navItems.filter((item) => item.path !== '/').map((item) => (
                  <Link
                    key={item.name}
                    href={item.path}
                    onClick={() => setIsStickyMenuOpen(false)}
                    className={`block w-full text-left font-medium transition-colors duration-200 text-xs uppercase tracking-wide p-3 min-h-[44px] ${
                      isActivePage(item.path)
                        ? 'text-blue-700'
                        : 'text-gray-700 hover:text-blue-700'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
                <div className="pt-4 border-t border-gray-400">
                  <Link
                    href="/book"
                    onClick={() => setIsStickyMenuOpen(false)}
                    className="block w-full bg-blue-500 text-white px-6 py-3 rounded-full font-semibold hover:bg-blue-600 transition-colors duration-200 min-h-[44px] text-center"
                  >
                    BOOK ONLINE
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}
