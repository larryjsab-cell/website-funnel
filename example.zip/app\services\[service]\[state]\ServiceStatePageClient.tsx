'use client';

import { useState, useMemo } from 'react';
import Link from 'next/link';
import { MapPin, Search, ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface City {
  city_name: string;
  city_slug: string;
}

interface TopCity {
  name: string;
  slug: string;
}

interface FAQ {
  question: string;
  answer: string;
}

interface ServiceStatePageClientProps {
  cities: City[];
  topCities: TopCity[];
  stateSlug: string;
  stateName: string;
  serviceSlug: string;
  serviceName: string;
  faqs: FAQ[];
  accentText: string;
  accentBg: string;
}

const CITIES_PER_PAGE = 50;

export default function ServiceStatePageClient({
  cities,
  topCities,
  stateSlug,
  stateName,
  serviceSlug,
  serviceName,
  faqs,
  accentText,
  accentBg,
}: ServiceStatePageClientProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const filteredCities = useMemo(() => {
    if (!searchQuery.trim()) return cities;
    const query = searchQuery.toLowerCase();
    return cities.filter((city) => city.city_name.toLowerCase().includes(query));
  }, [cities, searchQuery]);

  const totalPages = Math.ceil(filteredCities.length / CITIES_PER_PAGE);
  const startIndex = (currentPage - 1) * CITIES_PER_PAGE;
  const currentCities = filteredCities.slice(startIndex, startIndex + CITIES_PER_PAGE);

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const maxVisible = 7;
    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else if (currentPage <= 4) {
      for (let i = 1; i <= 5; i++) pages.push(i);
      pages.push('...');
      pages.push(totalPages);
    } else if (currentPage >= totalPages - 3) {
      pages.push(1);
      pages.push('...');
      for (let i = totalPages - 4; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      pages.push('...');
      for (let i = currentPage - 1; i <= currentPage + 1; i++) pages.push(i);
      pages.push('...');
      pages.push(totalPages);
    }
    return pages;
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Top Cities Section */}
      {topCities.length > 0 && (
        <section className="py-14 bg-gray-50 border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="text-center mb-10">
              <p className={`text-sm font-semibold uppercase tracking-widest ${accentText} mb-2`}>
                Popular Locations
              </p>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                Top Cities for {serviceName} in {stateName}
              </h2>
              <p className="text-gray-500 text-lg max-w-2xl mx-auto">
                Fast, professional service in {stateName}&apos;s largest cities — same-day availability in most areas.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {topCities.map((city, index) => (
                <Link
                  key={city.slug}
                  href={`/services/${serviceSlug}/${stateSlug}/${city.slug}`}
                  className="group relative bg-white rounded-2xl border border-gray-200 hover:border-gray-300 hover:shadow-lg transition-all duration-300 p-6 flex flex-col items-center text-center overflow-hidden"
                >
                  <div className={`absolute top-0 left-0 right-0 h-1 ${accentBg} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
                  <div className={`w-12 h-12 rounded-xl ${accentBg} bg-opacity-10 flex items-center justify-center mb-4`}>
                    <MapPin className={`h-6 w-6 ${accentText}`} />
                  </div>
                  <span className="text-sm font-bold text-gray-500 mb-1">#{index + 1}</span>
                  <h3 className={`font-bold text-gray-900 group-hover:${accentText} transition-colors duration-200 text-base leading-snug`}>
                    {city.name}
                  </h3>
                  <p className="text-xs text-gray-400 mt-1">{stateName}</p>
                  <div className="mt-3 flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-3 w-3 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <span className={`mt-3 text-xs font-semibold ${accentText} opacity-0 group-hover:opacity-100 transition-opacity duration-200`}>
                    View Service &rarr;
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Cities Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="mb-8">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4 text-center">
              {serviceName} in {stateName} — Cities We Serve
            </h2>
            <p className="text-lg text-gray-600 text-center mb-8">
              Professional {serviceName.toLowerCase()} services in over {cities.length} locations
            </p>

            <div className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search for your city..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="pl-12 py-6 text-lg border-2 rounded-xl focus:border-green-500"
                />
              </div>
            </div>

            {filteredCities.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-600 text-lg">
                  No cities found matching &ldquo;{searchQuery}&rdquo;. Try a different search term.
                </p>
              </div>
            ) : (
              <>
                <div className="text-center mb-6 text-sm text-gray-600">
                  Showing {startIndex + 1}–{Math.min(startIndex + CITIES_PER_PAGE, filteredCities.length)} of {filteredCities.length} cities
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                  {currentCities.map((city) => (
                    <Link
                      key={city.city_slug}
                      href={`/services/${serviceSlug}/${stateSlug}/${city.city_slug}`}
                    >
                      <div className={`p-4 bg-gray-50 hover:bg-green-50 rounded-lg transition-all duration-300 group cursor-pointer border border-gray-200 hover:border-green-500 h-full`}>
                        <div className="flex items-center gap-3">
                          <MapPin className={`h-5 w-5 ${accentText} flex-shrink-0`} />
                          <h3 className={`font-semibold text-gray-800 group-hover:${accentText} transition-colors duration-300 truncate text-sm`}>
                            {city.city_name}
                          </h3>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>

                {totalPages > 1 && (
                  <div className="mt-8 flex items-center justify-center gap-2">
                    <button
                      onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                      className="p-2 rounded-lg border border-gray-300 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      aria-label="Previous page"
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </button>

                    {getPageNumbers().map((page, index) =>
                      page === '...' ? (
                        <span key={`ellipsis-${index}`} className="px-3 py-2 text-gray-500">...</span>
                      ) : (
                        <button
                          key={page}
                          onClick={() => handlePageChange(page as number)}
                          className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                            currentPage === page
                              ? 'bg-blue-600 text-white'
                              : 'border border-gray-300 hover:bg-gray-100 text-gray-700'
                          }`}
                        >
                          {page}
                        </button>
                      )
                    )}

                    <button
                      onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages}
                      className="p-2 rounded-lg border border-gray-300 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      aria-label="Next page"
                    >
                      <ChevronRight className="h-5 w-5" />
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </section>

      {/* FAQ */}
      {faqs.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                {stateName} {serviceName} FAQ
              </h2>
              <p className="text-lg text-gray-600">
                Common questions about {serviceName.toLowerCase()} in {stateName}
              </p>
            </div>
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div key={index} className="bg-white p-6 rounded-xl border border-gray-200 hover:shadow-md transition-shadow">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{faq.question}</h3>
                  <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
