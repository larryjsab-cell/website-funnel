export function isBlank(value: any): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string' && value.trim() === '') return true;
  if (Array.isArray(value) && value.length === 0) return true;
  return false;
}

export function templateIntro(city: string, state: string, service: string | null): string {
  const serviceMap: Record<string, string> = {
    'junk-removal': 'junk removal',
    'couch-removal': 'couch removal',
    'furniture-removal': 'furniture removal',
  };

  const serviceName = service && serviceMap[service] ? serviceMap[service] : (service ? service.replace(/-/g, ' ') : 'couch removal');

  return `Welcome to ${city}, ${state}'s premier ${serviceName} service. We provide fast, affordable, and eco-friendly ${serviceName} solutions for homes and businesses throughout the ${city} area.`;
}

export function templateCityContext(city: string, state: string): string {
  return `${city}, ${state} is a vibrant community that values sustainability and cleanliness. Our team understands the unique needs of ${city} residents and businesses, providing tailored solutions that work for your schedule and budget.`;
}

export function templatePricingFactors(city: string, state: string, service: string | null): string[] {
  return [
    'Volume and weight of items',
    'Location and accessibility',
    'Type of materials being removed',
    'Labor required for removal',
    'Disposal and recycling fees',
  ];
}

export function templateServiceIncludes(service: string | null): string[] {
  const baseServices = [
    'Free on-site estimates',
    'Professional loading and hauling',
    'Responsible disposal and recycling',
    'Same-day service available',
    'Clean-up after removal',
  ];

  if (service === 'couch-removal' || !service) {
    return [
      ...baseServices,
      'All types of sofas and sectionals',
      'Sleeper sofas and futons',
      'Loveseats and recliners',
    ];
  }

  return baseServices;
}

export function templateLocalRules(city: string, state: string): string {
  return `We comply with all ${city} and ${state} waste disposal regulations. Our team is licensed and insured, ensuring your items are disposed of properly and in accordance with local environmental standards.`;
}

export function templateNearbyCities(city: string, state: string): string[] {
  return [];
}

export function templateLandmarks(city: string, state: string): string[] {
  return [];
}

export interface FAQ {
  question: string;
  answer: string;
}

export function templateFaqs(city: string, state: string, service: string | null): FAQ[] {
  const serviceMap: Record<string, string> = {
    'junk-removal': 'junk removal',
    'couch-removal': 'couch removal',
    'furniture-removal': 'furniture removal',
  };

  const serviceName = service && serviceMap[service] ? serviceMap[service] : (service ? service.replace(/-/g, ' ') : 'couch removal');

  return [
    {
      question: `How much does ${serviceName} cost in ${city}?`,
      answer: `Pricing varies based on volume, weight, and type of items. We offer free estimates and competitive rates for all ${serviceName} services in ${city}, ${state}.`,
    },
    {
      question: 'Do you offer same-day service?',
      answer: `Yes! We offer same-day ${serviceName} service in ${city} when you book early. Contact us to check availability.`,
    },
    {
      question: 'What items can you remove?',
      answer: `We remove most household and commercial items including furniture, appliances, electronics, yard waste, and general junk. Some hazardous materials may require special handling.`,
    },
    {
      question: 'Are you licensed and insured?',
      answer: `Yes, we are fully licensed and insured to operate in ${city}, ${state}. Your property and our team are protected throughout the removal process.`,
    },
    {
      question: 'Do you recycle or donate items?',
      answer: `Absolutely! We prioritize recycling and donation whenever possible. Many items are diverted from landfills and given new life through local charities and recycling centers in ${city}.`,
    },
  ];
}
