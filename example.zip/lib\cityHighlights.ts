// Extra hand-written content for high-volume city pages (keyed by `${stateSlug}/${citySlug}`).
export interface CityHighlight {
  areas: string[];
  paragraphs: string[];
  faqs: { question: string; answer: string }[];
}

export const CITY_HIGHLIGHTS: Record<string, CityHighlight> = {
  'texas/houston': {
    areas: ['Downtown', 'Midtown', 'The Heights', 'Montrose', 'River Oaks', 'Bellaire', 'Katy', 'Sugar Land', 'Pearland', 'The Woodlands', 'Spring', 'Pasadena'],
    paragraphs: [
      'Houston is spread out, with single-family homes, garden apartments, and high-rise condos across Harris County and the suburbs. We pick up from all of them, from a single couch in a Midtown apartment to a full garage cleanout in Katy or Pearland.',
      'Common Houston jobs include clearing out furniture before a move, hauling storm-damaged items after heavy rain, and removing old appliances after a remodel. Tell us what you have and we give you an upfront price before we start.',
    ],
    faqs: [
      { question: 'Do you pick up junk across the Houston suburbs?', answer: 'Yes. We serve Houston and surrounding communities such as Katy, Sugar Land, Pearland, The Woodlands, Spring, and Pasadena. Book online to see pickup times for your address.' },
      { question: 'Can you remove items from a Houston apartment or high-rise?', answer: 'Yes. Our crew handles stairs, elevators, and loading docks. Let us know about building rules, such as elevator reservations, when you book.' },
    ],
  },
  'california/los-angeles': {
    areas: ['Downtown LA', 'Hollywood', 'Silver Lake', 'Echo Park', 'Koreatown', 'Westwood', 'Santa Monica', 'Venice', 'Culver City', 'Pasadena', 'Burbank', 'the San Fernando Valley'],
    paragraphs: [
      'Los Angeles has everything from hillside homes with long stairways to apartment buildings with tight parking. Our crews plan for access, so getting a sectional out of a Silver Lake walk-up or a refrigerator out of a Valley garage is no problem.',
      'We remove furniture, mattresses, appliances, and mixed household junk across Los Angeles, and we donate or recycle what we can. You get an upfront quote before any work begins.',
    ],
    faqs: [
      { question: 'Do you serve all of Los Angeles?', answer: 'We serve the city of Los Angeles and nearby areas such as Santa Monica, Culver City, Pasadena, Burbank, and the San Fernando Valley. Book online to see available pickup times for your address.' },
      { question: 'Can you handle stairs and limited parking in LA?', answer: 'Yes. Tell us about stairs, long carries, or parking limits when you book so we can plan the crew and truck for your job.' },
    ],
  },
  'new-york/new-york-city': {
    areas: ['Manhattan', 'Brooklyn', 'Queens', 'The Bronx', 'Staten Island', 'Harlem', 'Upper West Side', 'Upper East Side', 'Williamsburg', 'Park Slope', 'Astoria', 'Long Island City'],
    paragraphs: [
      'Junk removal in New York City means walk-ups, narrow hallways, elevators, and building rules. Our crews carry items down from any floor, so you do not have to drag a couch or mattress to the curb yourself.',
      'We remove furniture, mattresses, appliances, and full apartment cleanouts across all five boroughs. Share your building details, such as elevator booking or a certificate of insurance, when you book.',
    ],
    faqs: [
      { question: 'Do you offer junk removal in all five NYC boroughs?', answer: 'Yes. We serve Manhattan, Brooklyn, Queens, the Bronx, and Staten Island. Book online to see pickup times for your address.' },
      { question: 'Can you remove items from a walk-up apartment?', answer: 'Yes. We carry items down stairs from any floor. Let us know how many flights there are when you book so your quote is accurate.' },
    ],
  },
  'oregon/salem': {
    areas: ['Downtown Salem', 'West Salem', 'South Salem', 'Northeast Salem', 'Keizer', 'Four Corners', 'Turner', 'Independence', 'Monmouth'],
    paragraphs: [
      'We provide junk removal in Salem, Oregon, and the surrounding Willamette Valley, including Keizer, Independence, and Monmouth. Common jobs include garage and shed cleanouts, old furniture and mattresses, and appliances replaced during a remodel.',
      'Our crew does all the lifting and loading, then donates or recycles what we can. You get a clear, upfront price before any work begins.',
    ],
    faqs: [
      { question: 'Do you serve Keizer and other towns near Salem, Oregon?', answer: 'Yes. We serve Salem and nearby communities such as Keizer, Turner, Independence, and Monmouth. Book online to see pickup times for your address.' },
      { question: 'Can you clear out a garage or shed in Salem?', answer: 'Yes. We handle full garage, shed, and basement cleanouts, including mixed loads you have not sorted.' },
    ],
  },
  'california/fresno': {
    areas: ['Downtown Fresno', 'Tower District', 'Fig Garden', 'Woodward Park', 'Sunnyside', 'Clovis', 'Sanger', 'Kerman', 'Selma'],
    paragraphs: [
      'We offer junk removal in Fresno and nearby Central Valley communities such as Clovis. We remove furniture, mattresses, appliances, yard waste, and mixed household junk from homes, rentals, and businesses.',
      'Our crew handles all the lifting and loading, and usable items are donated whenever possible. You get an upfront quote before we start.',
    ],
    faqs: [
      { question: 'Do you offer junk removal in Clovis as well as Fresno?', answer: 'Yes. We serve Fresno, Clovis, and nearby towns. Book online to see pickup times for your address.' },
      { question: 'Can you remove yard waste in Fresno?', answer: 'Yes. We haul branches, brush, and other yard debris along with household junk in the same pickup.' },
    ],
  },
};

export function getCityHighlight(stateSlug: string, citySlug: string): CityHighlight | null {
  return CITY_HIGHLIGHTS[`${stateSlug}/${citySlug}`] ?? null;
}
