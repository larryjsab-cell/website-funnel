'use client';

import { useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import { Mail, Facebook, Twitter, Instagram, Linkedin, ArrowRight, Loader as Loader2 } from 'lucide-react';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

const NewsletterForm = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setStatus('loading');

    const { error } = await supabase
      .from('newsletter_subscribers')
      .insert([{ email }]);

    setStatus(error && error.code !== '23505' ? 'error' : 'success');
  };

  if (status === 'success') {
    return (
      <p className="text-green-400 text-sm font-medium py-3">
        You&apos;re subscribed! Thanks for joining.
      </p>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <div className="flex gap-2">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Your email address"
          className="flex-1 min-w-0 px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <button
          type="submit"
          disabled={status === 'loading'}
          className="flex-shrink-0 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white px-3 py-2.5 rounded-lg transition-colors flex items-center justify-center"
          aria-label="Subscribe"
        >
          {status === 'loading' ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <ArrowRight className="h-4 w-4" />
          )}
        </button>
      </div>
      {status === 'error' && (
        <p className="text-red-400 text-xs">Something went wrong. Try again.</p>
      )}
    </form>
  );
};

// Converts e.g. "New York City" -> "new-york-city"
const slugify = (value: string) =>
  value
    .toLowerCase()
    .trim()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

const cityHref = (state: string, city: string) => `/services/couch-removal/${slugify(state)}/${slugify(city)}`;

export default function Footer() {
  const quickLinks = [
    { name: 'Home', href: '/' },
    { name: 'How It Works', href: '/how-it-works' },
    { name: 'Services', href: '/services' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact Us', href: '/contact' },
    { name: 'Book Online', href: '/book' }
  ];

  // All service links -> /book
  const services = [
    { name: 'Residential Couch Removal', href: '/book' },
    { name: 'Commercial Furniture Disposal', href: '/book' },
    { name: 'Same Day Service', href: '/book' },
    { name: 'Eco-Friendly Disposal', href: '/book' },
    { name: 'Donation Coordination', href: '/book' },
    { name: 'Free Estimates', href: '/book' }
  ];

  // Update these to match your real city pages (/locations/[state]/[city])
  const popularCities = [
    { name: 'New York City Couch Removal', state: 'New York', city: 'New York City' },
    { name: 'Los Angeles Furniture Disposal', state: 'California', city: 'Los Angeles' },
    { name: 'Chicago Couch Pickup', state: 'Illinois', city: 'Chicago' },
    { name: 'Houston Same Day Service', state: 'Texas', city: 'Houston' },
    { name: 'Phoenix Professional Removal', state: 'Arizona', city: 'Phoenix' },
    { name: 'Philadelphia Eco Disposal', state: 'Pennsylvania', city: 'Philadelphia' }
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' }
  ];

  return (
    <footer className="bg-gray-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-green-500/5 rounded-full blur-2xl" />
        <div className="absolute top-1/2 -right-20 w-64 h-96 bg-yellow-500/5 rounded-full blur-3xl transform -translate-y-1/2 rotate-12" />
      </div>

      <div className="relative z-10">
        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12">
            <motion.div
              className="lg:col-span-1"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="mb-6">
                <Image
                  src="/images/full_logo_white_BG.png"
                  alt="Junk Removals 365"
                  width={192}
                  height={48}
                  className="h-12 w-auto object-contain"
                />
              </div>

              <p className="text-gray-400 mb-6 leading-relaxed">
                Professional junk removal and disposal services across the United States. We handle unwanted items responsibly with eco-friendly solutions.
              </p>

              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-blue-400" />
                  <span className="text-gray-300">support@junkremovals365.com</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold mb-6">Quick Links</h3>
              <ul className="space-y-3">
                {quickLinks.map((link, index) => (
                  <motion.li key={index} whileHover={{ x: 5 }} transition={{ duration: 0.2 }}>
                    <Link
                      href={link.href}
                      className="text-gray-400 hover:text-white transition-colors duration-200 flex items-center group"
                    >
                      <ArrowRight className="h-3 w-3 mr-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                      {link.name}
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold mb-6">Our Services</h3>
              <ul className="space-y-3">
                {services.map((service, index) => (
                  <motion.li key={index} whileHover={{ x: 5 }} transition={{ duration: 0.2 }}>
                    <Link
                      href={service.href}
                      className="text-gray-400 hover:text-white transition-colors duration-200 flex items-center group"
                    >
                      <ArrowRight className="h-3 w-3 mr-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                      {service.name}
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold mb-6">Popular Cities</h3>
              <ul className="space-y-3">
                {popularCities.map((cityItem, index) => (
                  <motion.li key={index} whileHover={{ x: 5 }} transition={{ duration: 0.2 }}>
                    <Link
                      href={cityHref(cityItem.state, cityItem.city)}
                      className="text-gray-400 hover:text-white transition-colors duration-200 flex items-center group text-sm"
                      title={`Professional couch removal services in ${cityItem.city}, ${cityItem.state}`}
                    >
                      <ArrowRight className="h-3 w-3 mr-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                      {cityItem.name}
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold mb-6">Stay Connected</h3>

              <div className="mb-6">
                <p className="text-gray-400 mb-4">Subscribe to get updates on our latest services and tips.</p>
                <NewsletterForm />
              </div>

              <div>
                <p className="text-gray-400 mb-4">Follow us on social media</p>
                <div className="flex space-x-4">
                  {socialLinks.map((social, index) => (
                    <motion.a
                      key={index}
                      href={social.href}
                      className="bg-gray-800 p-3 rounded-lg hover:bg-blue-500 transition-colors duration-200 group min-w-[44px] min-h-[44px] flex items-center justify-center"
                      whileHover={{ scale: 1.1, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      aria-label={`Follow Junk Removals 365 on ${social.label}`}
                    >
                      <social.icon
                        className="h-4 w-4 text-gray-400 group-hover:text-white transition-colors duration-200"
                        aria-hidden="true"
                      />
                    </motion.a>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        <div className="border-t border-gray-800">
          <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <motion.div
                className="text-gray-400 text-sm"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
              >
                <p>© 2025 Junk Removals 365. All rights reserved.</p>
                <p className="mt-1 text-gray-500">
                  Website by{' '}
                  <a
                    href="https://ryzonautomationllc.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-300 hover:text-white underline underline-offset-2 transition-colors duration-200"
                  >
                    Ryzon Automation
                  </a>
                </p>
              </motion.div>

              <motion.div
                className="flex space-x-6 text-sm"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <Link
                  href="/privacy"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                  aria-label="Read our privacy policy"
                >
                  Privacy Policy
                </Link>
                <Link
                  href="/terms"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                  aria-label="Read our terms of service"
                >
                  Terms of Service
                </Link>
                <Link
                  href="/cookies"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                  aria-label="Read our cookie policy"
                >
                  Cookie Policy
                </Link>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
