# City Content Progress

The log of finished cities is `city_log.csv`. **Never redo a city that is in the log.** Every script skips logged cities.

## Status (2026-11-18)

| State | Cities done | Checked facts | Basic tier | Pages |
|---|---|---|---|---|
| Michigan | 1081 | 749 | 332 | 5,405 |
| Indiana | 526 | 490 | 36 | 2,630 |
| Ohio | 717 | 681 | 36 | 3,585 |
| Illinois | 767 | 733 | 34 | 3,835 |
| Wisconsin | 496 | 458 | 38 | 2,480 |
| Iowa | 289 | 279 | 10 | 1,445 |
| Minnesota | 395 | 363 | 32 | 1,975 |
| Pennsylvania | 1148 | 1067 | 81 | 5,740 |
| Missouri | 392 | 376 | 16 | 1,960 |
| Georgia | 405 | 373 | 32 | 2,025 |
| New Jersey | 663 | 627 | 36 | 3,315 |
| North Carolina | 661 | 647 | 14 | 3,305 |
| South Carolina | 260 | 254 | 6 | 1,300 |
| West Virginia | 186 | 173 | 13 | 930 |
| New Hampshire | 171 | 169 | 2 | 855 |
| New Mexico | 152 | 142 | 10 | 760 |
| South Dakota | 77 | 77 | 0 | 385 |
| North Dakota | 58 | 56 | 2 | 290 |
| Rhode Island | 55 | 52 | 3 | 275 |
| Connecticut | 379 | 345 | 34 | 1,895 |
| Virginia | 378 | 357 | 21 | 1,890 |
| Massachusetts | 514 | 490 | 24 | 2,570 |
| New York | 1407 | 1218 | 189 | 7,035 |
| Delaware | 57 | 57 | 0 | 285 |
| Vermont | 142 | 129 | 13 | 710 |
| Maryland | 368 | 355 | 13 | 1,840 |
| Wyoming | 60 | 60 | 0 | 300 |
| Nevada | 74 | 74 | 0 | 370 |
| Idaho | 94 | 94 | 0 | 470 |
| Nebraska | 123 | 123 | 0 | 615 |
| Maine | 263 | 263 | 0 | 1,315 |
| Alaska | 69 | 69 | 0 | 345 |
| Utah | 194 | 179 | 15 | 970 |
| Kansas | 203 | 203 | 0 | 1,015 |
| Mississippi | 205 | 205 | 0 | 1,025 |
| Arkansas | 226 | 226 | 0 | 1,130 |
| Oklahoma | 244 | 244 | 0 | 1,220 |
| Louisiana | 300 | 282 | 18 | 1,500 |
| Kentucky | 298 | 252 | 46 | 1,490 |
| Tennessee | 324 | 324 | 0 | 1,620 |
| Alabama | 339 | 339 | 0 | 1,695 |
| Colorado | 302 | 290 | 12 | 1,510 |
| Arizona | 232 | 232 | 0 | 1,160 |
| Oregon | 237 | 223 | 14 | 1,185 |
| **Total** | **15531** | **14399** | **1132** | **77,655 of 96,140** |

All states are done: 96,140 of 96,140 pages (19,228 cities) are custom as of 2026-11-19. HI and MT were hand-researched for notable cities, with the basic tier for the rest, because Overpass kept failing.

Michigan tiers (see the `batch` column in the log):
- **Researched tier** (307 cities, batches `michigan_batch1.json`, `mi_b2`–`mi_b4`): county, real roads, real landmarks, housing type, typical jobs, and nearby towns.
- **Census + OpenStreetMap tier** (268 small towns, batch `mi_researched_census_osm`): real county and township from the US Census geocoder, plus nearby lakes, rivers, parks and highways from OpenStreetMap. Only towns whose name matches the Census place or township at their coordinates are included (`research_bulk.py`, then `research_to_sql.py`).
- **Basic tier** (506 small communities, batch `mi_basic_tier`; these are not official Census places, so their facts can't be checked): mentions only the nearest researched city and nearby towns, computed from coordinates. It names no county and no landmarks, so it cannot be wrong about them. **This tier can be upgraded later** with researched facts.

## Fastest way to do a new state

`python state_pipeline.py <state_slug> <State Name> <ABBR> <workdir>` (add the state's ISO code to `FIPS_ISO` first). It pulls coordinates, does Census + OpenStreetMap research, and writes upload SQL plus verified/basic slug lists. Upload the `*_v_N.sql` files, then the basic SQL, then log both lists with `log_done.py`.

## How a batch is run (manual, researched by hand)

1. Write the facts as rows `(slug, county, area, roads, 'landmark|landmark', homes, typical jobs)`.
2. Paste the rows into `template_v2.sql` at `/*VALUES*/` and run it on Supabase. It fills all 5 services and computes nearby towns from coordinates.
3. Log the batch: `python log_done.py <state_slug> <batch_name> slug1,slug2,...`

Wording: 12 opening lines, 2 context paragraphs, and FAQ order shuffled per page (chosen by hash of city + service).

## Check remaining in Supabase
```sql
select state_slug, count(distinct city_slug) filter (where seo_status='template') cities_left
from city_pages group by 1 order by 2 desc;
```

## Known data problems
- Some `city_pages` rows have coordinates of a different town with the same name (Pennsylvania: philadelphia pointed at New Philadelphia, york at East York, media at Almedia). The verification step catches these and sends them to the basic tier. Big cities caught this way should be hand-written (see batch `pa_hand_researched`).
- Supabase REST returns at most 1000 rows per call. `state_pipeline.py` now pages through, so states with more than 1000 cities are fully covered.

## Next
- Pick the next state. Run the researched tier for its larger cities first, then the basic tier.
- Spaced state slugs ("new york", 14,760 rows) held 4 services while the dashed slug held couch-removal. All were renamed to the dashed slug (no collisions), so each state now has all 5 services under one dashed slug. Pages query the dashed slug only, and `middleware.ts` 301-redirects spaced URLs.

## Indexing (2026-11-19)
- The sitemap is now an index at `/sitemap.xml`, pointing to `/sitemaps/{main,junk-removal,couch-removal,mattress-removal,appliance-removal,furniture-removal}.xml`. There are 96,462 URLs; before this change, Supabase's 1000-row cap meant the sitemap only listed 1,322.
- IndexNow key: `public/cfa6ba280f1c4e25bffa99d94f71291e.txt`. A single-URL GET to Bing returned 202. Bulk POSTs (10k per batch) returned 403 because the key is new. Retry bulk submission later.
