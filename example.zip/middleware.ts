import { NextResponse, type NextRequest } from 'next/server';

// Old state URLs used spaces ("/services/x/new%20york/..."). Send them to the dashed slug.
export function middleware(req: NextRequest) {
  const path = decodeURIComponent(req.nextUrl.pathname);
  if (!path.includes(' ')) return NextResponse.next();
  const url = req.nextUrl.clone();
  url.pathname = path.replace(/ +/g, '-').toLowerCase();
  return NextResponse.redirect(url, 301);
}

export const config = { matcher: '/services/:path*' };
