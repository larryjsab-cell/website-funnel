"""Turn research.py output into template_v2 SQL batches (all 5 services per city).

Usage: python research_to_sql.py <research.json> <state_slug> <batch_tag> <out_prefix> [chunk]
Only cities logged with batch '<state>_basic_tier'-style tags are upgraded; writes <out_prefix>_N.sql
and <out_prefix>_slugs.txt (for log_done.py).
"""
import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def q(s):
    return "'" + s.replace("'", "''") + "'"


def road(ref):
    ref = ref.replace('US-24 CONN', 'US-24').strip()
    m = re.match(r'^(I|US|M)[ -]?(\d+\w*)', ref)
    return f'{m.group(1)}-{m.group(2)}' if m else ref


BAD = re.compile(r'(hole|unit [a-z]\b|bumper|fountain|soccer|field|koi|frog|dipper|retention|drain|pond|tennis|court|playground|trailhead|parking|common area|lagoon|bayou|mermaid|pool|basin|runoff|pay lake|resivore|totlot|walking path|wi-fi|splash|skate|sports complex|fairgrounds|fair grounds|addition|campground|fishing spot|players club|tot lot|fountian|lake one)', re.I)


def norm(x):
    return re.sub(r'[^a-z]', '', (x or '').lower().replace('saint', 'st').replace('township', '').replace('charter', '').replace('balance', '').replace('city', '') if 'balance' in (x or '').lower() else (x or '').lower().replace('saint', 'st').replace('township', '').replace('charter', ''))


def verified(d):
    if d.get('osm_ok'):
        return True
    n = norm(d['name'])
    if any(norm(p) == n for p in d.get('places') or []):
        return True
    t = re.sub(r'(charter )?township$|city$|village$|town$', '', (d.get('township') or '').lower()).strip()
    return norm(t) == n


def good(name):
    return bool(name) and not BAD.search(name) and len(name) > 3


def area(name, sub):
    if sub and 'not defined' in sub:
        sub = None
    if sub:
        sub = re.sub(r'charter township', 'Charter Township', sub, flags=re.I)
    if not sub:
        return 'a small Michigan community'
    s = sub.strip()
    if s.lower().endswith(' township'):
        t = s[:-9].strip() + ' Township'
        return f'a community in {t}'
    if s.lower().endswith(' city'):
        c = s[:-5].strip()
        return f'a community near {c}' if c != name else 'a small Michigan city'
    if s.lower().endswith(' town'):
        return f'a community in the Town of {s[:-5].strip()}'
    if s.lower().endswith(' village'):
        return f'a community in the Village of {s[:-8].strip()}'
    return f'a community in {s}'


def main():
    src, state, tag, prefix = sys.argv[1:5]
    chunk = int(sys.argv[5]) if len(sys.argv) > 5 else 200
    data = json.load(open(src, encoding='utf-8'))
    basic = {r['city_slug'] for r in csv.DictReader(open(os.path.join(HERE, 'city_log.csv'), encoding='utf-8'))
             if r['state_slug'] == state and r['batch'] == tag}
    rows, slugs = [], []
    for slug, d in data.items():
        if slug not in basic or not d.get('county') or not verified(d):
            continue
        roads = [road(r) for r in d['roads'] if re.match(r'^(I|US|M)[ -]?\d', r)]
        roads = list(dict.fromkeys(roads))
        lms = [x for x in d['water'] + d['parks'] if good(x)][:6]
        lake = sum(1 for x in d['water'] if 'Lake' in x) >= 2
        rows.append('(' + ','.join(q(x) for x in [
            slug, d['county'], area(d['name'], d.get('township')),
            ' and '.join([', '.join(roads[:-1]), roads[-1]]) if len(roads) > 1 else (roads[0] if roads else 'local county roads'),
            '|'.join(lms),
            'lake homes, cottages and family homes' if lake else 'homes, garages and outbuildings',
            'lake home, cottage and garage cleanouts' if lake else 'garage, basement and barn cleanouts',
        ]) + ')')
        slugs.append(slug)
    tpl = open(os.path.join(HERE, 'template_v2.sql'), encoding='utf-8').read()
    for i in range(0, len(rows), chunk):
        open(f'{prefix}_{i // chunk + 1}.sql', 'w', encoding='utf-8').write(
            tpl.replace('/*VALUES*/', ',\n'.join(rows[i:i + chunk])))
    open(f'{prefix}_slugs.txt', 'w', encoding='utf-8').write(','.join(slugs))
    print(len(rows), 'cities ->', (len(rows) + chunk - 1) // chunk, 'files')


if __name__ == '__main__':
    main()
