"""Emit ONE compact UPDATE that fills all 5 services for every city in a facts file.

Text is assembled inside Postgres from small per-city facts + shared templates (from
generate.py), so the payload sent to Supabase stays small.
Usage: python -I compact_sql.py <facts.json> <state_slug> <out.sql>
Skips cities already in city_log.csv.
"""
import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import generate as g  # noqa: E402

SEP = '§'


def q(s):
    return "'" + s.replace("'", "''") + "'"


def main():
    facts_path, state_slug, out = sys.argv[1:4]
    cities = json.load(open(facts_path, encoding='utf-8'))
    done = set()
    if os.path.exists(g.LOG):
        done = {(r['state_slug'], r['city_slug']) for r in csv.DictReader(open(g.LOG, encoding='utf-8'))}
    cities = [c for c in cities if (state_slug, c['slug']) not in done]
    if not cities:
        print('nothing to do'); return

    f_rows = []
    for c in cities:
        name = c.get('name') or c['slug'].replace('-', ' ').title()
        nb = (c['nearby'] + ['nearby communities'] * 4)
        f_rows.append('(' + ','.join(q(x) for x in [
            c['slug'], name, c['county'], c['area'], c['roads'], c['landmarks'][0], c['landmarks'][1],
            nb[0], nb[1], nb[2], nb[3], c['homes'], c['season'], '|'.join(c['nearby']), '|'.join(c['landmarks'])]) + ')')

    s_rows = []
    for slug, s in g.SERVICES.items():
        (f1q, f1a), (f2q, f2a) = s['faqs']
        s_rows.append('(' + ','.join(q(x) for x in [
            slug, s['name'], s['name'].capitalize(), s['items'], s['hook'], ';'.join(s['includes']), ';'.join(s['pricing']),
            f1q, f1a, f2q, f2a]) + ')')

    # Template string: fields joined by SEP; intro/context variants chosen by hash.
    gen = [x for pair in g.GENERIC_FAQS for x in pair]
    housing = '{city} has {homes}. We handle {svc} from all of them, including basements, upstairs rooms and garages.'
    tail = SEP.join([housing, g.RULES] + gen)
    intro_arr = 'array[' + ','.join(q(x) for x in g.INTROS) + ']'
    ctx_arr = 'array[' + ','.join(q(x) for x in g.CONTEXTS) + ']'

    keys = ['city', 'county', 'area', 'roads', 'lm0', 'lm1', 'n0', 'n1', 'n2', 'n3', 'homes', 'season', 'svc', 'Svc', 'items', 'hook']
    expr = 't.tpl'
    for k in keys:
        col = {'city': 'f.name', 'svc': 's.name', 'Svc': 's.cap'}.get(k, ('s.' if k in ('items', 'hook') else 'f.') + k)
        expr = f"replace({expr}, '{{{k}}}', {col})"

    sql = f"""with f(slug,name,county,area,roads,lm0,lm1,n0,n1,n2,n3,homes,season,nearby,landmarks) as (values
{(','+chr(10)).join(f_rows)}),
s(slug,name,cap,items,hook,includes,pricing,f1q,f1a,f2q,f2a) as (values
{(','+chr(10)).join(s_rows)}),
t as (select f.slug fslug, s.slug sslug,
  ({intro_arr})[1 + abs(hashtext(f.slug||s.slug)) % {len(g.INTROS)}] || '{SEP}' ||
  ({ctx_arr})[1 + abs(hashtext(f.slug||s.slug||'c')) % {len(g.CONTEXTS)}] || '{SEP}' ||
  {q(tail)} || '{SEP}' || s.f1q || '{SEP}' || s.f1a || '{SEP}' || s.f2q || '{SEP}' || s.f2a as tpl
  from f cross join s),
r as (select t.fslug, t.sslug, {expr} as x from t join f on f.slug=t.fslug join s on s.slug=t.sslug)
update city_pages cp set
  unique_intro = split_part(r.x,'{SEP}',1),
  city_context = split_part(r.x,'{SEP}',2),
  housing_type = split_part(r.x,'{SEP}',3),
  local_rules_note = split_part(r.x,'{SEP}',4),
  service_includes = s.includes,
  pricing_factors = s.pricing,
  nearby_cities = f.nearby,
  landmarks = f.landmarks,
  faqs = jsonb_build_array(
    jsonb_build_object('question',split_part(r.x,'{SEP}',11),'answer',split_part(r.x,'{SEP}',12)),
    jsonb_build_object('question',split_part(r.x,'{SEP}',13),'answer',split_part(r.x,'{SEP}',14)),
    jsonb_build_object('question',split_part(r.x,'{SEP}',5),'answer',split_part(r.x,'{SEP}',6)),
    jsonb_build_object('question',split_part(r.x,'{SEP}',7),'answer',split_part(r.x,'{SEP}',8)),
    jsonb_build_object('question',split_part(r.x,'{SEP}',9),'answer',split_part(r.x,'{SEP}',10)))::text,
  seo_status = 'custom',
  updated_at = now()
from r join f on f.slug=r.fslug join s on s.slug=r.sslug
where cp.state_slug = {q(state_slug)} and cp.city_slug = r.fslug and cp.service_slug = r.sslug;
"""
    open(out, 'w', encoding='utf-8').write(sql)
    print(f'{len(cities)} cities, {len(sql)} bytes -> {out}')


if __name__ == '__main__':
    main()
