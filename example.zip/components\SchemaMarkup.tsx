import Script from 'next/script';

interface FAQ {
  question: string;
  answer: string;
}

interface Review {
  author: string;
  rating: number;
  body: string;
  date: string;
}

interface SchemaMarkupProps {
  type: 'organization' | 'localBusiness' | 'faq' | 'webpage' | 'service' | 'breadcrumb' | 'reviews';
  id?: string;
  data?: {
    name?: string;
    description?: string;
    url?: string;
    logo?: string;
    telephone?: string;
    email?: string;
    address?: {
      streetAddress?: string;
      addressLocality?: string;
      addressRegion?: string;
      postalCode?: string;
      addressCountry?: string;
    };
    geo?: {
      latitude: number;
      longitude: number;
    };
    openingHours?: string[];
    priceRange?: string;
    faqs?: FAQ[];
    breadcrumbs?: Array<{ name: string; url: string }>;
    areaServed?: string | string[];
    serviceType?: string;
    reviews?: Review[];
    ratingValue?: string;
    reviewCount?: string;
  };
}

export default function SchemaMarkup({ type, id, data = {} }: SchemaMarkupProps) {
  const generateSchema = () => {
    const baseUrl = 'https://junkremovals365.com';

    switch (type) {
      case 'organization':
        return {
          '@context': 'https://schema.org',
          '@type': 'Organization',
          name: data.name || 'Junk Removals 365',
          url: data.url || baseUrl,
          logo: data.logo || `${baseUrl}/icon.svg`,
          description: data.description || 'Professional junk removal and hauling services across the United States. Fast, eco-friendly, and affordable.',
          contactPoint: {
            '@type': 'ContactPoint',
            email: data.email || 'support@junkremovals365.com',
            contactType: 'Customer Service',
            areaServed: 'US',
            availableLanguage: 'English'
          },
          sameAs: [
            'https://www.facebook.com/junkremovals365',
            'https://twitter.com/junkremovals365',
            'https://www.instagram.com/junkremovals365'
          ]
        };

      case 'localBusiness':
        return {
          '@context': 'https://schema.org',
          '@type': 'LocalBusiness',
          '@id': data.url || baseUrl,
          name: data.name || 'Junk Removals 365',
          image: data.logo || `${baseUrl}/icon.svg`,
          description: data.description || 'Professional junk removal and hauling services. Same-day service available.',
          url: data.url || baseUrl,
          email: data.email || 'support@junkremovals365.com',
          priceRange: data.priceRange || '$$',
          address: data.address ? {
            '@type': 'PostalAddress',
            streetAddress: data.address.streetAddress,
            addressLocality: data.address.addressLocality,
            addressRegion: data.address.addressRegion,
            postalCode: data.address.postalCode,
            addressCountry: data.address.addressCountry || 'US'
          } : undefined,
          geo: data.geo ? {
            '@type': 'GeoCoordinates',
            latitude: data.geo.latitude,
            longitude: data.geo.longitude
          } : undefined,
          openingHoursSpecification: data.openingHours || [
            {
              '@type': 'OpeningHoursSpecification',
              dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
              opens: '07:00',
              closes: '20:00'
            }
          ],
          areaServed: typeof data.areaServed === 'string' || Array.isArray(data.areaServed)
            ? data.areaServed
            : { '@type': 'Country', name: 'United States' }
        };

      case 'service':
        return {
          '@context': 'https://schema.org',
          '@type': 'Service',
          serviceType: data.serviceType || 'Junk Removal',
          name: data.name || data.serviceType || 'Junk Removal',
          description: data.description,
          provider: {
            '@type': 'LocalBusiness',
            name: 'Junk Removals 365',
            image: `${baseUrl}/icon.svg`,
            url: baseUrl
          },
          areaServed: typeof data.areaServed === 'string' || Array.isArray(data.areaServed)
            ? data.areaServed
            : { '@type': 'Country', name: 'United States' },
        };

      case 'faq':
        if (!data.faqs || data.faqs.length === 0) return null;
        return {
          '@context': 'https://schema.org',
          '@type': 'FAQPage',
          mainEntity: data.faqs.map((faq) => ({
            '@type': 'Question',
            name: faq.question,
            acceptedAnswer: {
              '@type': 'Answer',
              text: faq.answer
            }
          }))
        };

      case 'webpage':
        return {
          '@context': 'https://schema.org',
          '@type': 'WebPage',
          '@id': data.url || baseUrl,
          url: data.url || baseUrl,
          name: data.name || 'Junk Removals 365',
          description: data.description || 'Professional couch removal and furniture disposal services',
          isPartOf: {
            '@type': 'WebSite',
            '@id': `${baseUrl}/#website`,
            url: baseUrl,
            name: 'Junk Removals 365'
          },
          breadcrumb: data.breadcrumbs ? {
            '@type': 'BreadcrumbList',
            itemListElement: data.breadcrumbs.map((crumb, index) => ({
              '@type': 'ListItem',
              position: index + 1,
              name: crumb.name,
              item: crumb.url
            }))
          } : undefined
        };

      case 'breadcrumb':
        if (!data.breadcrumbs || data.breadcrumbs.length === 0) return null;
        return {
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: data.breadcrumbs.map((crumb, index) => ({
            '@type': 'ListItem',
            position: index + 1,
            name: crumb.name,
            item: crumb.url
          }))
        };

      case 'reviews':
        return {
          '@context': 'https://schema.org',
          '@type': 'LocalBusiness',
          '@id': `${baseUrl}/#reviews`,
          name: data.name || 'Junk Removals 365',
          url: baseUrl,
          image: `${baseUrl}/image.png`,
          aggregateRating: {
            '@type': 'AggregateRating',
            ratingValue: data.ratingValue || '4.8',
            reviewCount: data.reviewCount || '500',
            bestRating: '5',
            worstRating: '1',
          },
          review: (data.reviews || []).map((r) => ({
            '@type': 'Review',
            reviewRating: {
              '@type': 'Rating',
              ratingValue: String(r.rating),
              bestRating: '5',
              worstRating: '1',
            },
            author: {
              '@type': 'Person',
              name: r.author,
            },
            datePublished: r.date,
            reviewBody: r.body,
          })),
        };

      default:
        return null;
    }
  };

  const schema = generateSchema();

  if (!schema) return null;

  const scriptId = id ? `schema-${id}` : `schema-${type}`;

  return (
    <Script
      id={scriptId}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      strategy="afterInteractive"
    />
  );
}
