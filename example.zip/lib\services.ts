export interface ServiceConfig {
  slug: string;
  name: string;
  shortName: string;
  headline: string;
  subheadline: string;
  description: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string;
  heroImage: string;
  accentColor: string;
  features: string[];
  howItWorks: { title: string; description: string }[];
  faqs: { question: string; answer: string }[];
  stats: { value: string; label: string }[];
  benefits: { title: string; description: string }[];
}

export const SERVICES: Record<string, ServiceConfig> = {
  'couch-removal': {
    slug: 'couch-removal',
    name: 'Couch Removal',
    shortName: 'Couch Removal',
    headline: 'Professional Couch & Sofa Removal',
    subheadline: 'Same-day pickup available — we haul any couch, sofa, or sectional from anywhere in your home.',
    description: 'Get rid of that old couch fast. Our licensed, insured team removes any couch, sofa, sectional, or loveseat from any floor of your home. We donate to local charities when possible and recycle the rest.',
    metaTitle: 'Cheap Couch & Sofa Removal | Same-Day Pickup | Junk Removals 365',
    metaDescription: 'Professional couch and sofa removal starting at $79. Same-day pickup available. We remove any couch, sectional, or loveseat from any floor of your home.',
    keywords: 'couch removal, sofa removal, cheap sofa removal, cheapest couch removal, couch disposal, how to dispose of a couch, sectional removal, sofa pickup',
    heroImage: '/images/mattress.webp',
    accentColor: 'green',
    features: [
      'Single couches & loveseats',
      'Large sectionals (2–6+ pieces)',
      'Sleeper sofas & pullouts',
      'Futons & daybeds',
      'Recliners & rocking chairs',
      'Disassembly when needed (+$40)',
    ],
    howItWorks: [
      { title: 'Book Online in 60 Seconds', description: 'Fill out our quick form to get an instant quote and choose your pickup window.' },
      { title: 'We Show Up On Time', description: 'Our uniformed, background-checked team arrives within your scheduled window.' },
      { title: 'We Remove Everything', description: 'We handle all lifting, carrying, and loading — from any floor, any tight space.' },
      { title: 'Eco-Friendly Disposal', description: 'Your couch gets donated to a local charity or responsibly recycled.' },
    ],
    faqs: [
      { question: 'How much does couch removal cost?', answer: 'Couch removal starts at $79 for a standard sofa. Sectionals, sleeper sofas, and multi-piece sets cost more. You receive an upfront quote with no hidden fees.' },
      { question: 'Can you remove a couch from upstairs?', answer: 'Yes! Our team handles all levels including upstairs rooms, basements, and tight hallways. Stairs add $10 per flight.' },
      { question: 'Do you offer same-day couch removal?', answer: 'Same-day service is available in most areas when you book before 2 PM. Next-day service is always available.' },
      { question: 'What happens to my old couch?', answer: 'We donate couches in good condition to local charities and shelters. Items that cannot be donated are recycled responsibly.' },
      { question: 'Do I need to be home during removal?', answer: 'Someone 18+ must be present to authorize the service. You do not need to help — just show us the couch.' },
      { question: 'What is the cheapest way to get rid of a couch?', answer: 'If your couch is in good shape, donating or selling it is usually the cheapest option. Some cities also offer bulky-item curbside pickup on set days. If you need it gone fast, cannot move it yourself, or it is not donatable, professional couch removal starting at $79 is often cheaper than renting a truck and paying dump fees.' },
      { question: 'How do I dispose of a couch?', answer: 'You have four main options: donate it to a charity or thrift store, schedule a bulky-item pickup with your city, haul it to a local landfill or transfer station yourself, or book a removal service. We handle the lifting and loading, then donate or recycle the couch whenever possible.' },
      { question: 'How should I prepare my couch for pickup?', answer: 'Take off any cushion covers you want to keep, clear personal items out of the cushions, and make sure there is a clear path to the door. You do not need to move the couch — our crew carries it out from any room or floor.' },
      { question: 'What affects the price of couch removal?', answer: 'Price depends on the size and number of pieces (a loveseat costs less than a 6-piece sectional), stairs or tight access, whether disassembly is needed, and how many other items you add to the pickup. You get an upfront quote before we start.' },
    ],
    stats: [
      { value: '19K+', label: 'Cities Served' },
      { value: '$79+', label: 'Starting Price' },
      { value: '4.9★', label: 'Average Rating' },
      { value: 'Same-Day', label: 'Service Available' },
    ],
    benefits: [
      { title: 'No Heavy Lifting for You', description: 'We carry everything out — through hallways, down stairs, and out the door.' },
      { title: 'Donate Instead of Dump', description: 'Good condition couches go to local charities and families in need.' },
      { title: 'Upfront Transparent Pricing', description: 'Know the exact cost before we arrive. No surprise fees at pickup.' },
    ],
  },

  'mattress-removal': {
    slug: 'mattress-removal',
    name: 'Mattress Removal',
    shortName: 'Mattress Removal',
    headline: 'Professional Mattress Removal & Disposal',
    subheadline: 'Responsible mattress disposal that keeps 90% of materials out of the landfill — any size, any floor.',
    description: 'Mattress disposal is harder than it looks — many dumps and recycling centers refuse them. Our team picks up any size mattress and box spring, handles transport, and ensures responsible recycling at certified facilities.',
    metaTitle: 'Mattress Removal & Disposal Service | Junk Removals 365',
    metaDescription: 'Professional mattress removal starting at $69. We pick up twin, full, queen, and king mattresses. Same-day service available. Eco-friendly mattress recycling.',
    keywords: 'mattress removal, mattress disposal, mattress pickup, old mattress removal, mattress recycling, box spring removal, same day mattress removal',
    heroImage: '/images/couch_removal_front_door.webp',
    accentColor: 'blue',
    features: [
      'Twin, full, queen & king mattresses',
      'Box springs & foundations',
      'Memory foam & pillow tops',
      'Bunk bed mattresses',
      'Mattress toppers',
      'Multiple mattress discounts',
    ],
    howItWorks: [
      { title: 'Schedule Your Pickup', description: 'Book online and pick a time window. Same-day and next-day slots available.' },
      { title: 'Team Arrives On Time', description: 'Our licensed, insured crew shows up ready with all necessary equipment.' },
      { title: 'Mattress Removed Safely', description: 'We carry it out wrapped and clean — no dragging, no damage to your walls.' },
      { title: 'Certified Mattress Recycling', description: 'Steel springs, foam, and fibers are separated and sent to recycling facilities.' },
    ],
    faqs: [
      { question: 'How much does mattress removal cost?', answer: 'Mattress removal starts at $69 for a twin. Queen and king sizes start at $89. Multi-mattress pickups receive a discount. You get an exact quote upfront.' },
      { question: 'Can you remove a mattress from a second-floor bedroom?', answer: 'Absolutely. We handle any floor of your home. Stairs are $10 per flight. We protect your walls and floors throughout the process.' },
      { question: 'Do you recycle mattresses?', answer: 'Yes — 85–90% of mattress materials can be recycled. We take mattresses to certified recycling facilities where steel, foam, and fabric are separated and reused.' },
      { question: 'Can you remove a box spring too?', answer: 'Yes. Box spring removal is often included or available at a small additional cost. Let us know when booking.' },
      { question: 'Is same-day mattress removal available?', answer: 'Same-day pickup is available in most cities when you book before 2 PM.' },
    ],
    stats: [
      { value: '85%+', label: 'Materials Recycled' },
      { value: '$69+', label: 'Starting Price' },
      { value: '19K+', label: 'Cities Served' },
      { value: 'Same-Day', label: 'Service Available' },
    ],
    benefits: [
      { title: 'Certified Mattress Recycling', description: '85–90% of mattress materials are recycled — springs, foam, and fabric all find new life.' },
      { title: 'Any Size, Any Floor', description: 'Twin to California king, ground floor to third floor — we handle it all.' },
      { title: 'Hassle-Free Scheduling', description: 'Book in 60 seconds online. Same-day and next-day slots available nationwide.' },
    ],
  },

  'appliance-removal': {
    slug: 'appliance-removal',
    name: 'Appliance Removal',
    shortName: 'Appliance Removal',
    headline: 'Appliance Removal & Disposal Service',
    subheadline: 'We remove refrigerators, washers, dryers, dishwashers, and more — safely disconnected and hauled away.',
    description: 'Old appliances are heavy, bulky, and hard to dispose of legally. Our trained team safely disconnects and removes any household appliance from any location, ensuring proper disposal and recycling of metals and components.',
    metaTitle: 'Appliance Removal | Same-Day Hauling | Junk Removals 365',
    metaDescription: 'Professional appliance removal for refrigerators, washers, dryers & more. Safe disconnection included. Eco-friendly disposal. Same-day service available.',
    keywords: 'appliance removal, refrigerator removal, washer dryer removal, appliance disposal, old appliance pickup, stove removal, dishwasher removal',
    heroImage: '/images/fridge_for_donation.webp',
    accentColor: 'orange',
    features: [
      'Refrigerators & freezers',
      'Washers & dryers',
      'Stoves & ovens',
      'Dishwashers',
      'Microwaves & small appliances',
      'Air conditioners & dehumidifiers',
    ],
    howItWorks: [
      { title: 'Book & Get a Quote', description: 'Tell us what appliances need removing. Get an upfront, transparent price instantly.' },
      { title: 'Safe Disconnection', description: 'Our team safely disconnects water, gas, and electrical connections before removal.' },
      { title: 'Heavy Lifting Done for You', description: 'We move heavy appliances out without damaging floors, walls, or doorways.' },
      { title: 'Responsible Metal Recycling', description: 'Appliance metals and components are sent to certified recycling and disposal facilities.' },
    ],
    faqs: [
      { question: 'How much does appliance removal cost?', answer: 'Appliance removal starts at $89 for most items. Larger items like side-by-side refrigerators or stackable units may cost more. You get an exact quote before we arrive.' },
      { question: 'Do you disconnect the appliance before removal?', answer: 'Yes. Our team safely disconnects water lines, gas connections, and electrical before moving the appliance. We do not reconnect new appliances.' },
      { question: 'Can you remove appliances from a basement?', answer: 'Absolutely. We remove appliances from any floor, including basements. Stairs are $10 per flight.' },
      { question: 'What happens to old appliances?', answer: 'Appliances are taken to certified facilities where metals like steel and copper are separated and recycled. Refrigerants are extracted per EPA regulations.' },
      { question: 'Can you remove multiple appliances at once?', answer: 'Yes — and you\'ll save money. Multi-item pickups receive a discount. Tell us everything that needs to go when you book.' },
    ],
    stats: [
      { value: '100%', label: 'Safe Disconnection' },
      { value: '$89+', label: 'Starting Price' },
      { value: '19K+', label: 'Cities Served' },
      { value: 'Same-Day', label: 'Service Available' },
    ],
    benefits: [
      { title: 'Safe Disconnection Included', description: 'We handle water, gas, and electrical disconnection — no risk to you or your home.' },
      { title: 'Metal & Component Recycling', description: 'Appliance metals and refrigerants are recycled per EPA and local regulations.' },
      { title: 'No Damage Guarantee', description: 'We protect your floors and walls when moving heavy appliances out of your home.' },
    ],
  },

  'furniture-removal': {
    slug: 'furniture-removal',
    name: 'Furniture Removal',
    shortName: 'Furniture Removal',
    headline: 'Full Furniture Removal & Hauling Service',
    subheadline: 'From single pieces to full-room clearouts — we remove any furniture, any size, from any room.',
    description: 'Moving, redecorating, or clearing an estate? Our furniture removal service handles everything — beds, dressers, dining sets, office furniture, and more. One call clears an entire room or whole home.',
    metaTitle: 'Affordable Furniture Removal for Homes & Businesses | Junk Removals 365',
    metaDescription: 'Affordable furniture removal for homes and businesses, starting at $79. Beds, dressers, desks, office furniture & full-room clearouts. Same-day service nationwide.',
    keywords: 'affordable furniture removals, furniture removal, office furniture removal, furniture disposal, furniture pickup, bed frame removal, dresser removal, furniture hauling, estate clearout, full room furniture removal',
    heroImage: '/images/furniture_removal.webp',
    accentColor: 'teal',
    features: [
      'Beds, frames & headboards',
      'Dressers & armoires',
      'Dining tables & chairs',
      'Desks & office furniture',
      'Bookshelves & cabinets',
      'Full room & estate clearouts',
    ],
    howItWorks: [
      { title: 'Tell Us What You Have', description: 'List the furniture items you need removed. Get an instant quote online.' },
      { title: 'Schedule Your Pickup', description: 'Choose a date and window that works for you — same-day slots available.' },
      { title: 'We Remove & Haul', description: 'Our team disassembles, carries, and loads all furniture onto our truck.' },
      { title: 'Donate or Responsibly Dispose', description: 'Furniture in good condition is donated to local charities. The rest is recycled.' },
    ],
    faqs: [
      { question: 'What types of furniture do you remove?', answer: 'We remove virtually any furniture — beds and frames, dressers, dining sets, desks, bookshelves, armoires, cabinets, and more. If it came into your home, we can take it out.' },
      { question: 'Can you do a full room or estate clearout?', answer: 'Yes. We offer full room and whole-home furniture clearouts for moves, estate cleanups, and renovations. Volume discounts apply for large jobs.' },
      { question: 'How much does furniture removal cost?', answer: 'Furniture removal starts at $79 for a single piece. Full room and estate clearouts are priced by volume. You receive a transparent quote before any work begins.' },
      { question: 'Do you disassemble furniture?', answer: 'Yes — basic disassembly is included when needed to safely remove items. Complex or specialty disassembly may have an additional charge.' },
      { question: 'Will you donate my furniture?', answer: 'Yes. Furniture in good, clean condition is donated to local charities, thrift stores, and shelters whenever possible.' },
      { question: 'Do you remove office and business furniture?', answer: 'Yes. We remove desks, office chairs, cubicles, conference tables, filing cabinets, and break-room furniture for businesses of every size, including after-hours scheduling where available.' },
      { question: 'How do I prepare furniture for removal?', answer: 'Empty drawers and shelves, remove personal items, and point out anything fragile in the path. Our crew handles disassembly, carrying, and loading — you do not need to move anything to the curb.' },
      { question: 'What affects the cost of furniture removal?', answer: 'The number and size of items, total truck space used, stairs or long carries, and whether disassembly is needed all affect the price. Adding more items to one pickup usually lowers the cost per piece.' },
    ],
    stats: [
      { value: 'Any Size', label: 'Items Accepted' },
      { value: '$79+', label: 'Starting Price' },
      { value: '19K+', label: 'Cities Served' },
      { value: 'Same-Day', label: 'Service Available' },
    ],
    benefits: [
      { title: 'Single Pieces to Full Estates', description: 'Whether it\'s one chair or an entire household, we have the crew and truck to handle it.' },
      { title: 'Disassembly Included', description: 'We break down beds, desks, and shelving to safely remove items from tight spaces.' },
      { title: 'Charity Donation First', description: 'Usable furniture goes to families in need — not the landfill.' },
    ],
  },

  'junk-removal': {
    slug: 'junk-removal',
    name: 'Junk Removal',
    shortName: 'Junk Removal',
    headline: 'Local Junk Haulers Near You',
    subheadline: 'Full service junk removal for homes and businesses — same-day pickup, upfront pricing, and eco-friendly disposal you can count on.',
    description: 'Looking for local junk haulers near you? Junk Removals 365 is a full service junk removal company that hauls away furniture, appliances, trash, yard debris, and more. We offer home cleanout services, estate hauls, and garage cleanouts — with transparent pricing and no hidden fees.',
    metaTitle: 'Junk Removal Service | Local Haulers | Junk Removals 365',
    metaDescription: 'Local junk haulers for full service removal, home cleanouts, and trash hauling. Same-day pickup available. Upfront pricing, licensed & insured crews.',
    keywords: 'local junk haulers near me, full service junk removal, junk hauling services, free junk removal near me, trash removal, home cleanout services, junk removal near me, garage cleanout',
    heroImage: '/images/junk_removal.webp',
    accentColor: 'green',
    features: [
      'Garage & basement cleanouts',
      'Full home cleanout services',
      'Mixed household junk & trash',
      'Furniture & appliance removal',
      'Yard waste & debris haul',
      'Construction & renovation debris',
      'Estate & hoarder cleanouts',
      'Commercial junk hauls',
    ],
    howItWorks: [
      { title: 'Book Your Free Quote', description: 'Tell us what you need hauled. Get an upfront, no-obligation price — no need to sort or bag anything first.' },
      { title: 'Local Crew Shows Up On Time', description: 'Your assigned local junk haulers arrive in a marked truck within your scheduled window, uniformed and ready.' },
      { title: 'We Load Every Last Piece', description: 'We do all the heavy lifting — you just point to what goes. Furniture, trash bags, appliances, debris — all of it.' },
      { title: 'Sorted, Recycled & Donated', description: 'We separate recyclables, donate usable items to local charities, and minimize what goes to landfill.' },
    ],
    faqs: [
      { question: 'How do I find local junk haulers near me?', answer: 'Junk Removals 365 has local crews operating across the United States. Enter your zip code on our booking page to see real-time availability in your area. Same-day and next-day service is available in most cities.' },
      { question: 'How much does full service junk removal cost?', answer: 'Full service junk removal starts at $99 and is priced by truck volume. A minimum load (about 1/8 of a truck) starts at $99. A full truck is typically $349–$449. You always receive an exact upfront quote — no surprise fees at the door.' },
      { question: 'Do you offer anything close to free junk removal near me?', answer: 'While we are a professional service and cannot offer free junk removal, our pricing is among the most competitive you will find. Items in good condition are donated, which saves disposal costs — sometimes significantly reducing your total. Get a free no-obligation quote to see your price.' },
      { question: 'Do you provide home cleanout services?', answer: 'Yes. Home cleanout services are one of our most popular offerings. Whether you are clearing an estate, preparing a property for sale, or decluttering after a move, our teams can clear an entire house in a single day. Volume discounts apply for whole-home hauls.' },
      { question: 'Can you handle trash removal and regular household junk?', answer: 'Absolutely. We handle trash removal, old furniture, broken appliances, yard debris, and general household clutter. No sorting required — just point and we haul it.' },
      { question: 'Do I need to sort or bag my junk?', answer: 'No. We take mixed loads as-is. Our team separates recyclables and donatables at our facility, so you do not need to do any prep work beforehand.' },
      { question: 'Is same-day junk removal available?', answer: 'Same-day service is available in most areas when you book before 2 PM. Call or book online and we will check real-time availability in your zip code.' },
      { question: 'What items can you not remove?', answer: 'We cannot remove hazardous materials including paints, solvents, pesticides, asbestos, motor oil, or medical waste. For everything else — furniture, electronics, appliances, yard waste, construction debris — we are your team.' },
    ],
    stats: [
      { value: '$99+', label: 'Starting Price' },
      { value: '5,000+', label: 'Loads Hauled' },
      { value: '4.8★', label: 'Average Rating' },
      { value: 'Same-Day', label: 'Service Available' },
    ],
    benefits: [
      { title: 'Truly Local Haulers', description: 'We work with vetted local crews in your area — faster response times and real accountability to your community.' },
      { title: 'No Sorting, No Prep', description: 'Mixed loads taken as-is. We separate recyclables and donatables so you do not have to lift a finger.' },
      { title: 'Full Cleanouts in One Trip', description: 'Our large-capacity trucks handle garage, basement, estate, and whole-home cleanouts without multiple trips.' },
    ],
  },
};

export const SERVICE_LIST = Object.values(SERVICES);

export function getService(slug: string): ServiceConfig | null {
  return SERVICES[slug] ?? null;
}

export function getServiceAccentClasses(color: string): { bg: string; text: string; border: string; bgLight: string; bgDark: string } {
  const map: Record<string, { bg: string; text: string; border: string; bgLight: string; bgDark: string }> = {
    green: { bg: 'bg-green-600', text: 'text-green-600', border: 'border-green-500', bgLight: 'bg-green-50', bgDark: 'bg-green-700' },
    blue: { bg: 'bg-blue-600', text: 'text-blue-600', border: 'border-blue-500', bgLight: 'bg-blue-50', bgDark: 'bg-blue-700' },
    orange: { bg: 'bg-orange-600', text: 'text-orange-600', border: 'border-orange-500', bgLight: 'bg-orange-50', bgDark: 'bg-orange-700' },
    teal: { bg: 'bg-teal-600', text: 'text-teal-600', border: 'border-teal-500', bgLight: 'bg-teal-50', bgDark: 'bg-teal-700' },
    red: { bg: 'bg-red-600', text: 'text-red-600', border: 'border-red-500', bgLight: 'bg-red-50', bgDark: 'bg-red-700' },
  };
  return map[color] ?? map.green;
}
