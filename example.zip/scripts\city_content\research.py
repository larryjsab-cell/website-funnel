"""Research facts for small towns from public data (no guessing).

- County + county subdivision (township): US Census geocoder, from lat/lng.
- Nearby named lakes/rivers/parks and highway refs: OpenStreetMap Overpass API.

Usage: python research.py <coords.json> <out.json> [limit]
coords.json: [{"city_slug","city_name","lat","lng"}]. Resumes: skips slugs already in out.json.
"""
import json
import os
import sys
import time
import urllib.parse
import urllib.request

MIRRORS = ['https://overpass.kumi.systems/api/interpreter', 'https://overpass.private.coffee/api/interpreter', 'https://overpass-api.de/api/interpreter']
UA = {'User-Agent': 'junkremovals365-content-research/1.0'}


def get(url, data=None, timeout=60):
    req = urllib.request.Request(url, data=data, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def census(lat, lng):
    q = urllib.parse.urlencode({'x': lng, 'y': lat, 'benchmark': 'Public_AR_Current', 'vintage': 'Current_Current',
                                'layers': 'Counties,County Subdivisions,Incorporated Places,Census Designated Places', 'format': 'json'})
    g = get('https://geocoding.geo.census.gov/geocoder/geographies/coordinates?' + q)['result']['geographies']
    county = (g.get('Counties') or [{}])[0].get('BASENAME')
    sub = (g.get('County Subdivisions') or [{}])[0].get('NAME')
    places = [p.get('BASENAME', '') for k in ('Incorporated Places', 'Census Designated Places') for p in (g.get(k) or [])]
    return county, sub, places


def osm(lat, lng):
    q = f"""[out:json][timeout:40];
(
  way["natural"="water"]["name"](around:6000,{lat},{lng});
  relation["natural"="water"]["name"](around:6000,{lat},{lng});
  way["waterway"="river"]["name"](around:5000,{lat},{lng});
  way["leisure"="park"]["name"](around:5000,{lat},{lng});
  relation["boundary"="protected_area"]["name"](around:8000,{lat},{lng});
  way["highway"~"^(motorway|trunk|primary)$"]["ref"](around:4000,{lat},{lng});
);
out tags;"""
    body = urllib.parse.urlencode({'data': q}).encode()
    last = None
    for host in MIRRORS:
        try:
            d = get(host, data=body)
            break
        except Exception as e:  # noqa: BLE001
            last = e
    else:
        raise last
    water, parks, roads = [], [], []
    for e in d.get('elements', []):
        t = e.get('tags', {})
        if t.get('highway'):
            for ref in t['ref'].split(';'):
                ref = ref.strip()
                if ref and ref not in roads:
                    roads.append(ref)
        elif t.get('natural') == 'water' or t.get('waterway'):
            n = t.get('name')
            if n and n not in water:
                water.append(n)
        else:
            n = t.get('name')
            if n and n not in parks:
                parks.append(n)
    return water[:4], parks[:4], roads[:3]


def main():
    src, out = sys.argv[1], sys.argv[2]
    limit = int(sys.argv[3]) if len(sys.argv) > 3 else 10 ** 9
    cities = json.load(open(src, encoding='utf-8'))
    res = json.load(open(out, encoding='utf-8')) if os.path.exists(out) else {}
    from concurrent.futures import ThreadPoolExecutor
    todo = [c for c in cities if c['city_slug'] not in res][:limit]

    def work(c):
        try:
            county, sub = census(c['lat'], c['lng'])
            water, parks, roads = osm(c['lat'], c['lng'])
            return c['city_slug'], {'name': c['city_name'], 'county': county, 'township': sub,
                                    'water': water, 'parks': parks, 'roads': roads}
        except Exception as e:  # noqa: BLE001
            print('ERR', c['city_slug'], e, flush=True)
            return c['city_slug'], None

    with ThreadPoolExecutor(4) as ex:
        for i, (slug, v) in enumerate(ex.map(work, todo), 1):
            if v:
                res[slug] = v
            if i % 25 == 0:
                json.dump(res, open(out, 'w', encoding='utf-8'), ensure_ascii=False)
                print(len(res), 'saved', flush=True)
    json.dump(res, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print('total', len(res))


if __name__ == '__main__':
    main()
