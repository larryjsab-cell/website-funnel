import { notFound } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BookingSection from '@/components/BookingSection';
import { getService, SERVICE_LIST } from '@/lib/services';
import {
  CircleCheck as CheckCircle,
  ArrowRight,
  Shield,
  Zap,
  Leaf,
  Clock,
  Star,
  MapPin,
  Phone,
  ChevronRight,
  Truck,
  Award,
  ThumbsUp,
  DollarSign,
  Recycle,
} from 'lucide-react';
import type { Metadata } from 'next';
import SchemaMarkup from '@/components/SchemaMarkup';

export async function generateStaticParams() {
  return SERVICE_LIST.map((s) => ({ service: s.slug }));
}

export async function generateMetadata({ params }: { params: { service: string } }): Promise<Metadata> {
  const service = getService(params.service);
  if (!service) return { title: 'Service Not Found' };
  return {
    title: service.metaTitle,
    description: service.metaDescription,
    keywords: service.keywords,
    alternates: { canonical: `https://junkremovals365.com/services/${service.slug}` },
    openGraph: {
      title: service.metaTitle,
      description: service.metaDescription,
      url: `https://junkremovals365.com/services/${service.slug}`,
      siteName: 'Junk Removals 365',
      type: 'website',
      images: [{ url: 'https://junkremovals365.com/image.png' }],
    },
  };
}

const US_STATES = [
  { name: 'Alabama', slug: 'alabama' }, { name: 'Alaska', slug: 'alaska' }, { name: 'Arizona', slug: 'arizona' },
  { name: 'Arkansas', slug: 'arkansas' }, { name: 'California', slug: 'california' }, { name: 'Colorado', slug: 'colorado' },
  { name: 'Connecticut', slug: 'connecticut' }, { name: 'Delaware', slug: 'delaware' }, { name: 'Florida', slug: 'florida' },
  { name: 'Georgia', slug: 'georgia' }, { name: 'Hawaii', slug: 'hawaii' }, { name: 'Idaho', slug: 'idaho' },
  { name: 'Illinois', slug: 'illinois' }, { name: 'Indiana', slug: 'indiana' }, { name: 'Iowa', slug: 'iowa' },
  { name: 'Kansas', slug: 'kansas' }, { name: 'Kentucky', slug: 'kentucky' }, { name: 'Louisiana', slug: 'louisiana' },
  { name: 'Maine', slug: 'maine' }, { name: 'Maryland', slug: 'maryland' }, { name: 'Massachusetts', slug: 'massachusetts' },
  { name: 'Michigan', slug: 'michigan' }, { name: 'Minnesota', slug: 'minnesota' }, { name: 'Mississippi', slug: 'mississippi' },
  { name: 'Missouri', slug: 'missouri' }, { name: 'Montana', slug: 'montana' }, { name: 'Nebraska', slug: 'nebraska' },
  { name: 'Nevada', slug: 'nevada' }, { name: 'New Hampshire', slug: 'new-hampshire' }, { name: 'New Jersey', slug: 'new-jersey' },
  { name: 'New Mexico', slug: 'new-mexico' }, { name: 'New York', slug: 'new-york' }, { name: 'North Carolina', slug: 'north-carolina' },
  { name: 'North Dakota', slug: 'north-dakota' }, { name: 'Ohio', slug: 'ohio' }, { name: 'Oklahoma', slug: 'oklahoma' },
  { name: 'Oregon', slug: 'oregon' }, { name: 'Pennsylvania', slug: 'pennsylvania' }, { name: 'Rhode Island', slug: 'rhode-island' },
  { name: 'South Carolina', slug: 'south-carolina' }, { name: 'South Dakota', slug: 'south-dakota' }, { name: 'Tennessee', slug: 'tennessee' },
  { name: 'Texas', slug: 'texas' }, { name: 'Utah', slug: 'utah' }, { name: 'Vermont', slug: 'vermont' },
  { name: 'Virginia', slug: 'virginia' }, { name: 'Washington', slug: 'washington' }, { name: 'Washington DC', slug: 'washington-dc' },
  { name: 'West Virginia', slug: 'west-virginia' }, { name: 'Wisconsin', slug: 'wisconsin' }, { name: 'Wyoming', slug: 'wyoming' },
];

const TOP_CITIES = [
  { name: 'Los Angeles', state: 'california', slug: 'los-angeles' },
  { name: 'New York City', state: 'new-york', slug: 'new-york-city' },
  { name: 'Houston', state: 'texas', slug: 'houston' },
  { name: 'Phoenix', state: 'arizona', slug: 'phoenix' },
  { name: 'Chicago', state: 'illinois', slug: 'chicago' },
  { name: 'Philadelphia', state: 'pennsylvania', slug: 'philadelphia' },
  { name: 'San Antonio', state: 'texas', slug: 'san-antonio' },
  { name: 'San Diego', state: 'california', slug: 'san-diego' },
  { name: 'Dallas', state: 'texas', slug: 'dallas' },
  { name: 'Miami', state: 'florida', slug: 'miami' },
  { name: 'Atlanta', state: 'georgia', slug: 'atlanta' },
  { name: 'Denver', state: 'colorado', slug: 'denver' },
];

const accentBgMap: Record<string, string> = {
  green: 'bg-green-600', blue: 'bg-blue-600', orange: 'bg-orange-600', teal: 'bg-teal-600', red: 'bg-red-600',
};
const accentTextMap: Record<string, string> = {
  green: 'text-green-600', blue: 'text-blue-600', orange: 'text-orange-600', teal: 'text-teal-600', red: 'text-red-600',
};
const accentHoverMap: Record<string, string> = {
  green: 'hover:bg-green-700', blue: 'hover:bg-blue-700', orange: 'hover:bg-orange-700', teal: 'hover:bg-teal-700', red: 'hover:bg-red-700',
};
const accentBgLightMap: Record<string, string> = {
  green: 'bg-green-50', blue: 'bg-blue-50', orange: 'bg-orange-50', teal: 'bg-teal-50', red: 'bg-red-50',
};
const accentBorderLightMap: Record<string, string> = {
  green: 'border-green-200', blue: 'border-blue-200', orange: 'border-orange-200', teal: 'border-teal-200', red: 'border-red-200',
};

const TESTIMONIALS = [
  {
    name: 'Sarah M.',
    location: 'Austin, TX',
    rating: 5,
    text: 'They showed up on time, removed everything fast, and were incredibly professional. Would 100% recommend to anyone needing same-day service.',
  },
  {
    name: 'James R.',
    location: 'Denver, CO',
    rating: 5,
    text: 'Got an instant quote online, booked within minutes. The crew was friendly and efficient — cleared everything in under an hour.',
  },
  {
    name: 'Linda K.',
    location: 'Orlando, FL',
    rating: 5,
    text: 'Affordable pricing and zero hassle. They even donated my old items to a local charity. Will use again for sure.',
  },
];

const PRICING_FACTORS = [
  { icon: Truck, label: 'Item Size & Weight', desc: 'Larger or heavier items require more labor and truck space.' },
  { icon: MapPin, label: 'Floor Location', desc: 'Items on upper floors or in tight spaces may add a small stair fee.' },
  { icon: Award, label: 'Volume of Items', desc: 'Multi-item pickups often qualify for bundle discounts.' },
  { icon: Clock, label: 'Service Timing', desc: 'Same-day slots are available — scheduling flexibility at no extra cost.' },
];

export default function ServicePage({ params }: { params: { service: string } }) {
  const service = getService(params.service);
  if (!service) notFound();

  const accentBg = accentBgMap[service.accentColor] ?? 'bg-green-600';
  const accentText = accentTextMap[service.accentColor] ?? 'text-green-600';
  const accentHover = accentHoverMap[service.accentColor] ?? 'hover:bg-green-700';
  const accentBgLight = accentBgLightMap[service.accentColor] ?? 'bg-green-50';
  const accentBorderLight = accentBorderLightMap[service.accentColor] ?? 'border-green-200';

  const relatedServices = SERVICE_LIST.filter((s) => s.slug !== service.slug).slice(0, 4);

  const baseUrl = 'https://junkremovals365.com';
  const pageUrl = `${baseUrl}/services/${service.slug}`;

  return (
    <div className="min-h-screen bg-white">
      <SchemaMarkup
        type="faq"
        id={`faq-${service.slug}`}
        data={{ faqs: service.faqs }}
      />
      <SchemaMarkup
        type="localBusiness"
        id={`lb-${service.slug}`}
        data={{
          description: service.metaDescription,
          url: pageUrl,
          serviceType: service.name,
        }}
      />
      <SchemaMarkup
        type="breadcrumb"
        id={`bc-${service.slug}`}
        data={{
          breadcrumbs: [
            { name: 'Home', url: baseUrl },
            { name: 'Services', url: `${baseUrl}/services` },
            { name: service.name, url: pageUrl },
          ],
        }}
      />

      <Header />

      <main>
      {/* Breadcrumbs */}
      <nav className="bg-gray-50 border-b border-gray-200 py-3">
        <div className="container mx-auto px-4 max-w-7xl">
          <ol className="flex items-center gap-2 text-sm text-gray-500 flex-wrap">
            <li><Link href="/" className="hover:text-gray-800 transition-colors">Home</Link></li>
            <li><ChevronRight className="h-3 w-3" /></li>
            <li><Link href="/services" className="hover:text-gray-800 transition-colors">Services</Link></li>
            <li><ChevronRight className="h-3 w-3" /></li>
            <li className="text-gray-900 font-medium">{service.name}</li>
          </ol>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative py-20 lg:py-28 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src={service.heroImage}
            alt={`${service.name} service`}
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-950/95 via-gray-900/88 to-gray-900/60" />
        </div>

        <div className="relative z-10 container mx-auto px-4 max-w-7xl">
          <div className="max-w-3xl">
            {/* Trust badges */}
            <div className="flex flex-wrap gap-2 mb-6">
              {['Licensed & Insured', 'Same-Day Service', 'Free Quote'].map((badge) => (
                <span key={badge} className="inline-flex items-center gap-1.5 bg-white/15 border border-white/30 text-white text-xs font-semibold px-3 py-1.5 rounded-full">
                  <CheckCircle className="h-3.5 w-3.5" />
                  {badge}
                </span>
              ))}
            </div>

            <h1 className="text-4xl lg:text-6xl font-bold text-white mb-5 leading-tight">
              {service.name} Services Near You
            </h1>

            <p className="text-xl text-gray-200 mb-8 leading-relaxed">
              {service.subheadline} Fast, affordable, and handled by a local team that cares.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <Link
                href="/book"
                className={`inline-flex items-center justify-center ${accentBg} ${accentHover} text-white px-8 py-4 rounded-lg font-bold transition-colors text-lg shadow-lg`}
              >
                Get a Free Quote
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
              {service.stats.map((stat, i) => (
                <div key={i} className="text-center">
                  <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-gray-300 text-sm">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Intro + What We Remove */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Professional {service.name} Near You
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                {service.description} With over 10,000 jobs completed nationwide, our fast, affordable {service.name.toLowerCase()} service is available in your area — often same day.
              </p>
              <div className="flex flex-wrap gap-3 mb-6">
                {[
                  { icon: Shield, text: 'Licensed & Insured' },
                  { icon: Zap, text: 'Same-Day Available' },
                  { icon: ThumbsUp, text: 'Upfront Pricing' },
                  { icon: Leaf, text: 'Eco-Friendly Disposal' },
                ].map(({ icon: Icon, text }) => (
                  <span key={text} className={`inline-flex items-center gap-2 ${accentBgLight} ${accentText} text-sm font-semibold px-4 py-2 rounded-full border ${accentBorderLight}`}>
                    <Icon className="h-4 w-4" />
                    {text}
                  </span>
                ))}
              </div>
              <p className="text-gray-600 leading-relaxed">
                We serve customers across all 50 states. Whether you need a single item removed or a full cleanout, our local teams are ready to help — no hidden fees, no hassle.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">What We Remove</h3>
              <div className="grid sm:grid-cols-2 gap-3">
                {service.features.map((f, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <CheckCircle className={`h-5 w-5 flex-shrink-0 ${accentText}`} />
                    <span className="text-gray-800 font-medium text-sm">{f}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className={`py-16 ${accentBgLight}`}>
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">Why Choose Junk Removals 365?</h2>
            <p className="text-lg text-gray-600">Trusted by 10,000+ homeowners across America for fast, reliable service</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {service.benefits.map((b, i) => (
              <div key={i} className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                <div className={`w-10 h-10 ${accentBg} rounded-lg flex items-center justify-center mb-4`}>
                  {i === 0 && <Shield className="h-5 w-5 text-white" />}
                  {i === 1 && <Leaf className="h-5 w-5 text-white" />}
                  {i === 2 && <Zap className="h-5 w-5 text-white" />}
                </div>
                <h3 className="font-bold text-gray-900 mb-2">{b.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{b.description}</p>
              </div>
            ))}
            {/* Additional benefit cards to hit word count and completeness */}
            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className={`w-10 h-10 ${accentBg} rounded-lg flex items-center justify-center mb-4`}>
                <Award className="h-5 w-5 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">10,000+ Jobs Completed</h3>
              <p className="text-gray-600 text-sm leading-relaxed">Years of experience across every state means you get a professional team that knows how to handle any removal challenge.</p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className={`w-10 h-10 ${accentBg} rounded-lg flex items-center justify-center mb-4`}>
                <DollarSign className="h-5 w-5 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">No Hidden Fees — Ever</h3>
              <p className="text-gray-600 text-sm leading-relaxed">The price we quote is the price you pay. No surprise charges at the door, no fuel surcharges, no disposal add-ons.</p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className={`w-10 h-10 ${accentBg} rounded-lg flex items-center justify-center mb-4`}>
                <Phone className="h-5 w-5 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Local Teams Near You</h3>
              <p className="text-gray-600 text-sm leading-relaxed">We work with vetted local crews in your area — meaning faster response times and better accountability.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">How Our {service.name} Works</h2>
            <p className="text-lg text-gray-600">From booking to removal in 4 simple steps — as fast as the same day</p>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {service.howItWorks.map((step, i) => (
              <div key={i} className="relative">
                <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 h-full">
                  <div className={`w-12 h-12 ${accentBg} rounded-full flex items-center justify-center text-white font-bold text-lg mb-4`}>
                    {i + 1}
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{step.description}</p>
                </div>
                {i < service.howItWorks.length - 1 && (
                  <ArrowRight className="hidden md:block absolute -right-3 top-1/2 -translate-y-1/2 h-6 w-6 text-gray-300 z-10" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Explanation */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                {service.name} Pricing
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Our {service.name.toLowerCase()} pricing is simple and transparent. Rates start at {service.stats.find(s => s.label === 'Starting Price')?.value ?? 'competitive prices'} and are based on the size and quantity of items. You always receive an upfront quote — no surprise fees.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Most customers find our pricing 20–30% more affordable than local competitors, especially for same-day and multi-item jobs. We offer volume discounts for full room cleanouts and estate hauls.
              </p>
              <Link
                href="/book"
                className={`inline-flex items-center ${accentBg} ${accentHover} text-white px-6 py-3 rounded-lg font-bold transition-colors`}
              >
                Get Your Free Quote
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              {PRICING_FACTORS.map(({ icon: Icon, label, desc }, i) => (
                <div key={i} className="bg-white p-5 rounded-xl border border-gray-200">
                  <div className={`w-9 h-9 ${accentBg} rounded-lg flex items-center justify-center mb-3`}>
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                  <h4 className="font-bold text-gray-900 text-sm mb-1">{label}</h4>
                  <p className="text-gray-500 text-xs leading-relaxed">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Eco-Friendly Disposal */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="grid grid-cols-3 gap-4">
                {[
                  { value: '60%+', label: 'Items Donated or Recycled' },
                  { value: '0', label: 'Illegal Dump Sites Used' },
                  { value: '50', label: 'States Served' },
                ].map((stat, i) => (
                  <div key={i} className={`${accentBgLight} rounded-xl p-5 text-center border ${accentBorderLight}`}>
                    <div className={`text-2xl font-bold ${accentText} mb-1`}>{stat.value}</div>
                    <div className="text-gray-600 text-xs leading-tight">{stat.label}</div>
                  </div>
                ))}
              </div>
              <div className="mt-6 p-5 bg-gray-50 rounded-xl border border-gray-200">
                <p className="text-gray-600 text-sm leading-relaxed">
                  We partner with local charities, thrift stores, and certified recycling facilities to ensure your items are handled responsibly. Everything that can be reused, donated, or recycled gets a second life — keeping more out of the landfill.
                </p>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <div className={`inline-flex items-center ${accentBg} text-white text-sm font-bold px-4 py-2 rounded-full mb-4`}>
                <Recycle className="h-4 w-4 mr-2" />
                Eco-Friendly Disposal
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                We Dispose Responsibly
              </h2>
              <p className="text-lg text-gray-600 mb-4 leading-relaxed">
                We don't just haul and dump. Every {service.name.toLowerCase()} job is completed with environmental responsibility in mind. Items in good condition are donated to local charities and families in need first.
              </p>
              <ul className="space-y-3">
                {[
                  'Donate usable items to local charities & shelters',
                  'Recycle metals, electronics, and materials',
                  'Use only licensed disposal and recycling facilities',
                  'Minimize landfill waste on every job',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle className={`h-5 w-5 flex-shrink-0 mt-0.5 ${accentText}`} />
                    <span className="text-gray-700 text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold mb-3">What Our Customers Say</h2>
            <p className="text-gray-300 text-lg">4.9 stars from 1,000+ verified reviews nationwide</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex gap-0.5 mb-3">
                  {[...Array(t.rating)].map((_, j) => (
                    <Star key={j} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 text-sm leading-relaxed mb-4">"{t.text}"</p>
                <div>
                  <div className="font-semibold text-white text-sm">{t.name}</div>
                  <div className="text-gray-500 text-xs">{t.location}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <div className="inline-flex items-center gap-3 bg-gray-800 border border-gray-700 rounded-xl px-6 py-4">
              <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <span className="text-white font-bold text-lg">4.9 / 5.0</span>
              <span className="text-gray-400 text-sm">Based on 1,000+ reviews</span>
            </div>
          </div>
        </div>
      </section>

      {/* Booking CTA */}
      <BookingSection service={service} />

      {/* Top Cities */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
              {service.name} in Popular Cities
            </h2>
            <p className="text-gray-600 text-lg">
              Fast, affordable {service.name.toLowerCase()} service near you — same-day available in most areas
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-8">
            {TOP_CITIES.map((city) => (
              <Link
                key={city.slug}
                href={`/services/${service.slug}/${city.state}/${city.slug}`}
                className="p-3 bg-gray-50 border border-gray-200 hover:border-gray-400 rounded-lg transition-all group"
              >
                <div className="flex items-center gap-2">
                  <MapPin className={`h-4 w-4 ${accentText} flex-shrink-0`} />
                  <span className="font-medium text-gray-800 text-xs truncate">{city.name}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* States Grid */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
              {service.name} Service Areas
            </h2>
            <p className="text-gray-600 text-lg">
              Professional {service.name.toLowerCase()} in all 50 states. Select your state to find local service near you.
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
            {US_STATES.map((state) => (
              <Link
                key={state.slug}
                href={`/services/${service.slug}/${state.slug}`}
                className="p-3 bg-white border border-gray-200 hover:border-gray-400 rounded-lg transition-all group"
              >
                <div className="flex items-center gap-2">
                  <MapPin className={`h-4 w-4 ${accentText} flex-shrink-0`} />
                  <span className="font-medium text-gray-800 text-xs truncate">{state.name}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Related Services */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Other Services We Offer</h2>
            <p className="text-gray-600">Full-service junk removal for every need — one call, one team</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {relatedServices.map((s) => (
              <Link
                key={s.slug}
                href={`/services/${s.slug}`}
                className="group p-5 bg-gray-50 border border-gray-200 hover:border-gray-400 rounded-xl transition-all hover:shadow-md"
              >
                <h3 className={`font-bold text-gray-900 group-hover:${accentText} transition-colors mb-2`}>
                  {s.name}
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed line-clamp-2">{s.subheadline}</p>
                <div className={`flex items-center gap-1 mt-3 ${accentText} text-sm font-semibold`}>
                  Learn More <ArrowRight className="h-4 w-4" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-gray-600 text-lg">Common questions about our {service.name.toLowerCase()} service</p>
          </div>
          <div className="space-y-4">
            {service.faqs.map((faq, i) => (
              <div key={i} className="bg-white p-6 rounded-xl border border-gray-200 hover:shadow-md transition-shadow">
                <h3 className="text-lg font-bold text-gray-900 mb-3">{faq.question}</h3>
                <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className={`py-16 ${accentBg} text-white`}>
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Ready for Fast, Affordable {service.name}?
          </h2>
          <p className="text-xl opacity-90 mb-3">
            Book online in 60 seconds. Same-day service available nationwide.
          </p>
          <p className="opacity-75 mb-8 text-sm">
            Licensed & insured. Upfront pricing. No hidden fees. 10,000+ jobs completed.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/book"
              className="inline-flex items-center justify-center bg-white text-gray-900 px-10 py-4 rounded-lg font-bold transition-colors text-lg shadow-lg hover:bg-gray-100"
            >
              Get a Free Quote
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      </main>
      <Footer />
    </div>
  );
}

export const revalidate = 86400;
