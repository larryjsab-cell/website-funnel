'use client';

import { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { DollarSign, CalendarCheck, ArrowRight } from 'lucide-react';
import type { ServiceConfig } from '@/lib/services';
import {
  getSessionId,
  trackButtonClick,
  trackSessionEnd,
  trackStepUpdate,
  createStepDebouncer,
} from '@/lib/bookingTracking';

interface BookingSectionProps {
  cityName?: string;
  stateName?: string;
  service?: ServiceConfig;
}

const clamp = (v: number, min: number, max: number) => Math.min(Math.max(v, min), max);

const DEFAULT_STATS = [
  { value: '$99+', label: 'Starting Price' },
  { value: 'Same-Day', label: 'Service Available' },
];

function injectPreconnects() {
  const origins = [
    'https://fonts.goloadup.com',
    'https://d152brbz03jo7g.cloudfront.net',
    'https://js.stripe.com',
    'https://order.goloadup.com',
  ];
  origins.forEach((href) => {
    if (document.querySelector(`link[href="${href}"]`)) return;
    const link = document.createElement('link');
    link.rel = 'preconnect';
    link.href = href;
    link.crossOrigin = 'anonymous';
    document.head.appendChild(link);
  });
}

export default function BookingSection({ cityName, stateName, service }: BookingSectionProps) {
  const location = cityName && stateName
    ? `${cityName}, ${stateName}`
    : stateName ?? 'your area';

  const serviceName = service?.name ?? 'Junk Removal';
  const serviceDescription = service
    ? `We make ${service.name.toLowerCase()} simple, affordable, and eco-friendly. Our professional team handles everything from pickup to responsible disposal.`
    : 'We make junk removal simple, affordable, and eco-friendly. Our professional team handles everything from pickup to responsible disposal.';
  const pricingDesc = service
    ? `${service.name} starts at ${service.stats[1]?.value ?? '$99+'}. No hidden fees, no surprises. You'll know the exact cost before we arrive.`
    : "Starting at $99 for a minimum load. No hidden fees, no surprises. You'll know the exact cost before we arrive.";
  const displayStats = service ? service.stats.slice(0, 2) : DEFAULT_STATS;

  const [started, setStarted] = useState(false);
  const [iframeHeight, setIframeHeight] = useState(900);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const widgetStepRef = useRef(0);
  // stable ref for the step debouncer so it persists across renders
  const advanceStepRef = useRef<(() => void) | null>(null);

  const handleStart = () => {
    injectPreconnects();
    setStarted(true);
    trackButtonClick(window.location.href);
  };

  useEffect(() => {
    if (!started) return;

    advanceStepRef.current = createStepDebouncer(600, (step) => {
      widgetStepRef.current = step;
      trackStepUpdate(step);
    });

    const onLeave = () => trackSessionEnd(widgetStepRef.current);

    const onVisibility = () => {
      if (document.visibilityState === 'hidden') onLeave();
    };

    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('beforeunload', onLeave);
    window.addEventListener('pagehide', onLeave);

    const handleMessage = (event: MessageEvent) => {
      const isGoLoadUp =
        event.origin.includes('goloadup.com') ||
        event.origin.includes('goloadup.info') ||
        event.origin === window.location.origin;
      if (!isGoLoadUp) return;

      const data = event.data;
      if (!data || typeof data !== 'object') return;

      if (data.type === 'resizeIframe' || data.type === 'LOADUP_HEIGHT') {
        const h = Number(data.height);
        if (!Number.isNaN(h)) {
          const clamped = clamp(h, 400, 4000);
          setIframeHeight(clamped);
          // Each meaningful resize = user moved to next step
          advanceStepRef.current?.();
        }
        return;
      }

      if (data.type === 'completed_order') {
        if ((window as any).dataLayer) {
          (window as any).dataLayer.push({
            event: 'purchase',
            ecommerce: {
              transaction_id: data.order?.id || `ORDER_${Date.now()}`,
              value: data.total || 0,
              currency: 'USD',
              items: [{ item_name: serviceName, price: data.total || 0, quantity: 1 }],
            },
          });
        }

        const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
        if (supabaseUrl) {
          fetch(`${supabaseUrl}/functions/v1/log-completed-order`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              session_id: getSessionId(),
              order_id: data.order?.id || null,
              order_total: data.total || null,
              event_type: 'completed_order',
              occurred_at: new Date().toISOString(),
            }),
          }).catch(() => {});
        }
      }
    };

    window.addEventListener('message', handleMessage);

    return () => {
      window.removeEventListener('message', handleMessage);
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('beforeunload', onLeave);
      window.removeEventListener('pagehide', onLeave);
    };
  }, [started, serviceName]);

  return (
    <section className="py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left: info */}
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Why Choose Us in {location}?
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed">{serviceDescription}</p>
            </div>

            <Card className="p-6 border-2 border-green-700 bg-green-600">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-white/20 rounded-full p-3 flex-shrink-0">
                  <DollarSign className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Transparent Pricing</h3>
                  <p className="text-white/90">{pricingDesc}</p>
                </div>
              </div>
              <div className="bg-white rounded-lg p-4 mt-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  {displayStats.map((stat, i) => (
                    <div key={i}>
                      <div className="text-3xl font-bold text-green-600">{stat.value}</div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            <div className="bg-blue-600 border-2 border-blue-700 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-3">How It Works</h3>
              <ol className="space-y-3">
                {[
                  { label: 'Book Online:', desc: 'Get a free quote in minutes' },
                  { label: 'Schedule Pickup:', desc: 'Choose a time that works for you' },
                  { label: 'We Remove It:', desc: 'Our team handles everything' },
                  { label: 'Eco-Friendly Disposal:', desc: 'We donate or recycle when possible' },
                ].map((step, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="bg-white/20 text-white rounded-full w-7 h-7 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
                      {i + 1}
                    </div>
                    <div>
                      <span className="font-semibold text-white">{step.label}</span>
                      <span className="text-white/90"> {step.desc}</span>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          {/* Right: click-to-load widget */}
          <div className={started ? 'h-fit' : 'lg:sticky lg:top-4 h-fit'}>
            <div className="bg-white rounded-xl shadow-lg border-2 border-gray-200">
              {!started ? (
                <div className="p-8 text-center">
                  <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-5">
                    <CalendarCheck className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Get an Instant Quote
                  </h3>
                  <p className="text-gray-500 text-sm mb-6 leading-relaxed">
                    Click below to open the booking form and get your upfront price in under 2 minutes.
                  </p>
                  <button
                    onClick={handleStart}
                    className="inline-flex items-center justify-center gap-2 w-full bg-green-600 hover:bg-green-700 active:scale-95 text-white font-bold py-4 px-6 rounded-xl transition-all duration-200 text-lg shadow-lg shadow-green-600/20"
                  >
                    Start Booking — It's Free
                    <ArrowRight className="h-5 w-5" />
                  </button>
                  <p className="text-xs text-gray-600 mt-3">No credit card required</p>
                </div>
              ) : (
                <iframe
                  ref={iframeRef}
                  title="Booking Widget"
                  src="/booking-widget.html"
                  style={{ width: '100%', height: `${iframeHeight}px`, border: 0, display: 'block', scrollbarWidth: 'none' }}
                  sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
