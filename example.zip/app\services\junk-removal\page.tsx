import Link from 'next/link';
import Image from 'next/image';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import SchemaMarkup from '@/components/SchemaMarkup';
import { CircleCheck as CheckCircle, ArrowRight, Phone, MapPin, Star, Shield, Zap, Leaf, Clock, Truck, ChevronRight, DollarSign, Chrome as Home, Trash2, PackageOpen, Recycle, Award, ThumbsUp } from 'lucide-react';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Junk Removal Service Nationwide | Same-Day Hauling | Junk Removals 365',
  description:
    'Local junk haulers for full service removal, home cleanouts, and trash hauling. Same-day pickup available. Upfront pricing, licensed & insured crews.',
  keywords:
    'local junk haulers near me, full service junk removal, junk hauling services, junk pickup near me, free junk removal near me, trash removal, home cleanout services, junk removal near me, garage cleanout, junk hauling company',
  alternates: { canonical: 'https://junkremovals365.com/services/junk-removal' },
  openGraph: {
    title: 'Junk Removal Service Nationwide | Same-Day Hauling | Junk Removals 365',
    description:
      'Local junk haulers near you for full service junk removal, home cleanout services, and trash removal. Same-day available. Upfront pricing.',
    url: 'https://junkremovals365.com/services/junk-removal',
    siteName: 'Junk Removals 365',
    type: 'website',
    images: [{ url: 'https://junkremovals365.com/image.png' }],
  },
};

const BASE_URL = 'https://junkremovals365.com';

const FAQS = [
  {
    question: 'How do I find local junk haulers near me?',
    answer:
      'Junk Removals 365 has local crews operating across the United States. Book online to check real-time availability in your zip code. Same-day and next-day service is available in most cities.',
  },
  {
    question: 'How much does full service junk removal cost?',
    answer:
      'Full service junk removal starts at $99 and is priced by truck volume. A minimum load (about 1/8 of a truck) starts at $99. A full truck is typically $349–$449. You always receive an exact upfront quote — no surprise fees at the door.',
  },
  {
    question: 'Do you offer anything close to free junk removal near me?',
    answer:
      'While we are a professional paid service, items in good condition are donated — which reduces disposal costs and sometimes significantly lowers your total. We offer some of the most competitive pricing you will find. Get a free, no-obligation quote to see your exact price.',
  },
  {
    question: 'Do you provide home cleanout services?',
    answer:
      'Yes. Home cleanout services are one of our most popular offerings. Whether you are clearing an estate, preparing a property for sale, or decluttering after a move, our teams can clear an entire house in a single day. Volume discounts apply for whole-home hauls.',
  },
  {
    question: 'Can you handle trash removal and regular household junk?',
    answer:
      'Absolutely. We handle trash removal, old furniture, broken appliances, yard debris, and general household clutter. No sorting required — just point and we haul it.',
  },
  {
    question: 'Is same-day junk removal available?',
    answer:
      'Same-day service is available in most areas when you book before 2 PM. Call or book online and we will check real-time availability in your zip code.',
  },
  {
    question: 'Do I need to sort or bag my junk?',
    answer:
      'No. We take mixed loads as-is. Our team separates recyclables and donatables at our facility so you do not need to do any prep work beforehand.',
  },
  {
    question: 'What items can you not remove?',
    answer:
      'We cannot remove hazardous materials including paints, solvents, pesticides, asbestos, motor oil, or medical waste. For everything else — furniture, electronics, appliances, yard waste, construction debris — we are your team.',
  },
];

const TESTIMONIALS = [
  {
    name: 'Kevin B.',
    location: 'Houston, TX',
    rating: 5,
    text: 'I searched for local junk haulers near me and found Junk Removals 365. They cleared my entire garage the same day I called. Incredible team — fast, professional, and no hidden charges.',
  },
  {
    name: 'Maria C.',
    location: 'Phoenix, AZ',
    rating: 5,
    text: 'Used them for a full home cleanout after my mother passed. They handled everything with care and even donated her furniture to a local shelter. Truly full service junk removal.',
  },
  {
    name: 'Tony W.',
    location: 'Atlanta, GA',
    rating: 5,
    text: 'Needed trash removal and junk hauled from a basement renovation. They came next morning, cleared everything in two hours. Price was exactly what they quoted — zero surprises.',
  },
  {
    name: 'Brenda L.',
    location: 'Chicago, IL',
    rating: 5,
    text: 'I was looking for something close to free junk removal near me and honestly their pricing blew me away. Donated my old couch and dresser, so I basically only paid for the debris. Highly recommend.',
  },
  {
    name: 'James P.',
    location: 'Miami, FL',
    rating: 5,
    text: 'Home cleanout service was flawless. Three-bedroom house cleared in one day for a fair flat rate. Crew was respectful, efficient, and on time. Will use again for our rental property.',
  },
  {
    name: 'Samantha R.',
    location: 'Denver, CO',
    rating: 4,
    text: 'Good experience overall. They picked up yard debris and old appliances from my backyard quickly. Good communication and the price was fair.',
  },
];

const WHAT_WE_REMOVE = [
  { icon: Home, label: 'Full Home Cleanout Services', desc: 'Entire house cleared in one day for moves, estates, or sales prep.' },
  { icon: PackageOpen, label: 'Garage & Basement Cleanouts', desc: 'Years of clutter gone in a single haul — no sorting needed.' },
  { icon: Trash2, label: 'Trash & Debris Removal', desc: 'Household trash, junk bags, and debris hauled fast.' },
  { icon: Truck, label: 'Furniture & Appliance Hauling', desc: 'Couches, dressers, fridges, washers — all sizes handled.' },
  { icon: Leaf, label: 'Yard Waste & Landscaping Debris', desc: 'Branches, soil, mulch, fencing, and green waste cleared.' },
  { icon: Recycle, label: 'Construction & Renovation Debris', desc: 'Drywall, lumber, tiles, and mixed construction waste hauled.' },
  { icon: Award, label: 'Estate & Hoarder Cleanouts', desc: 'Compassionate, professional whole-property cleanouts.' },
  { icon: PackageOpen, label: 'Commercial Junk Removal', desc: 'Office furniture, warehouse clutter, and business hauls.' },
];

const BENEFITS = [
  {
    icon: MapPin,
    title: 'Truly Local Junk Haulers',
    desc: 'We staff vetted local crews in your area — faster response, real accountability, and crews that know your neighborhood.',
  },
  {
    icon: Trash2,
    title: 'No Sorting, No Prep',
    desc: 'Mixed loads taken as-is. We separate recyclables and donatables so you never have to lift a finger before we arrive.',
  },
  {
    icon: Clock,
    title: 'Same-Day Availability',
    desc: 'Book before 2 PM and a crew can often be at your door the same day. No waiting weeks for an appointment.',
  },
  {
    icon: DollarSign,
    title: 'Upfront, Transparent Pricing',
    desc: 'The quote you get is the price you pay. No fuel surcharges, no disposal add-ons, no surprise labor fees.',
  },
  {
    icon: Recycle,
    title: 'Eco-Friendly Disposal',
    desc: 'We donate usable items to local charities and recycle metals and materials — significantly reducing landfill waste.',
  },
  {
    icon: Shield,
    title: 'Licensed & Fully Insured',
    desc: 'Every crew is licensed, insured, and background-checked. Your home and belongings are protected throughout.',
  },
];

const TOP_CITIES = [
  { name: 'Los Angeles, CA', state: 'california', slug: 'los-angeles' },
  { name: 'New York City, NY', state: 'new-york', slug: 'new-york-city' },
  { name: 'Houston, TX', state: 'texas', slug: 'houston' },
  { name: 'Phoenix, AZ', state: 'arizona', slug: 'phoenix' },
  { name: 'Chicago, IL', state: 'illinois', slug: 'chicago' },
  { name: 'Philadelphia, PA', state: 'pennsylvania', slug: 'philadelphia' },
  { name: 'San Antonio, TX', state: 'texas', slug: 'san-antonio' },
  { name: 'San Diego, CA', state: 'california', slug: 'san-diego' },
  { name: 'Dallas, TX', state: 'texas', slug: 'dallas' },
  { name: 'Miami, FL', state: 'florida', slug: 'miami' },
  { name: 'Atlanta, GA', state: 'georgia', slug: 'atlanta' },
  { name: 'Denver, CO', state: 'colorado', slug: 'denver' },
  { name: 'Seattle, WA', state: 'washington', slug: 'seattle' },
  { name: 'Nashville, TN', state: 'tennessee', slug: 'nashville' },
  { name: 'Portland, OR', state: 'oregon', slug: 'portland' },
  { name: 'Las Vegas, NV', state: 'nevada', slug: 'las-vegas' },
  { name: 'Austin, TX', state: 'texas', slug: 'austin' },
  { name: 'Charlotte, NC', state: 'north-carolina', slug: 'charlotte' },
];

const US_STATES = [
  { name: 'Alabama', slug: 'alabama' }, { name: 'Alaska', slug: 'alaska' }, { name: 'Arizona', slug: 'arizona' },
  { name: 'Arkansas', slug: 'arkansas' }, { name: 'California', slug: 'california' }, { name: 'Colorado', slug: 'colorado' },
  { name: 'Connecticut', slug: 'connecticut' }, { name: 'Delaware', slug: 'delaware' }, { name: 'Florida', slug: 'florida' },
  { name: 'Georgia', slug: 'georgia' }, { name: 'Hawaii', slug: 'hawaii' }, { name: 'Idaho', slug: 'idaho' },
  { name: 'Illinois', slug: 'illinois' }, { name: 'Indiana', slug: 'indiana' }, { name: 'Iowa', slug: 'iowa' },
  { name: 'Kansas', slug: 'kansas' }, { name: 'Kentucky', slug: 'kentucky' }, { name: 'Louisiana', slug: 'louisiana' },
  { name: 'Maine', slug: 'maine' }, { name: 'Maryland', slug: 'maryland' }, { name: 'Massachusetts', slug: 'massachusetts' },
  { name: 'Michigan', slug: 'michigan' }, { name: 'Minnesota', slug: 'minnesota' }, { name: 'Mississippi', slug: 'mississippi' },
  { name: 'Missouri', slug: 'missouri' }, { name: 'Montana', slug: 'montana' }, { name: 'Nebraska', slug: 'nebraska' },
  { name: 'Nevada', slug: 'nevada' }, { name: 'New Hampshire', slug: 'new-hampshire' }, { name: 'New Jersey', slug: 'new-jersey' },
  { name: 'New Mexico', slug: 'new-mexico' }, { name: 'New York', slug: 'new-york' }, { name: 'North Carolina', slug: 'north-carolina' },
  { name: 'North Dakota', slug: 'north-dakota' }, { name: 'Ohio', slug: 'ohio' }, { name: 'Oklahoma', slug: 'oklahoma' },
  { name: 'Oregon', slug: 'oregon' }, { name: 'Pennsylvania', slug: 'pennsylvania' }, { name: 'Rhode Island', slug: 'rhode-island' },
  { name: 'South Carolina', slug: 'south-carolina' }, { name: 'South Dakota', slug: 'south-dakota' }, { name: 'Tennessee', slug: 'tennessee' },
  { name: 'Texas', slug: 'texas' }, { name: 'Utah', slug: 'utah' }, { name: 'Vermont', slug: 'vermont' },
  { name: 'Virginia', slug: 'virginia' }, { name: 'Washington', slug: 'washington' }, { name: 'Washington DC', slug: 'washington-dc' },
  { name: 'West Virginia', slug: 'west-virginia' }, { name: 'Wisconsin', slug: 'wisconsin' }, { name: 'Wyoming', slug: 'wyoming' },
];

const RELATED_SERVICES = [
  { name: 'Furniture Removal', slug: 'furniture-removal', desc: 'Couches, dressers, beds, and full room clearouts.' },
  { name: 'Appliance Removal', slug: 'appliance-removal', desc: 'Fridges, washers, dryers, stoves safely hauled away.' },
  { name: 'Mattress Removal', slug: 'mattress-removal', desc: 'Any size mattress recycled or disposed eco-friendly.' },
  { name: 'Couch Removal', slug: 'couch-removal', desc: 'Same-day sofa and sectional removal from any floor.' },
];

export default function JunkRemovalPage() {
  const pageUrl = `${BASE_URL}/services/junk-removal`;

  return (
    <div className="min-h-screen bg-white">
      {/* Schema — FAQ */}
      <SchemaMarkup
        type="faq"
        id="faq-junk-removal"
        data={{ faqs: FAQS }}
      />
      {/* Schema — LocalBusiness */}
      <SchemaMarkup
        type="localBusiness"
        id="lb-junk-removal"
        data={{
          description:
            'Professional junk hauling company near you — home cleanout services, trash removal, furniture and appliance hauling. Same-day bulk item pickup available.',
          url: pageUrl,
        }}
      />
      {/* Schema — Service */}
      <SchemaMarkup
        type="service"
        id="svc-junk-removal"
        data={{
          serviceType: 'Full Service Junk Removal',
          name: 'Full Service Junk Removal',
          description:
            'Junk hauling professionals near you for home cleanout services, debris hauling, trash removal, and garage cleanouts. Same-day bulk item pickup available.',
          areaServed: 'United States',
        }}
      />
      {/* Schema — Breadcrumb */}
      <SchemaMarkup
        type="breadcrumb"
        id="bc-junk-removal"
        data={{
          breadcrumbs: [
            { name: 'Home', url: BASE_URL },
            { name: 'Services', url: `${BASE_URL}/services` },
            { name: 'Junk Removal', url: pageUrl },
          ],
        }}
      />

      <Header />

      <main>
        {/* Breadcrumb nav */}
        <nav className="bg-gray-50 border-b border-gray-200 py-3">
          <div className="max-w-7xl mx-auto px-4">
            <ol className="flex items-center gap-2 text-sm text-gray-500 flex-wrap">
              <li><Link href="/" className="hover:text-gray-800 transition-colors">Home</Link></li>
              <li><ChevronRight className="h-3 w-3" /></li>
              <li><Link href="/services" className="hover:text-gray-800 transition-colors">Services</Link></li>
              <li><ChevronRight className="h-3 w-3" /></li>
              <li className="text-gray-900 font-medium">Junk Removal</li>
            </ol>
          </div>
        </nav>

        {/* ─── HERO ─── */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src="/images/junk_removal.webp"
              alt="Professional removal crew loading a truck for a home cleanout service"
              fill
              priority
              sizes="100vw"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-gray-950/95 via-gray-900/88 to-gray-900/60" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4">
            <div className="max-w-3xl">
              {/* Trust pills */}
              <div className="flex flex-wrap gap-2 mb-6">
                {['Licensed & Insured', 'Same-Day Service', 'Free Quote', 'No Hidden Fees'].map((badge) => (
                  <span
                    key={badge}
                    className="inline-flex items-center gap-1.5 bg-white/15 border border-white/30 text-white text-xs font-semibold px-3 py-1.5 rounded-full"
                  >
                    <CheckCircle className="h-3.5 w-3.5" />
                    {badge}
                  </span>
                ))}
              </div>

              <h1 className="text-4xl lg:text-6xl font-bold text-white mb-5 leading-tight">
                Junk Removal Service Near You
              </h1>

              <p className="text-xl text-gray-200 mb-3 leading-relaxed">
                Professional junk hauling for homes and businesses — furniture, appliances, trash,
                garage cleanouts, and complete property cleanout services.
              </p>
              <p className="text-gray-300 mb-8 leading-relaxed">
                Our removal crews handle same-day bulk item pickup with upfront pricing and eco-friendly
                disposal. No sorting, no heavy lifting — just point and we haul it.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <Link
                  href="/book"
                  className="inline-flex items-center justify-center bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-bold transition-colors text-lg shadow-lg"
                >
                  Get a Free Quote
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-5">
                {[
                  { value: '$99+', label: 'Starting Price' },
                  { value: '5,000+', label: 'Loads Hauled' },
                  { value: '4.8★', label: 'Average Rating' },
                  { value: 'Same-Day', label: 'Available' },
                ].map((stat, i) => (
                  <div key={i} className="text-center">
                    <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                    <div className="text-gray-300 text-sm">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ─── INTRO + WHAT WE REMOVE ─── */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                  Our Junk Removal Service — Every Job, Every Item
                </h2>
                <p className="text-lg text-gray-600 mb-5 leading-relaxed">
                  Searching for <strong>local junk haulers near me</strong>? You found the right team.
                  Junk Removals 365 is a professional junk hauling company with vetted removal crews
                  operating across the country. We handle everything from a single{' '}
                  <Link href="/services/furniture-removal" className="text-green-700 font-semibold hover:underline">furniture pickup</Link>{' '}
                  to a complete <strong>home cleanout service</strong> — all in one visit, nothing to sort beforehand.
                </p>
                <p className="text-gray-600 mb-5 leading-relaxed">
                  Whether you need <strong>trash removal</strong> after a renovation, a garage cleanout before
                  a move, or a property cleanout team for an estate, our hauling specialists show up on
                  time, work fast, and leave the space swept clean. We believe debris hauling should be
                  stress-free from the first call to the final load.
                </p>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Many customers searching for <strong>free junk removal near me</strong> are surprised by
                  how affordable our <strong>junk pickup</strong> service is — especially when items can be
                  donated, which reduces disposal costs. Get a free, no-obligation quote and see your
                  exact price before our crew ever arrives.
                </p>
                <div className="flex flex-wrap gap-3">
                  {[
                    { icon: Shield, text: 'Licensed & Insured' },
                    { icon: Zap, text: 'Same-Day Available' },
                    { icon: ThumbsUp, text: 'Upfront Pricing' },
                    { icon: Leaf, text: 'Eco-Friendly Disposal' },
                  ].map(({ icon: Icon, text }) => (
                    <span
                      key={text}
                      className="inline-flex items-center gap-2 bg-green-50 text-green-700 text-sm font-semibold px-4 py-2 rounded-full border border-green-200"
                    >
                      <Icon className="h-4 w-4" />
                      {text}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-5">What We Haul Away</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {WHAT_WE_REMOVE.map((item, i) => {
                    const Icon = item.icon;
                    return (
                      <div
                        key={i}
                        className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl border border-gray-100"
                      >
                        <div className="bg-green-600 p-2 rounded-lg flex-shrink-0">
                          <Icon className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900 text-sm mb-0.5">{item.label}</div>
                          <div className="text-gray-500 text-xs leading-relaxed">{item.desc}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── HOME CLEANOUT SERVICES FEATURE SECTION ─── */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-flex items-center bg-green-600 text-white text-sm font-bold px-4 py-2 rounded-full mb-5">
                  <Home className="h-4 w-4 mr-2" />
                  Home Cleanout Services
                </div>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                  Complete Home Cleanout Services — One Call, One Day
                </h2>
                <p className="text-lg text-gray-600 mb-5 leading-relaxed">
                  Our <strong>home cleanout services</strong> are designed to clear an entire property in a
                  single visit — whether you are managing an estate, preparing a home for sale, or finally
                  tackling years of accumulated clutter. Our crews can handle a three-bedroom house in a
                  single day.
                </p>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  We work room by room, hauling out furniture, appliances, trash, clothing, boxes, and
                  miscellaneous debris. Usable items go to local charities. Everything else is recycled
                  or responsibly disposed of. You get a completely empty, swept-clean space when we leave.
                </p>
                <ul className="space-y-3 mb-8">
                  {[
                    'Estate cleanouts after a loss',
                    'Pre-sale home staging cleanouts',
                    'Move-out and relocation hauls',
                    'Hoarder property cleanouts',
                    'Rental property turnover cleanouts',
                    'Foreclosure and bank-owned cleanouts',
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  href="/contact"
                  className="inline-flex items-center bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-bold transition-colors"
                >
                  Schedule a Home Cleanout
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>

              <div className="space-y-4">
                <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
                  <h3 className="font-bold text-gray-900 text-lg mb-2">How is a home cleanout priced?</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    Home cleanouts are priced by truck volume — the space your items take up in our truck.
                    Studio and one-bedroom hauls typically run $199–$349. Full three- and four-bedroom
                    homes typically run $449–$699. You always get an exact quote on-site before we start.
                  </p>
                </div>
                <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
                  <h3 className="font-bold text-gray-900 text-lg mb-2">Do we need to be home during the cleanout?</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    Someone 18 or older needs to be present to grant access and point out what goes. You
                    do not need to help move or carry anything — that is entirely our job.
                  </p>
                </div>
                <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
                  <h3 className="font-bold text-gray-900 text-lg mb-2">What about items we want to keep?</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    Before we begin, walk us through what stays and what goes. We only remove what you
                    authorize. Any confusion is resolved with you before items leave the property.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── PRICING / FREE JUNK REMOVAL SECTION ─── */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                  The Closest Thing to Free Junk Removal Near You
                </h2>
                <p className="text-lg text-gray-600 mb-5 leading-relaxed">
                  Many people searching for <strong>free junk removal near me</strong> are really looking
                  for affordable, no-hassle pickup — and that is exactly what we provide. While we are a
                  professional paid service, here is why our pricing often surprises people:
                </p>
                <ul className="space-y-4 mb-6">
                  {[
                    { title: 'Donation reduces your cost', desc: 'Items in good condition go to local charities. This reduces the weight and volume we dispose of — which lowers your price.' },
                    { title: 'No subscription, no recurring fees', desc: 'You pay once, for exactly what you need hauled. No monthly service contracts.' },
                    { title: 'Volume-based pricing is fair', desc: 'A small pile costs a fraction of a full truck. You only pay for the space your items take up.' },
                    { title: 'Free quote, no obligation', desc: 'Get an exact price before we ever arrive. If it does not work for your budget, you owe nothing.' },
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-3 bg-green-50 rounded-xl p-4 border border-green-100">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-gray-900 text-sm">{item.title}: </span>
                        <span className="text-gray-600 text-sm">{item.desc}</span>
                      </div>
                    </li>
                  ))}
                </ul>
                <Link
                  href="/contact"
                  className="inline-flex items-center bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-bold transition-colors"
                >
                  Get Your Free Quote Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-5">Typical Price Ranges</h3>
                <div className="space-y-3">
                  {[
                    { label: 'Single item (chair, small appliance)', price: '$99 – $139' },
                    { label: 'Small load (1/4 truck)', price: '$139 – $219' },
                    { label: 'Medium load (1/2 truck)', price: '$219 – $329' },
                    { label: 'Large load (3/4 truck)', price: '$329 – $429' },
                    { label: 'Full truck load', price: '$399 – $499' },
                    { label: 'Home cleanout (2–3 beds)', price: '$449 – $699' },
                  ].map((row, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-100"
                    >
                      <span className="text-gray-700 text-sm font-medium">{row.label}</span>
                      <span className="text-green-700 font-bold text-sm whitespace-nowrap ml-4">{row.price}</span>
                    </div>
                  ))}
                </div>
                <p className="text-gray-400 text-xs mt-3">
                  * All pricing is approximate. You receive an exact upfront quote before any work begins.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ─── WHY CHOOSE US ─── */}
        <section className="py-16 bg-green-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                Why Choose Junk Removals 365?
              </h2>
              <p className="text-lg text-gray-600">
                A junk hauling company people trust — fast, affordable, and eco-friendly on every job
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {BENEFITS.map((b, i) => {
                const Icon = b.icon;
                return (
                  <div key={i} className="bg-white p-6 rounded-xl border border-green-100 shadow-sm hover:shadow-md transition-shadow">
                    <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                    <h3 className="font-bold text-gray-900 mb-2">{b.title}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{b.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ─── HOW IT WORKS ─── */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                How Our Junk Hauling Service Works
              </h2>
              <p className="text-lg text-gray-600">Book to done in 4 simple steps — as fast as today</p>
            </div>
            <div className="grid md:grid-cols-4 gap-6">
              {[
                { title: 'Get a Free Quote', desc: 'Describe your load online or by phone. Receive an upfront price with zero obligation.' },
                { title: 'Your Crew Shows Up On Time', desc: 'Your assigned removal specialists arrive in a marked truck within your scheduled window, ready to work.' },
                { title: 'We Load Every Last Piece', desc: 'You just point — we carry, load, and haul everything out without you lifting a finger.' },
                { title: 'Sorted, Donated & Recycled', desc: 'We donate usable items, recycle metals and materials, and minimize landfill waste.' },
              ].map((step, i) => (
                <div key={i} className="relative">
                  <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 h-full">
                    <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-bold text-lg mb-4">
                      {i + 1}
                    </div>
                    <h3 className="font-bold text-gray-900 mb-2">{step.title}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{step.desc}</p>
                  </div>
                  {i < 3 && (
                    <ArrowRight className="hidden md:block absolute -right-3 top-1/2 -translate-y-1/2 h-6 w-6 text-gray-300 z-10" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ─── TESTIMONIALS ─── */}
        <section className="py-16 bg-gray-900 text-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold mb-3">
                What Customers Say About Our Hauling Crews
              </h2>
              <p className="text-gray-300 text-lg">4.8 stars from 500+ verified customer reviews</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {TESTIMONIALS.map((t, i) => (
                <div key={i} className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                  <div className="flex gap-0.5 mb-3">
                    {[...Array(t.rating)].map((_, j) => (
                      <Star key={j} className="h-4 w-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-300 text-sm leading-relaxed mb-4">"{t.text}"</p>
                  <div>
                    <div className="font-semibold text-white text-sm">{t.name}</div>
                    <div className="text-gray-500 text-xs">{t.location}</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="text-center mt-10">
              <div className="inline-flex items-center gap-3 bg-gray-800 border border-gray-700 rounded-xl px-6 py-4">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <span className="text-white font-bold text-lg">4.8 / 5.0</span>
                <span className="text-gray-400 text-sm">Based on 500+ reviews</span>
              </div>
            </div>
          </div>
        </section>

        {/* ─── BOOK CTA ─── */}
        <section className="py-16 bg-green-600 text-white">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Ready for Same-Day Junk Removal Near You?
            </h2>
            <p className="text-xl opacity-90 mb-3">
              Book in 60 seconds. Local haulers. Upfront pricing. No hidden fees.
            </p>
            <p className="opacity-80 mb-8 text-sm">
              Furniture, appliances, yard debris, home cleanouts, and more — handled by vetted hauling specialists.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/contact"
                className="inline-flex items-center justify-center bg-white text-green-800 px-10 py-4 rounded-lg font-bold transition-colors text-lg shadow-lg hover:bg-gray-100"
              >
                Get a Free Quote
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
          </div>
        </section>

        {/* ─── FAQ ─── */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Junk Removal FAQs
              </h2>
              <p className="text-gray-600 text-lg">
                Common questions about local junk hauling, pricing, and home cleanout services
              </p>
            </div>
            <div className="space-y-4">
              {FAQS.map((faq, i) => (
                <div key={i} className="bg-white p-6 rounded-xl border border-gray-200 hover:shadow-md transition-shadow">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{faq.question}</h3>
                  <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ─── TOP CITIES ─── */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                Junk Removal in Popular Cities Near You
              </h2>
              <p className="text-gray-600 text-lg">
                Same-day bulk item pickup and junk hauling services available in hundreds of cities
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-8">
              {TOP_CITIES.map((city) => (
                <Link
                  key={city.slug}
                  href={`/services/junk-removal/${city.state}/${city.slug}`}
                  className="p-3 bg-gray-50 border border-gray-200 hover:border-green-500 hover:bg-green-50 rounded-lg transition-all group"
                >
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-green-600 flex-shrink-0" />
                    <span className="font-medium text-gray-800 text-xs truncate">{city.name}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* ─── STATES GRID ─── */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                Junk Removal Service Areas — All 50 States
              </h2>
              <p className="text-gray-600 text-lg">
                Select your state to find removal crews and junk pickup availability near you.
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
              {US_STATES.map((state) => (
                <Link
                  key={state.slug}
                  href={`/services/junk-removal/${state.slug}`}
                  className="p-3 bg-white border border-gray-200 hover:border-green-500 hover:bg-green-50 rounded-lg transition-all group"
                >
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-green-600 flex-shrink-0" />
                    <span className="font-medium text-gray-800 text-xs truncate">{state.name}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* ─── RELATED SERVICES (Internal Links) ─── */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-gray-900 mb-3">
                Other Removal Services We Offer
              </h2>
              <p className="text-gray-600">
                One hauling company for every need — bulk item pickup, specialized removals, and full cleanouts
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {RELATED_SERVICES.map((s) => (
                <Link
                  key={s.slug}
                  href={`/services/${s.slug}`}
                  className="group p-5 bg-gray-50 border border-gray-200 hover:border-green-400 rounded-xl transition-all hover:shadow-md"
                >
                  <h3 className="font-bold text-gray-900 group-hover:text-green-700 transition-colors mb-2">
                    {s.name}
                  </h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{s.desc}</p>
                  <div className="flex items-center gap-1 mt-3 text-green-600 text-sm font-semibold">
                    Learn More <ArrowRight className="h-4 w-4" />
                  </div>
                </Link>
              ))}
            </div>

            {/* Internal links prose block */}
            <div className="mt-12 bg-gray-50 rounded-2xl p-8 border border-gray-200">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                More Ways Our Hauling Specialists Can Help
              </h3>
              <p className="text-gray-600 leading-relaxed mb-4">
                Junk Removals 365 is a full service hauling company covering every type of removal job.
                Need to clear out a specific item? Our dedicated service pages cover{' '}
                <Link href="/services/furniture-removal" className="text-green-700 font-semibold hover:underline">
                  furniture removal
                </Link>
                ,{' '}
                <Link href="/services/appliance-removal" className="text-green-700 font-semibold hover:underline">
                  appliance hauling
                </Link>
                ,{' '}
                <Link href="/services/mattress-removal" className="text-green-700 font-semibold hover:underline">
                  mattress disposal
                </Link>
                , and{' '}
                <Link href="/services/couch-removal" className="text-green-700 font-semibold hover:underline">
                  couch and sofa pickup
                </Link>
                — all with upfront pricing, vetted crews, and eco-friendly disposal.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Ready to schedule your pickup? Visit our{' '}
                <Link href="/contact" className="text-green-700 font-semibold hover:underline">
                  contact page
                </Link>{' '}
                for a free quote, or{' '}
                <Link href="/how-it-works" className="text-green-700 font-semibold hover:underline">
                  see how our process works
                </Link>{' '}
                before you book. Same-day junk pickup available in most areas.
              </p>
            </div>
          </div>
        </section>

        {/* ─── FINAL CTA ─── */}
        <section className="py-16 bg-gray-900 text-white">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Got Junk? Our Removal Crews Are Ready.
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Junk hauling services. Home cleanout specialists. Trash removal. Bulk item pickup.
              One call. Upfront pricing. Same-day available.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/contact"
                className="inline-flex items-center justify-center bg-green-600 hover:bg-green-700 text-white px-10 py-4 rounded-lg font-bold transition-colors text-lg shadow-lg"
              >
                Book Your Pickup
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                href="/how-it-works"
                className="inline-flex items-center justify-center border-2 border-white text-white px-10 py-4 rounded-lg font-bold hover:bg-white/10 transition-colors text-lg gap-2"
              >
                How It Works
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
