import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, CircleCheck as CheckCircle, Shield, Zap, Users, Leaf, Clock, TrendingUp } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HowItWorks from '@/components/HowItWorks';
import BookingSection from '@/components/BookingSection';
import { createServerClient } from '@/lib/supabaseServer';
import { getService, SERVICE_LIST } from '@/lib/services';
import { getTopCities } from '@/lib/topCities';
import ServiceStatePageClient from './ServiceStatePageClient';
import LazyMap from '@/components/LazyMap';
import type { Metadata } from 'next';
import SchemaMarkup from '@/components/SchemaMarkup';

const STATE_NAMES: Record<string, string> = {
  alabama: 'Alabama', alaska: 'Alaska', arizona: 'Arizona', arkansas: 'Arkansas',
  california: 'California', colorado: 'Colorado', connecticut: 'Connecticut', delaware: 'Delaware',
  florida: 'Florida', georgia: 'Georgia', hawaii: 'Hawaii', idaho: 'Idaho', illinois: 'Illinois',
  indiana: 'Indiana', iowa: 'Iowa', kansas: 'Kansas', kentucky: 'Kentucky', louisiana: 'Louisiana',
  maine: 'Maine', maryland: 'Maryland', massachusetts: 'Massachusetts', michigan: 'Michigan',
  minnesota: 'Minnesota', mississippi: 'Mississippi', missouri: 'Missouri', montana: 'Montana',
  nebraska: 'Nebraska', nevada: 'Nevada', 'new-hampshire': 'New Hampshire', 'new-jersey': 'New Jersey',
  'new-mexico': 'New Mexico', 'new-york': 'New York', 'north-carolina': 'North Carolina',
  'north-dakota': 'North Dakota', ohio: 'Ohio', oklahoma: 'Oklahoma', oregon: 'Oregon',
  pennsylvania: 'Pennsylvania', 'rhode-island': 'Rhode Island', 'south-carolina': 'South Carolina',
  'south-dakota': 'South Dakota', tennessee: 'Tennessee', texas: 'Texas', utah: 'Utah',
  vermont: 'Vermont', virginia: 'Virginia', washington: 'Washington', 'washington-dc': 'Washington DC',
  'west-virginia': 'West Virginia', wisconsin: 'Wisconsin', wyoming: 'Wyoming',
};

const STATE_COORDS: Record<string, { lat: number; lng: number; zoom: number }> = {
  alabama: { lat: 32.806671, lng: -86.79113, zoom: 7 },
  alaska: { lat: 64.200841, lng: -149.493673, zoom: 4 },
  arizona: { lat: 33.729759, lng: -111.431221, zoom: 7 },
  arkansas: { lat: 34.969704, lng: -92.373123, zoom: 7 },
  california: { lat: 36.778259, lng: -119.417931, zoom: 6 },
  colorado: { lat: 39.059811, lng: -105.311104, zoom: 7 },
  connecticut: { lat: 41.597782, lng: -72.755371, zoom: 8 },
  delaware: { lat: 39.318523, lng: -75.507141, zoom: 8 },
  florida: { lat: 27.766279, lng: -81.686783, zoom: 7 },
  georgia: { lat: 33.040619, lng: -83.643074, zoom: 7 },
  hawaii: { lat: 20.593684, lng: -157.498337, zoom: 7 },
  idaho: { lat: 44.240459, lng: -114.478828, zoom: 6 },
  illinois: { lat: 40.349457, lng: -88.986137, zoom: 7 },
  indiana: { lat: 39.849426, lng: -86.258278, zoom: 7 },
  iowa: { lat: 42.011539, lng: -93.210526, zoom: 7 },
  kansas: { lat: 38.5266, lng: -96.726486, zoom: 7 },
  kentucky: { lat: 37.66814, lng: -84.670067, zoom: 7 },
  louisiana: { lat: 31.169546, lng: -91.867805, zoom: 7 },
  maine: { lat: 44.693947, lng: -69.381927, zoom: 7 },
  maryland: { lat: 39.063946, lng: -76.802101, zoom: 8 },
  massachusetts: { lat: 42.230171, lng: -71.530106, zoom: 8 },
  michigan: { lat: 44.314844, lng: -85.602364, zoom: 6 },
  minnesota: { lat: 45.694454, lng: -93.900192, zoom: 6 },
  mississippi: { lat: 32.741646, lng: -89.678696, zoom: 7 },
  missouri: { lat: 38.456085, lng: -92.288368, zoom: 7 },
  montana: { lat: 46.921925, lng: -110.454353, zoom: 6 },
  nebraska: { lat: 41.12537, lng: -98.268082, zoom: 7 },
  nevada: { lat: 38.313515, lng: -117.055374, zoom: 6 },
  'new-hampshire': { lat: 43.452492, lng: -71.563896, zoom: 7 },
  'new-jersey': { lat: 40.298904, lng: -74.521011, zoom: 8 },
  'new-mexico': { lat: 34.840515, lng: -106.248482, zoom: 6 },
  'new-york': { lat: 42.165726, lng: -74.948051, zoom: 7 },
  'north-carolina': { lat: 35.630066, lng: -79.806419, zoom: 7 },
  'north-dakota': { lat: 47.528912, lng: -99.784012, zoom: 6 },
  ohio: { lat: 40.388783, lng: -82.764915, zoom: 7 },
  oklahoma: { lat: 35.565342, lng: -96.928917, zoom: 7 },
  oregon: { lat: 44.572021, lng: -122.070938, zoom: 7 },
  pennsylvania: { lat: 40.590752, lng: -77.209755, zoom: 7 },
  'rhode-island': { lat: 41.680893, lng: -71.51178, zoom: 9 },
  'south-carolina': { lat: 33.856892, lng: -80.945007, zoom: 7 },
  'south-dakota': { lat: 44.299782, lng: -99.438828, zoom: 7 },
  tennessee: { lat: 35.747845, lng: -86.692345, zoom: 7 },
  texas: { lat: 31.054487, lng: -97.563461, zoom: 6 },
  utah: { lat: 40.150032, lng: -111.862434, zoom: 7 },
  vermont: { lat: 44.045876, lng: -72.710686, zoom: 8 },
  virginia: { lat: 37.769337, lng: -78.169968, zoom: 7 },
  washington: { lat: 47.400902, lng: -121.490494, zoom: 7 },
  'washington-dc': { lat: 38.907192, lng: -77.036871, zoom: 11 },
  'west-virginia': { lat: 38.491226, lng: -80.954453, zoom: 7 },
  wisconsin: { lat: 44.268543, lng: -89.616508, zoom: 7 },
  wyoming: { lat: 42.755966, lng: -107.30249, zoom: 7 },
};

function getWhyUsItems(serviceName: string) {
  return [
    { icon: Shield, title: 'Licensed & Insured', description: 'Fully licensed and insured professionals you can trust' },
    { icon: Zap, title: 'Same-Day Service', description: `Fast response times with same-day ${serviceName.toLowerCase()} available` },
    { icon: Leaf, title: 'Eco-Friendly Disposal', description: `Responsible recycling and donation after every ${serviceName.toLowerCase()} job` },
    { icon: TrendingUp, title: 'Transparent Pricing', description: 'No hidden fees — you know the cost upfront' },
    { icon: Users, title: 'Expert Team', description: `Trained professionals who handle every ${serviceName.toLowerCase()} with care` },
    { icon: Clock, title: '24/7 Booking', description: 'Book online anytime that works for your schedule' },
  ];
}

const accentBgMap: Record<string, string> = {
  green: 'bg-green-600', blue: 'bg-blue-600', orange: 'bg-orange-600', teal: 'bg-teal-600', red: 'bg-red-600',
};
const accentTextMap: Record<string, string> = {
  green: 'text-green-600', blue: 'text-blue-600', orange: 'text-orange-600', teal: 'text-teal-600', red: 'text-red-600',
};
const accentHoverMap: Record<string, string> = {
  green: 'hover:bg-green-700', blue: 'hover:bg-blue-700', orange: 'hover:bg-orange-700', teal: 'hover:bg-teal-700', red: 'hover:bg-red-700',
};

export async function generateStaticParams() {
  const params: { service: string; state: string }[] = [];
  for (const service of SERVICE_LIST) {
    for (const state of Object.keys(STATE_NAMES)) {
      params.push({ service: service.slug, state });
    }
  }
  return params;
}

export async function generateMetadata({ params }: { params: { service: string; state: string } }): Promise<Metadata> {
  const service = getService(params.service);
  const stateName = STATE_NAMES[params.state];
  if (!service || !stateName) return { title: 'Not Found' };

  const pageData = await getStatePageData(stateName, params.service);

  const title = `${service.name} in ${stateName} | Professional Service | Junk Removals 365`;
  const description = pageData?.meta_description ||
    `Professional ${service.name.toLowerCase()} in ${stateName}. Licensed, insured team serves all major cities. Same-day service available. Book online today.`;

  return {
    title,
    description,
    alternates: { canonical: `https://junkremovals365.com/services/${service.slug}/${params.state}` },
    openGraph: {
      title,
      description,
      url: `https://junkremovals365.com/services/${service.slug}/${params.state}`,
      siteName: 'Junk Removals 365',
      type: 'website',
      images: [{ url: 'https://junkremovals365.com/image.png' }],
    },
  };
}

async function getCities(stateSlug: string, serviceSlug: string): Promise<{ city_name: string; city_slug: string }[]> {
  try {
    const supabase = createServerClient();
    const { data, error } = await supabase
      .from('city_pages')
      .select('city_name, city_slug')
      .eq('state_slug', stateSlug)
      .eq('service_slug', serviceSlug)
      .eq('is_active', true)
      .order('city_name', { ascending: true })
      .limit(2000);
    if (error) return [];
    return Array.from(new Map((data || []).map((c) => [c.city_slug, c])).values());
  } catch {
    return [];
  }
}

interface StatePageData {
  hero_title: string | null;
  hero_description: string | null;
  intro_text: string | null;
  why_choose_section: string | null;
  service_areas_text: string | null;
  pricing_note: string | null;
  local_info: string | null;
  what_makes_different: string | null;
  faqs: { question: string; answer: string }[] | null;
  map_embed_url: string | null;
  lat: number | null;
  lng: number | null;
  meta_description: string | null;
}

async function getStatePageData(stateName: string, serviceSlug: string): Promise<StatePageData | null> {
  try {
    const supabase = createServerClient();
    const { data, error } = await supabase
      .from('state_pages')
      .select('hero_title, hero_description, intro_text, why_choose_section, service_areas_text, pricing_note, local_info, what_makes_different, faqs, map_embed_url, lat, lng, meta_description')
      .eq('state_name', stateName)
      .eq('service_slug', serviceSlug)
      .eq('is_active', true)
      .maybeSingle();
    if (error || !data) return null;
    return data as StatePageData;
  } catch {
    return null;
  }
}

export default async function ServiceStatePage({ params }: { params: { service: string; state: string } }) {
  const service = getService(params.service);
  const stateName = STATE_NAMES[params.state];
  if (!service || !stateName) notFound();

  const [cities, topCities, statePageData] = await Promise.all([
    getCities(params.state, params.service),
    Promise.resolve(getTopCities(params.state)),
    getStatePageData(stateName, params.service),
  ]);

  const coords = STATE_COORDS[params.state] || { lat: 39.8283, lng: -98.5795, zoom: 4 };
  const mapUrl = `https://www.google.com/maps?q=${encodeURIComponent(stateName)},USA&output=embed&z=${coords.zoom}`;

  const accentBg = accentBgMap[service.accentColor] ?? 'bg-green-600';
  const accentText = accentTextMap[service.accentColor] ?? 'text-green-600';
  const accentHover = accentHoverMap[service.accentColor] ?? 'hover:bg-green-700';

  const iconBgColors = ['bg-blue-600', 'bg-green-600', 'bg-yellow-600', 'bg-orange-600', 'bg-teal-600', 'bg-pink-600'];
  const whyUsItems = getWhyUsItems(service.name);

  const baseUrl = 'https://junkremovals365.com';
  const pageUrl = `${baseUrl}/services/${service.slug}/${params.state}`;
  const stateFaqs = statePageData?.faqs ?? service.faqs;

  return (
    <div className="min-h-screen bg-white">
      <SchemaMarkup
        type="localBusiness"
        id={`lb-${service.slug}-${params.state}`}
        data={{
          description: `Professional ${service.name.toLowerCase()} in ${stateName}. Licensed, insured team serves all major cities with same-day service available.`,
          url: pageUrl,
          areaServed: stateName,
        }}
      />
      <SchemaMarkup
        type="faq"
        id={`faq-${service.slug}-${params.state}`}
        data={{ faqs: stateFaqs }}
      />
      <SchemaMarkup
        type="breadcrumb"
        id={`bc-${service.slug}-${params.state}`}
        data={{
          breadcrumbs: [
            { name: 'Home', url: baseUrl },
            { name: 'Services', url: `${baseUrl}/services` },
            { name: service.name, url: `${baseUrl}/services/${service.slug}` },
            { name: stateName, url: pageUrl },
          ],
        }}
      />
      <Header />

      <main>
      {/* Hero */}
      <section className="relative py-16 bg-gradient-to-b from-gray-50 to-white">
        <div className="container mx-auto px-4">
          <Link
            href={`/services/${service.slug}`}
            className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-8 font-semibold transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to All {service.name} Locations
          </Link>

          <div className="grid lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                Professional <span className={accentText}>{service.name}</span> in {stateName}
              </h1>

              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                {statePageData?.hero_description || `${service.subheadline} Serving all major cities across ${stateName} with licensed, insured professionals.`}
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Link
                  href="/book"
                  className={`inline-flex items-center justify-center ${accentBg} ${accentHover} text-white px-8 py-4 rounded-lg font-bold transition-colors shadow-lg text-lg`}
                >
                  Book Now
                </Link>
              </div>

              <div className="flex items-center gap-8 pt-6 border-t border-gray-200">
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <CheckCircle key={i} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <span className="font-bold text-gray-900">4.9</span>
                </div>
                <div className="text-sm text-gray-600">
                  <span className="font-bold text-gray-900">1,000+</span> reviews
                </div>
                <div className="text-sm text-gray-600">
                  <span className="font-bold text-gray-900">Same-day</span> service
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative bg-gradient-to-br from-gray-900 to-gray-700 rounded-3xl p-8 shadow-2xl border-8 border-gray-200">
                <div className={`absolute -top-4 -right-4 ${accentBg} text-white px-4 py-2 rounded-lg font-bold text-sm shadow-lg`}>
                  Live Coverage
                </div>
                <LazyMap
                  src={mapUrl}
                  title={`Map of ${stateName} showing ${service.name.toLowerCase()} service areas`}
                  height={600}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <BookingSection stateName={stateName} service={service} />

      {/* Custom Intro Text */}
      {statePageData?.intro_text && (
        <section className="py-14 bg-white border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-4xl">
            <p className="text-lg text-gray-700 leading-relaxed">{statePageData.intro_text}</p>
          </div>
        </section>
      )}

      {/* Why Choose Us */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Why Choose Our {stateName} {service.name} Service?
            </h2>
            <p className="text-xl text-gray-300">
              Trusted by thousands of {stateName} residents for professional, eco-friendly removal
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {whyUsItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="bg-gray-800 p-6 rounded-xl hover:bg-gray-700 transition-colors">
                  <div className={`w-14 h-14 ${iconBgColors[index % iconBgColors.length]} rounded-xl flex items-center justify-center mb-4`}>
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-gray-400">{item.description}</p>
                </div>
              );
            })}
          </div>

          {statePageData?.why_choose_section && (
            <div className="mt-10 max-w-4xl mx-auto border-t border-gray-700 pt-8">
              <p className="text-gray-300 text-lg leading-relaxed">{statePageData.why_choose_section}</p>
            </div>
          )}
        </div>
      </section>

      <HowItWorks serviceName={service.name} />

      {/* Local Info */}
      {statePageData?.local_info && (
        <section className="py-14 bg-gray-50 border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-4xl">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">
              About {service.name} in {stateName}
            </h2>
            <p className="text-lg text-gray-700 leading-relaxed">{statePageData.local_info}</p>
          </div>
        </section>
      )}

      {/* What Makes Us Different */}
      {statePageData?.what_makes_different && (
        <section className="py-10 bg-white border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className={`${accentBg} text-white rounded-2xl p-8 text-center`}>
              <p className="text-xl font-semibold leading-relaxed">{statePageData.what_makes_different}</p>
            </div>
          </div>
        </section>
      )}

      <ServiceStatePageClient
        cities={cities}
        topCities={topCities}
        stateSlug={params.state}
        stateName={stateName}
        serviceSlug={service.slug}
        serviceName={service.name}
        faqs={statePageData?.faqs ?? service.faqs}
        accentText={accentText}
        accentBg={accentBg}
      />

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-blue-600 via-blue-500 to-green-500 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10" />
        <div className="container mx-auto px-4 max-w-4xl text-center relative z-10">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Ready for {service.name} in {stateName}?
          </h2>
          <p className="text-xl mb-8 text-white/90">Book online in minutes or get a free, no-obligation quote today</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/book"
              className="inline-flex items-center justify-center bg-white text-blue-600 px-10 py-4 rounded-lg font-bold hover:bg-gray-100 transition-colors text-lg shadow-lg"
            >
              Schedule Service
            </Link>
            <Link
              href="/book"
              className="inline-flex items-center justify-center border-2 border-white text-white px-10 py-4 rounded-lg font-bold hover:bg-white hover:text-blue-600 transition-colors text-lg"
            >
              Get Free Quote
            </Link>
          </div>
        </div>
      </section>

      </main>
      <Footer />
    </div>
  );
}

export const revalidate = 86400;
