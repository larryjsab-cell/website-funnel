"""Bulk research for a whole state: 1 Overpass request for named features + Census county per town.

Usage: python research_bulk.py <coords.json> <ISO3166-2 e.g. US-MI> <out.json>
Resumes: towns already in out.json with a county are skipped.
"""
import json
import math
import os
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from research import MIRRORS, census, get  # noqa: E402


def features(iso, cache):
    if os.path.exists(cache):
        return json.load(open(cache, encoding='utf-8'))
    q = f"""[out:json][timeout:600];
area["ISO3166-2"="{iso}"]->.s;
(
  way["natural"="water"]["name"](area.s);
  relation["natural"="water"]["name"](area.s);
  way["waterway"="river"]["name"](area.s);
  way["leisure"="park"]["name"](area.s);
  relation["boundary"="protected_area"]["name"](area.s);
  way["highway"~"^(motorway|trunk|primary)$"]["ref"](area.s);
);
out center tags;"""
    body = urllib.parse.urlencode({'data': q}).encode()
    for attempt in range(6):
        for host in MIRRORS:
            try:
                d = get(host, data=body, timeout=900)
                if d.get('remark') or len(d['elements']) < 5000:
                    raise ValueError(f"partial result {len(d['elements'])} {d.get('remark', '')[:80]}")
                out = []
                for e in d['elements']:
                    c = e.get('center')
                    if not c:
                        continue
                    t = e['tags']
                    kind = 'road' if t.get('highway') else 'water' if (t.get('natural') == 'water' or t.get('waterway')) else 'park'
                    out.append([kind, t.get('ref') if kind == 'road' else t.get('name'), c['lat'], c['lon']])
                json.dump(out, open(cache, 'w', encoding='utf-8'))
                return out
            except Exception as e:  # noqa: BLE001
                print('overpass retry', host, e, flush=True)
                time.sleep(20)
    raise SystemExit('overpass failed')


def km(a, b, c, d):
    return math.hypot((a - c) * 111, (b - d) * 111 * math.cos(math.radians(a)))


def main():
    src, iso, out = sys.argv[1:4]
    towns = json.load(open(src, encoding='utf-8'))
    feats = features(iso, out + '.features.json')
    # A timed-out Overpass response can be cut off part way across the state; reject it if towns fall outside it.
    tl = [float(t['lng']) for t in towns if t.get('lng') is not None]
    fl = [f[3] for f in feats]
    if tl and fl and (min(tl) < min(fl) - 0.3 or max(tl) > max(fl) + 0.3):
        os.remove(out + '.features.json')
        raise SystemExit(f'partial overpass coverage {min(fl):.2f}..{max(fl):.2f} vs towns {min(tl):.2f}..{max(tl):.2f}; rerun')
    print('features', len(feats), flush=True)
    res = json.load(open(out, encoding='utf-8')) if os.path.exists(out) else {}
    radius = {'water': 6, 'park': 5, 'road': 4}
    for t in towns:
        lat, lng = float(t['lat']), float(t['lng'])
        near = sorted((km(lat, lng, f[2], f[3]), f[0], f[1]) for f in feats
                      if abs(f[2] - lat) < 0.1 and abs(f[3] - lng) < 0.13)
        pick = {'water': [], 'park': [], 'road': []}
        for dist, kind, name in near:
            if dist > radius[kind] or not name:
                continue
            for n in (name.split(';') if kind == 'road' else [name]):
                n = n.strip()
                if n and n not in pick[kind]:
                    pick[kind].append(n)
        r = res.get(t['city_slug'], {})
        r.update({'name': t['city_name'], 'water': pick['water'][:4], 'parks': pick['park'][:4], 'roads': pick['road'][:3]})
        res[t['city_slug']] = r
    todo = [t for t in towns if 'places' not in res[t['city_slug']]]

    def work(t):
        for _ in range(3):
            try:
                return t['city_slug'], census(float(t['lat']), float(t['lng']))
            except Exception:  # noqa: BLE001
                time.sleep(3)
        return t['city_slug'], (None, None, None)

    with ThreadPoolExecutor(6) as ex:
        for i, (slug, (county, sub, places)) in enumerate(ex.map(work, todo), 1):
            res[slug]['county'], res[slug]['township'], res[slug]['places'] = county, sub, places
            if i % 100 == 0:
                print(i, 'census', flush=True)
                json.dump(res, open(out, 'w', encoding='utf-8'), ensure_ascii=False)
    json.dump(res, open(out, 'w', encoding='utf-8'), ensure_ascii=False)
    print('total', len(res), 'with county', sum(1 for v in res.values() if v.get('county')))


if __name__ == '__main__':
    main()
