'use client';

import { useState } from 'react';
import Link from 'next/link';
import { MapPin, ChevronDown, ChevronUp } from 'lucide-react';
import type { FAQ } from '@/lib/templates/cityTemplates';

interface CityPageClientProps {
  cityName: string;
  serviceName: string;
  stateName: string;
  stateSlug: string;
  nearbyCitiesBaseHref: string;
  faqs: FAQ[];
  cityContext: string;
  pricingFactors: string[];
  serviceIncludes: string[];
  localRules: string;
  nearbyCities: string[];
  landmarks: string[];
  housingType: string | null;
}

function FAQItem({ question, answer }: FAQ) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between p-5 text-left bg-white hover:bg-gray-50 transition-colors"
        aria-expanded={open}
      >
        <span className="font-semibold text-gray-900 pr-4">{question}</span>
        {open ? <ChevronUp className="h-5 w-5 text-gray-500 flex-shrink-0" /> : <ChevronDown className="h-5 w-5 text-gray-500 flex-shrink-0" />}
      </button>
      {open && (
        <div className="px-5 pb-5 bg-white border-t border-gray-100">
          <p className="text-gray-600 leading-relaxed pt-3">{answer}</p>
        </div>
      )}
    </div>
  );
}

export default function CityPageClient({
  cityName,
  serviceName,
  stateName,
  stateSlug,
  nearbyCitiesBaseHref,
  faqs,
  cityContext,
  pricingFactors,
  serviceIncludes,
  localRules,
  nearbyCities,
  landmarks,
  housingType,
}: CityPageClientProps) {
  return (
    <>
      {/* City Context */}
      <section className="py-14 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">
                {cityName} {serviceName} — Serving {cityName}, {stateName}
              </h2>
              <p className="text-gray-600 leading-relaxed mb-6">{cityContext}</p>
              {housingType && (
                <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                  <p className="text-sm font-semibold text-gray-700 mb-1">Local Housing Info</p>
                  <p className="text-sm text-gray-600">{housingType}</p>
                </div>
              )}
              {localRules && (
                <div className="mt-4 bg-blue-600 rounded-xl p-4 border border-blue-700">
                  <p className="text-sm font-semibold text-white mb-1">Local Regulations</p>
                  <p className="text-sm text-white/90">{localRules}</p>
                </div>
              )}
            </div>

            <div className="space-y-6">
              {serviceIncludes.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">What&apos;s Included</h3>
                  <ul className="space-y-2">
                    {serviceIncludes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <span className="mt-1 w-5 h-5 rounded-full bg-green-600 flex items-center justify-center flex-shrink-0">
                          <span className="block w-2 h-2 rounded-full bg-white" />
                        </span>
                        <span className="text-gray-700 text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {pricingFactors.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Pricing Factors</h3>
                  <ul className="space-y-2">
                    {pricingFactors.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <span className="mt-1 w-5 h-5 rounded-full bg-orange-600 flex items-center justify-center flex-shrink-0">
                          <span className="block w-2 h-2 rounded-full bg-white" />
                        </span>
                        <span className="text-gray-700 text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Landmarks */}
      {landmarks.length > 0 && (
        <section className="py-10 bg-gray-50 border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-7xl">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Landmarks & Areas We Serve in {cityName}</h2>
            <div className="flex flex-wrap gap-2">
              {landmarks.map((lm, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-200 rounded-full text-sm text-gray-700">
                  <MapPin className="h-3.5 w-3.5 text-gray-400" />
                  {lm}
                </span>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Nearby Cities (text-based from DB) — hidden */}
      {false && nearbyCities.length > 0 && (
        <section className="py-10 bg-white border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-7xl">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Also Serving Nearby {stateName} Cities</h2>
            <div className="flex flex-wrap gap-2">
              {nearbyCities.map((city, i) => {
                const slug = city.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
                return (
                  <Link
                    key={i}
                    href={`${nearbyCitiesBaseHref}/${slug}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gray-50 hover:bg-white border border-gray-200 hover:border-gray-300 rounded-full text-sm text-gray-700 hover:text-gray-900 transition-colors"
                  >
                    <MapPin className="h-3.5 w-3.5 text-gray-400" />
                    {city}
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* FAQ */}
      {faqs.length > 0 && (
        <section className="py-14 bg-gray-50 border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="text-center mb-10">
              <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">
                Frequently Asked Questions
              </h2>
              <p className="text-gray-500">Common questions about our service in {cityName}, {stateName}</p>
            </div>
            <div className="space-y-3">
              {faqs.map((faq, i) => (
                <FAQItem key={i} question={faq.question} answer={faq.answer} />
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
