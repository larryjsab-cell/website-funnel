import { createServerClient } from '@/lib/supabaseServer';
import { SERVICE_LIST } from '@/lib/services';
import { getPublishedPostSlugs } from '@/lib/blogQueries';

export const BASE_URL = 'https://junkremovals365.com';
const PAGE_SIZE = 1000;

// One sitemap for core pages, plus one per service for city pages (each well under 50k URLs).
export function sitemapNames(): string[] {
  return ['main', ...SERVICE_LIST.map((svc) => svc.slug)];
}

function urlset(urls: string[]): string {
  const body = urls.map((u) => `<url><loc>${u}</loc></url>`).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${body}</urlset>`;
}

export function sitemapIndex(): string {
  const body = sitemapNames()
    .map((name) => `<sitemap><loc>${BASE_URL}/sitemaps/${name}.xml</loc></sitemap>`)
    .join('');
  return `<?xml version="1.0" encoding="UTF-8"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${body}</sitemapindex>`;
}

async function mainUrls(): Promise<string[]> {
  const urls = [
    BASE_URL,
    ...['/services', '/blog', '/book', '/how-it-works', '/contact', '/privacy', '/terms'].map((p) => BASE_URL + p),
    ...SERVICE_LIST.map((svc) => `${BASE_URL}/services/${svc.slug}`),
  ];
  const supabase = createServerClient();
  const { data: statePages } = await supabase
    .from('state_pages')
    .select('state_slug, service_slug')
    .eq('is_active', true);
  for (const page of statePages || []) {
    if (page.service_slug) urls.push(`${BASE_URL}/services/${page.service_slug}/${page.state_slug}`);
  }
  const posts = await getPublishedPostSlugs();
  for (const post of posts) urls.push(`${BASE_URL}/blog/${post.slug}`);
  return urls;
}

// Supabase caps responses at 1000 rows, so page through with range().
async function cityUrls(serviceSlug: string): Promise<string[]> {
  const supabase = createServerClient();
  const urls: string[] = [];
  for (let from = 0; ; from += PAGE_SIZE) {
    const { data, error } = await supabase
      .from('city_pages')
      .select('state_slug, city_slug')
      .eq('service_slug', serviceSlug)
      .eq('is_active', true)
      .ilike('seo_status', 'custom')
      .order('state_slug')
      .order('city_slug')
      .range(from, from + PAGE_SIZE - 1);
    if (error) throw error;
    for (const row of data || []) {
      urls.push(`${BASE_URL}/services/${serviceSlug}/${row.state_slug}/${row.city_slug}`);
    }
    if (!data || data.length < PAGE_SIZE) break;
  }
  return urls;
}

export async function sitemapXml(name: string): Promise<string | null> {
  if (name === 'main') return urlset(await mainUrls());
  if (SERVICE_LIST.some((svc) => svc.slug === name)) return urlset(await cityUrls(name));
  return null;
}
