"""Append finished cities to city_log.csv. Usage: python log_done.py <state_slug> <batch> <slug,slug,...>
Skips any city already logged."""
import csv, datetime, os, sys
LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'city_log.csv')
state, batch, slugs = sys.argv[1], sys.argv[2], sys.argv[3].split(',')
done = {(r['state_slug'], r['city_slug']) for r in csv.DictReader(open(LOG, encoding='utf-8'))} if os.path.exists(LOG) else set()
n = 0
with open(LOG, 'a', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    for s in slugs:
        if (state, s) not in done:
            w.writerow([state, s, s.replace('-', ' ').title(), 5, datetime.date.today().isoformat(), batch]); n += 1
print(f'logged {n}; total {len(done) + n}')
