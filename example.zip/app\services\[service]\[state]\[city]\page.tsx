import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, CircleCheck as CheckCircle, Shield, Zap, Users, Leaf, Clock, TrendingUp, MapPin } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HowItWorks from '@/components/HowItWorks';
import BookingSection from '@/components/BookingSection';
import { createServerClient } from '@/lib/supabaseServer';
import { getService, SERVICE_LIST } from '@/lib/services';
import CityPageClient from '@/components/CityPageClient';
import LazyMap from '@/components/LazyMap';
import {
  isBlank,
  templateIntro,
  templateCityContext,
  templatePricingFactors,
  templateServiceIncludes,
  templateLocalRules,
  templateNearbyCities,
  templateLandmarks,
  templateFaqs,
  type FAQ,
} from '@/lib/templates/cityTemplates';
import type { Metadata } from 'next';
import SchemaMarkup from '@/components/SchemaMarkup';
import { getCityHighlight } from '@/lib/cityHighlights';

const STATE_NAMES: Record<string, string> = {
  alabama: 'Alabama', alaska: 'Alaska', arizona: 'Arizona', arkansas: 'Arkansas',
  california: 'California', colorado: 'Colorado', connecticut: 'Connecticut', delaware: 'Delaware',
  florida: 'Florida', georgia: 'Georgia', hawaii: 'Hawaii', idaho: 'Idaho', illinois: 'Illinois',
  indiana: 'Indiana', iowa: 'Iowa', kansas: 'Kansas', kentucky: 'Kentucky', louisiana: 'Louisiana',
  maine: 'Maine', maryland: 'Maryland', massachusetts: 'Massachusetts', michigan: 'Michigan',
  minnesota: 'Minnesota', mississippi: 'Mississippi', missouri: 'Missouri', montana: 'Montana',
  nebraska: 'Nebraska', nevada: 'Nevada', 'new-hampshire': 'New Hampshire', 'new-jersey': 'New Jersey',
  'new-mexico': 'New Mexico', 'new-york': 'New York', 'north-carolina': 'North Carolina',
  'north-dakota': 'North Dakota', ohio: 'Ohio', oklahoma: 'Oklahoma', oregon: 'Oregon',
  pennsylvania: 'Pennsylvania', 'rhode-island': 'Rhode Island', 'south-carolina': 'South Carolina',
  'south-dakota': 'South Dakota', tennessee: 'Tennessee', texas: 'Texas', utah: 'Utah',
  vermont: 'Vermont', virginia: 'Virginia', washington: 'Washington', 'washington-dc': 'Washington DC',
  'west-virginia': 'West Virginia', wisconsin: 'Wisconsin', wyoming: 'Wyoming',
};

interface CityPageData {
  city_name: string;
  city_slug: string;
  state_slug: string;
  state_name: string | null;
  service_slug: string | null;
  unique_intro: string | null;
  city_context: string | null;
  housing_type: string | null;
  pricing_factors: string | null;
  service_includes: string | null;
  local_rules_note: string | null;
  nearby_cities: string | null;
  landmarks: string | null;
  faqs: string | null;
  lat: number | null;
  lng: number | null;
  is_active?: boolean;
  seo_status?: string;
}

interface NearbyCityRow {
  city_name: string;
  city_slug: string;
  state_slug: string;
}


function getWhyUsItems(serviceName: string) {
  return [
    { icon: Shield, title: 'Licensed & Insured', description: 'Fully licensed and insured professionals you can trust' },
    { icon: Zap, title: 'Same-Day Service', description: `Fast response times with same-day ${serviceName.toLowerCase()} available` },
    { icon: Leaf, title: 'Eco-Friendly Disposal', description: `Responsible recycling and donation after every ${serviceName.toLowerCase()} job` },
    { icon: TrendingUp, title: 'Transparent Pricing', description: 'No hidden fees — you know the cost upfront' },
    { icon: Users, title: 'Expert Team', description: `Trained professionals who handle every ${serviceName.toLowerCase()} with care` },
    { icon: Clock, title: '24/7 Booking', description: 'Book online anytime that works for your schedule' },
  ];
}

const accentBgMap: Record<string, string> = {
  green: 'bg-green-600', blue: 'bg-blue-600', orange: 'bg-orange-600', teal: 'bg-teal-600', red: 'bg-red-600',
};
const accentTextMap: Record<string, string> = {
  green: 'text-green-600', blue: 'text-blue-600', orange: 'text-orange-600', teal: 'text-teal-600', red: 'text-red-600',
};
const accentHoverMap: Record<string, string> = {
  green: 'hover:bg-green-700', blue: 'hover:bg-blue-700', orange: 'hover:bg-orange-700', teal: 'hover:bg-teal-700', red: 'hover:bg-red-700',
};

async function getCityData(stateSlug: string, citySlug: string, serviceSlug: string): Promise<CityPageData | null> {
  try {
    const supabase = createServerClient();
    const { data, error } = await supabase
      .from('city_pages')
      .select('*')
      .eq('state_slug', stateSlug)
      .eq('city_slug', citySlug)
      .eq('service_slug', serviceSlug)
      .maybeSingle();
    if (error) return null;
    return data;
  } catch {
    return null;
  }
}

async function getNearbyCities(
  stateSlug: string,
  citySlug: string,
  lat: number | null,
  lng: number | null,
): Promise<NearbyCityRow[]> {
  if (!lat || !lng) return [];
  try {
    const supabase = createServerClient();
    // Use Haversine approximation via ORDER BY distance, exclude current city
    const { data, error } = await supabase
      .from('city_pages')
      .select('city_name, city_slug, state_slug')
      .eq('state_slug', stateSlug)
      .neq('city_slug', citySlug)
      .not('lat', 'is', null)
      .not('lng', 'is', null)
      .limit(200);
    if (error || !data) return [];

    // Sort by Haversine distance client-side (avoids needing PostGIS)
    const sorted = data
      .map((row: any) => {
        const dLat = ((Number(row.lat) - lat) * Math.PI) / 180;
        const dLng = ((Number(row.lng) - lng) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) ** 2 +
          Math.cos((lat * Math.PI) / 180) * Math.cos((Number(row.lat) * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
        const dist = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return { ...row, dist };
      })
      .sort((a: any, b: any) => a.dist - b.dist)
      .slice(0, 5);

    return sorted.map(({ dist: _d, ...row }: any) => row);
  } catch {
    return [];
  }
}


function parseDelimited(value: string | null, delim: string): string[] {
  if (!value) return [];
  return value.split(delim).map((s) => s.trim()).filter(Boolean);
}

function parseFaqs(value: string | null): FAQ[] {
  if (!value) return [];
  try {
    const p = JSON.parse(value);
    return Array.isArray(p) ? p : [];
  } catch {
    return [];
  }
}

function cityNameFromSlug(slug: string) {
  return slug.split('-').map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

export async function generateMetadata({ params }: { params: { service: string; state: string; city: string } }): Promise<Metadata> {
  const service = getService(params.service);
  const stateName = STATE_NAMES[params.state];
  if (!service || !stateName) return { title: 'Not Found' };

  const cityData = await getCityData(params.state, params.city, params.service);
  const cityName = cityData?.city_name ?? cityNameFromSlug(params.city);

  const title = `${service.name} in ${cityName}, ${stateName} | Junk Removals 365`;
  const description = isBlank(cityData?.unique_intro)
    ? `Professional ${service.name.toLowerCase()} in ${cityName}, ${stateName}. Same-day service available. Licensed & insured. Get an instant quote online.`
    : cityData!.unique_intro!.substring(0, 160);

  return {
    title,
    description,
    robots: { index: true, follow: true },
    alternates: { canonical: `https://junkremovals365.com/services/${service.slug}/${params.state}/${params.city}` },
    openGraph: { title, description, siteName: 'Junk Removals 365' },
  };
}

export default async function ServiceCityPage({ params }: { params: { service: string; state: string; city: string } }) {
  const service = getService(params.service);
  const stateName = STATE_NAMES[params.state];
  if (!service || !stateName) notFound();

  const cityData = await getCityData(params.state, params.city, params.service);
  const cityName = cityData?.city_name ?? cityNameFromSlug(params.city);
  const serviceSlug = service.slug;

  const [nearbyCities] = await Promise.all([
    getNearbyCities(params.state, params.city, cityData?.lat ?? null, cityData?.lng ?? null),
  ]);

  const intro = isBlank(cityData?.unique_intro)
    ? templateIntro(cityName, stateName, serviceSlug)
    : cityData!.unique_intro!;

  const cityContext = isBlank(cityData?.city_context)
    ? templateCityContext(cityName, stateName)
    : cityData!.city_context!;

  const pricingFactors = isBlank(cityData?.pricing_factors)
    ? templatePricingFactors(cityName, stateName, serviceSlug)
    : parseDelimited(cityData!.pricing_factors, ';');

  const serviceIncludes = isBlank(cityData?.service_includes)
    ? templateServiceIncludes(serviceSlug)
    : parseDelimited(cityData!.service_includes, ';');

  const localRules = isBlank(cityData?.local_rules_note)
    ? templateLocalRules(cityName, stateName)
    : cityData!.local_rules_note!;

  const nearbyCityNames = isBlank(cityData?.nearby_cities)
    ? templateNearbyCities(cityName, stateName)
    : parseDelimited(cityData!.nearby_cities, '|');

  const landmarks = isBlank(cityData?.landmarks)
    ? templateLandmarks(cityName, stateName)
    : parseDelimited(cityData!.landmarks, '|');

  const serviceLower = service.name.toLowerCase();
  const cityFaqs: FAQ[] = [
    {
      question: `Do you offer ${serviceLower} in ${cityName}, ${stateName}?`,
      answer: `Yes. Junk Removals 365 provides ${serviceLower} in ${cityName} and nearby ${stateName} communities. Book online to see available pickup times, including same-day and next-day slots in most areas.`,
    },
    {
      question: `How much does ${serviceLower} cost in ${cityName}?`,
      answer: `${service.name} in ${cityName} is priced by how much truck space your items take, the type of items, and access such as stairs. You get an upfront quote before any work begins, with no hidden fees.`,
    },
  ];
  const highlight = getCityHighlight(params.state, params.city);
  const faqs = [...cityFaqs, ...(highlight?.faqs ?? []), ...(isBlank(cityData?.faqs) ? service.faqs : parseFaqs(cityData!.faqs))];

  const mapUrl =
    cityData?.lat && cityData?.lng
      ? `https://www.google.com/maps?q=${cityData.lat},${cityData.lng}&output=embed&z=12`
      : `https://www.google.com/maps?q=${encodeURIComponent(cityName)},${encodeURIComponent(stateName)}&output=embed&z=12`;

  const accentBg = accentBgMap[service.accentColor] ?? 'bg-green-600';
  const accentText = accentTextMap[service.accentColor] ?? 'text-green-600';
  const accentHover = accentHoverMap[service.accentColor] ?? 'hover:bg-green-700';

  const iconBgColors = ['bg-blue-600', 'bg-green-600', 'bg-yellow-600', 'bg-orange-600', 'bg-teal-600', 'bg-pink-600'];
  const whyUsItems = getWhyUsItems(service.name);

  const servicestoShow = SERVICE_LIST.filter((s) => s.slug !== serviceSlug);

  const baseUrl = 'https://junkremovals365.com';
  const pageUrl = `${baseUrl}/services/${service.slug}/${params.state}/${params.city}`;

  return (
    <div className="min-h-screen bg-white">
      <SchemaMarkup
        type="localBusiness"
        id={`lb-${service.slug}-${params.state}-${params.city}`}
        data={{
          description: `Professional ${service.name.toLowerCase()} in ${cityName}, ${stateName}. Same-day service available. Licensed & insured.`,
          url: pageUrl,
          areaServed: `${cityName}, ${stateName}`,
          ...(cityData?.lat && cityData?.lng ? { geo: { latitude: cityData.lat, longitude: cityData.lng } } : {}),
        }}
      />
      <SchemaMarkup
        type="faq"
        id={`faq-${service.slug}-${params.state}-${params.city}`}
        data={{ faqs }}
      />
      <SchemaMarkup
        type="breadcrumb"
        id={`bc-${service.slug}-${params.state}-${params.city}`}
        data={{
          breadcrumbs: [
            { name: 'Home', url: baseUrl },
            { name: 'Services', url: `${baseUrl}/services` },
            { name: service.name, url: `${baseUrl}/services/${service.slug}` },
            { name: stateName, url: `${baseUrl}/services/${service.slug}/${params.state}` },
            { name: cityName, url: pageUrl },
          ],
        }}
      />
      <Header />

      <main>
      {/* Hero */}
      <section className="relative py-16 bg-gradient-to-b from-gray-50 to-white">
        <div className="container mx-auto px-4">
          <Link
            href={`/services/${service.slug}/${params.state}`}
            className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-8 font-semibold transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to {stateName}
          </Link>

          <div className="grid lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                Professional <span className={accentText}>{service.name}</span> in {cityName}
              </h1>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">{intro}</p>

              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Link
                  href="/book"
                  className={`inline-flex items-center justify-center ${accentBg} ${accentHover} text-white px-8 py-4 rounded-lg font-bold transition-colors shadow-lg text-lg`}
                >
                  Book Now
                </Link>
              </div>

              <div className="flex items-center gap-8 pt-6 border-t border-gray-200">
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <CheckCircle key={i} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <span className="font-bold text-gray-900">4.9</span>
                </div>
                <div className="text-sm text-gray-600">
                  <span className="font-bold text-gray-900">1,000+</span> reviews
                </div>
                <div className="text-sm text-gray-600">
                  <span className="font-bold text-gray-900">Same-day</span> service
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative bg-gradient-to-br from-gray-900 to-gray-700 rounded-3xl p-8 shadow-2xl border-8 border-gray-200">
                <div className={`absolute -top-4 -right-4 ${accentBg} text-white px-4 py-2 rounded-lg font-bold text-sm shadow-lg`}>
                  We Serve {cityName}
                </div>
                <LazyMap
                  src={mapUrl}
                  title={`Map of ${cityName}, ${stateName} showing ${service.name.toLowerCase()} service areas`}
                  height={600}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <BookingSection cityName={cityName} stateName={stateName} service={service} />

      {/* Why Choose Us */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Why Choose Our {cityName} {service.name} Service?
            </h2>
            <p className="text-xl text-gray-300">
              Trusted by {cityName} residents for professional, eco-friendly removal
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {whyUsItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="bg-gray-800 p-6 rounded-xl hover:bg-gray-700 transition-colors">
                  <div className={`w-14 h-14 ${iconBgColors[index % iconBgColors.length]} rounded-xl flex items-center justify-center mb-4`}>
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-gray-400">{item.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <HowItWorks serviceName={service.name} />

      {highlight && (
        <section className="py-14 bg-white border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-5xl">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">
              {service.name} in {cityName}: What to Know
            </h2>
            {highlight.paragraphs.map((text, i) => (
              <p key={i} className="text-gray-700 leading-relaxed mb-4">{text}</p>
            ))}
            <h3 className="text-lg font-bold text-gray-900 mt-6 mb-3">Areas We Serve In and Around {cityName}</h3>
            <ul className="flex flex-wrap gap-2">
              {highlight.areas.map((area) => (
                <li key={area} className="bg-gray-100 text-gray-800 text-sm px-3 py-1 rounded-full">{area}</li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <CityPageClient
        cityName={cityName}
        serviceName={service.name}
        stateName={stateName}
        stateSlug={params.state}
        nearbyCitiesBaseHref={`/services/${service.slug}/${params.state}`}
        faqs={faqs}
        cityContext={cityContext}
        pricingFactors={pricingFactors}
        serviceIncludes={serviceIncludes}
        localRules={localRules}
        nearbyCities={nearbyCityNames}
        landmarks={landmarks}
        housingType={cityData?.housing_type ?? null}
      />

      {/* Internal Links — Nearby Cities + Other Services side by side */}
      {(nearbyCities.length > 0 || servicestoShow.length > 0) && (
        <section className="py-14 bg-gray-50 border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="grid lg:grid-cols-2 gap-10">

              {/* Nearby Cities */}
              {nearbyCities.length > 0 && (
                <div>
                  <p className={`text-xs font-semibold uppercase tracking-widest ${accentText} mb-2`}>
                    Also Serving Your Area
                  </p>
                  <h2 className="text-xl font-bold text-gray-900 mb-1">
                    Neighboring Cities
                  </h2>
                  <p className="text-sm text-gray-500 mb-6">
                    {service.name} near {cityName}, {stateName}
                  </p>
                  <div className="flex flex-col gap-3">
                    {nearbyCities.map((city) => (
                      <Link
                        key={city.city_slug}
                        href={`/services/${serviceSlug}/${city.state_slug}/${city.city_slug}`}
                        className="group flex items-center gap-3 p-4 bg-white rounded-xl border border-gray-200 hover:border-gray-300 hover:shadow-md transition-all duration-200"
                      >
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${accentBg} bg-opacity-10`}>
                          <MapPin className={`h-4 w-4 ${accentText}`} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className={`font-semibold text-gray-800 group-hover:${accentText} transition-colors text-sm`}>
                            {city.city_name}
                          </p>
                          <p className="text-xs text-gray-400">{stateName}</p>
                        </div>
                        <span className={`text-xs font-semibold ${accentText} opacity-0 group-hover:opacity-100 transition-opacity`}>
                          View &rarr;
                        </span>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Other Services */}
              {servicestoShow.length > 0 && (
                <div>
                  <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 mb-2">
                    More Ways We Can Help
                  </p>
                  <h2 className="text-xl font-bold text-gray-900 mb-1">
                    Other Services in {cityName}
                  </h2>
                  <p className="text-sm text-gray-500 mb-6">
                    Additional removal services available in {cityName}
                  </p>
                  <div className="flex flex-col gap-3">
                    {servicestoShow.map((svc) => {
                      const svcAccentBg = accentBgMap[svc.accentColor] ?? 'bg-green-600';
                      const svcAccentText = accentTextMap[svc.accentColor] ?? 'text-green-600';
                      return (
                        <Link
                          key={svc.slug}
                          href={`/services/${svc.slug}/${params.state}/${params.city}`}
                          className="group flex items-center gap-3 p-4 bg-white rounded-xl border border-gray-200 hover:border-gray-300 hover:shadow-md transition-all duration-200"
                        >
                          <div className={`w-9 h-9 ${svcAccentBg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                            <CheckCircle className="h-4 w-4 text-white" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className={`font-semibold text-gray-800 group-hover:${svcAccentText} transition-colors text-sm`}>
                              {svc.name}
                            </p>
                            <p className="text-xs text-gray-400 truncate">{svc.shortName} in {cityName}</p>
                          </div>
                          <span className={`text-xs font-semibold ${svcAccentText} opacity-0 group-hover:opacity-100 transition-opacity`}>
                            View &rarr;
                          </span>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-blue-600 via-blue-500 to-green-500 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10" />
        <div className="container mx-auto px-4 max-w-4xl text-center relative z-10">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Ready for {service.name} in {cityName}?
          </h2>
          <p className="text-xl mb-8 text-white/90">Book online in minutes or get a free, no-obligation quote today</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/book"
              className="inline-flex items-center justify-center bg-white text-blue-600 px-10 py-4 rounded-lg font-bold hover:bg-gray-100 transition-colors text-lg shadow-lg"
            >
              Schedule Service
            </Link>
            <Link
              href="/book"
              className="inline-flex items-center justify-center border-2 border-white text-white px-10 py-4 rounded-lg font-bold hover:bg-white hover:text-blue-600 transition-colors text-lg"
            >
              Get Free Quote
            </Link>
          </div>
        </div>
      </section>

      </main>
      <Footer />
    </div>
  );
}

export const revalidate = 86400;
