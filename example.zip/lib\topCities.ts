export const TOP_CITIES_BY_STATE: Record<string, string[]> = {
  alabama: ['Birmingham', 'Montgomery', 'Mobile', 'Huntsville', 'Tuscaloosa'],
  alaska: ['Anchorage', 'Fairbanks', 'Juneau', 'Sitka', 'Ketchikan'],
  arizona: ['Phoenix', 'Tucson', 'Mesa', 'Chandler', 'Scottsdale'],
  arkansas: ['Little Rock', 'Fort Smith', 'Fayetteville', 'Springdale', 'Jonesboro'],
  california: ['Los Angeles', 'San Diego', 'San Jose', 'San Francisco', 'Sacramento'],
  colorado: ['Denver', 'Colorado Springs', 'Aurora', 'Fort Collins', 'Boulder'],
  connecticut: ['Bridgeport', 'New Haven', 'Hartford', 'Stamford', 'Waterbury'],
  delaware: ['Wilmington', 'Dover', 'Newark', 'Middletown', 'Smyrna'],
  florida: ['Jacksonville', 'Miami', 'Tampa', 'Orlando', 'St. Petersburg'],
  georgia: ['Atlanta', 'Augusta', 'Columbus', 'Savannah', 'Athens'],
  hawaii: ['Honolulu', 'Hilo', 'Kailua', 'Kapolei', 'Kaneohe'],
  idaho: ['Boise', 'Meridian', 'Nampa', 'Idaho Falls', 'Pocatello'],
  illinois: ['Chicago', 'Aurora', 'Naperville', 'Joliet', 'Rockford'],
  indiana: ['Indianapolis', 'Fort Wayne', 'Evansville', 'South Bend', 'Carmel'],
  iowa: ['Des Moines', 'Cedar Rapids', 'Davenport', 'Sioux City', 'Iowa City'],
  kansas: ['Wichita', 'Overland Park', 'Kansas City', 'Topeka', 'Olathe'],
  kentucky: ['Louisville', 'Lexington', 'Bowling Green', 'Owensboro', 'Covington'],
  louisiana: ['New Orleans', 'Baton Rouge', 'Shreveport', 'Lafayette', 'Lake Charles'],
  maine: ['Portland', 'Lewiston', 'Bangor', 'South Portland', 'Auburn'],
  maryland: ['Baltimore', 'Frederick', 'Rockville', 'Gaithersburg', 'Annapolis'],
  massachusetts: ['Boston', 'Worcester', 'Springfield', 'Cambridge', 'Lowell'],
  michigan: ['Detroit', 'Grand Rapids', 'Warren', 'Sterling Heights', 'Lansing'],
  minnesota: ['Minneapolis', 'Saint Paul', 'Rochester', 'Duluth', 'Bloomington'],
  mississippi: ['Jackson', 'Gulfport', 'Southaven', 'Hattiesburg', 'Biloxi'],
  missouri: ['Kansas City', 'St. Louis', 'Springfield', 'Columbia', 'Independence'],
  montana: ['Billings', 'Missoula', 'Great Falls', 'Bozeman', 'Helena'],
  nebraska: ['Omaha', 'Lincoln', 'Bellevue', 'Grand Island', 'Kearney'],
  nevada: ['Las Vegas', 'Henderson', 'Reno', 'North Las Vegas', 'Sparks'],
  'new-hampshire': ['Manchester', 'Nashua', 'Concord', 'Derry', 'Rochester'],
  'new-jersey': ['Newark', 'Jersey City', 'Paterson', 'Elizabeth', 'Edison'],
  'new-mexico': ['Albuquerque', 'Las Cruces', 'Rio Rancho', 'Santa Fe', 'Roswell'],
  'new-york': ['New York City', 'Buffalo', 'Rochester', 'Yonkers', 'Syracuse'],
  'north-carolina': ['Charlotte', 'Raleigh', 'Greensboro', 'Durham', 'Winston-Salem'],
  'north-dakota': ['Fargo', 'Bismarck', 'Grand Forks', 'Minot', 'West Fargo'],
  ohio: ['Columbus', 'Cleveland', 'Cincinnati', 'Toledo', 'Akron'],
  oklahoma: ['Oklahoma City', 'Tulsa', 'Norman', 'Broken Arrow', 'Edmond'],
  oregon: ['Portland', 'Eugene', 'Salem', 'Gresham', 'Hillsboro'],
  pennsylvania: ['Philadelphia', 'Pittsburgh', 'Allentown', 'Erie', 'Reading'],
  'rhode-island': ['Providence', 'Warwick', 'Cranston', 'Pawtucket', 'East Providence'],
  'south-carolina': ['Charleston', 'Columbia', 'North Charleston', 'Mount Pleasant', 'Rock Hill'],
  'south-dakota': ['Sioux Falls', 'Rapid City', 'Aberdeen', 'Brookings', 'Watertown'],
  tennessee: ['Nashville', 'Memphis', 'Knoxville', 'Chattanooga', 'Clarksville'],
  texas: ['Houston', 'San Antonio', 'Dallas', 'Austin', 'Fort Worth'],
  utah: ['Salt Lake City', 'West Valley City', 'Provo', 'West Jordan', 'Orem'],
  vermont: ['Burlington', 'South Burlington', 'Rutland', 'Barre', 'Montpelier'],
  virginia: ['Virginia Beach', 'Norfolk', 'Chesapeake', 'Richmond', 'Newport News'],
  washington: ['Seattle', 'Spokane', 'Tacoma', 'Vancouver', 'Bellevue'],
  'washington-dc': ['Washington', 'Georgetown', 'Capitol Hill', 'Dupont Circle', 'Adams Morgan'],
  'west-virginia': ['Charleston', 'Huntington', 'Morgantown', 'Parkersburg', 'Wheeling'],
  wisconsin: ['Milwaukee', 'Madison', 'Green Bay', 'Kenosha', 'Racine'],
  wyoming: ['Cheyenne', 'Casper', 'Laramie', 'Gillette', 'Rock Springs'],
};

export function cityToSlug(city: string): string {
  return city
    .toLowerCase()
    .trim()
    .replace(/&/g, 'and')
    .replace(/['']/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

export function getTopCities(stateSlug: string): { name: string; slug: string }[] {
  const cities = TOP_CITIES_BY_STATE[stateSlug] ?? [];
  return cities.map((name) => ({ name, slug: cityToSlug(name) }));
}
