"""Full per-state pipeline: coords -> research (Census + OSM) -> verified SQL batches + basic-tier SQL.

Usage: python state_pipeline.py <state_slug> <State Name> <ABBR> <workdir>
Needs NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY in env (read-only REST select).
Outputs in workdir: <state>_v_N.sql (verified, 200 cities each), <state>_basic.sql, <state>_verified.txt, <state>_basic.txt
Skips cities already in city_log.csv.
"""
import csv
import json
import math
import os
import re
import sys
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import research_bulk as rb  # noqa: E402
import research_to_sql as rs  # noqa: E402
from research import MIRRORS, get  # noqa: E402

FIPS_ISO = {'indiana': 'US-IN', 'ohio': 'US-OH', 'illinois': 'US-IL', 'wisconsin': 'US-WI', 'michigan': 'US-MI', 'pennsylvania': 'US-PA', 'minnesota': 'US-MN', 'iowa': 'US-IA', 'missouri': 'US-MO', 'kentucky': 'US-KY', 'tennessee': 'US-TN', 'kansas': 'US-KS', 'nebraska': 'US-NE', 'georgia': 'US-GA', 'virginia': 'US-VA', 'connecticut': 'US-CT', 'massachusetts': 'US-MA', 'washington': 'US-WA', 'texas': 'US-TX', 'florida': 'US-FL', 'california': 'US-CA', 'alabama': 'US-AL', 'arkansas': 'US-AR', 'louisiana': 'US-LA', 'oklahoma': 'US-OK', 'colorado': 'US-CO', 'arizona': 'US-AZ', 'oregon': 'US-OR', 'maryland': 'US-MD', 'mississippi': 'US-MS', 'new-york': 'US-NY', 'new-jersey': 'US-NJ', 'north-carolina': 'US-NC', 'south-carolina': 'US-SC', 'west-virginia': 'US-WV', 'new-hampshire': 'US-NH', 'new-mexico': 'US-NM', 'south-dakota': 'US-SD', 'north-dakota': 'US-ND', 'rhode-island': 'US-RI', 'delaware': 'US-DE', 'vermont': 'US-VT', 'maine': 'US-ME', 'hawaii': 'US-HI', 'idaho': 'US-ID', 'montana': 'US-MT', 'nevada': 'US-NV', 'alaska': 'US-AK', 'wyoming': 'US-WY', 'utah': 'US-UT'}


def q(s):
    return "'" + s.replace("'", "''") + "'"


def coords(state, wd):
    p = os.path.join(wd, f'{state}_coords.json')
    if os.path.exists(p):
        return json.load(open(p, encoding='utf-8'))
    # Supabase REST caps each response at 1000 rows, so page through with offset.
    k = os.environ['NEXT_PUBLIC_SUPABASE_ANON_KEY']
    d = []
    while True:
        url = os.environ['NEXT_PUBLIC_SUPABASE_URL'] + '/rest/v1/city_pages?' + urllib.parse.urlencode(
            {'select': 'city_slug,city_name,lat,lng', 'state_slug': f'eq.{state}', 'service_slug': 'eq.junk-removal',
             'order': 'city_slug', 'limit': 1000, 'offset': len(d)})
        req = urllib.request.Request(url, headers={'apikey': k, 'Authorization': 'Bearer ' + k})
        page = json.loads(urllib.request.urlopen(req, timeout=60).read())
        d += page
        if len(page) < 1000:
            break
    json.dump(d, open(p, 'w', encoding='utf-8'))
    return d


def places(iso, wd):
    p = os.path.join(wd, f'{iso}_places.json')
    if os.path.exists(p):
        return json.load(open(p))
    body = urllib.parse.urlencode({'data': f'[out:json][timeout:300];area["ISO3166-2"="{iso}"]->.s;node["place"]["name"](area.s);out;'}).encode()
    for h in MIRRORS * 3:
        try:
            d = get(h, data=body, timeout=400)
            pl = [(e['tags']['name'], e['lat'], e['lon']) for e in d['elements']]
            json.dump(pl, open(p, 'w'))
            return pl
        except Exception as e:  # noqa: BLE001
            print('places retry', h, e, flush=True)
    raise SystemExit('places failed')


def area(name, sub, state_name):
    a = rs.area(name, sub)
    return a.replace('a small Michigan city', f'a small {state_name} city').replace('a small Michigan community', f'a small {state_name} community')


def main():
    state, sname, abbr, wd = sys.argv[1:5]
    iso = FIPS_ISO[state]
    done = {r['city_slug'] for r in csv.DictReader(open(os.path.join(HERE, 'city_log.csv'), encoding='utf-8')) if r['state_slug'] == state}
    towns = [t for t in coords(state, wd) if t['city_slug'] not in done and t['lat'] is not None]
    src = os.path.join(wd, f'{state}_todo.json')
    json.dump(towns, open(src, 'w', encoding='utf-8'))
    out = os.path.join(wd, f'{state}_research.json')
    sys.argv = ['rb', src, iso, out]
    rb.main()
    d = json.load(open(out, encoding='utf-8'))
    pl = places(iso, wd)
    by = {t['city_slug']: t for t in towns}
    rows, ver, basic = [], [], []
    for slug, v in d.items():
        if slug not in by:
            continue
        t = by[slug]
        n = rs.norm(v['name'])
        v['osm_ok'] = any(rs.norm(nm) == n and math.hypot((la - t['lat']) * 111, (lo - t['lng']) * 82) < 3 for nm, la, lo in pl)
        if not v.get('county') or not rs.verified(v):
            basic.append(slug)
            continue
        roads = list(dict.fromkeys(rs.road(re.sub(r'(\d+)[a-z]+$', r'', r)) for r in v['roads'] if re.match(r'^(I|US|SR|[A-Z]{1,2}-?)[ -]?\d', r)))
        lms = [x for x in v['water'] + v['parks'] if rs.good(x) and '(' not in x and len(x) < 40][:3]
        in_place = any(rs.norm(p) == n for p in v.get('places') or [])
        lake = sum(1 for x in v['water'] if 'Lake' in x) >= 2
        rw = ' and '.join([', '.join(roads[:-1]), roads[-1]]) if len(roads) > 1 else (roads[0] if roads else 'local county roads')
        rows.append('(' + ','.join(q(x) for x in [slug, v['county'], ('' if in_place else area(v['name'], v.get('township'), sname)), rw, '|'.join(lms), 'L' if lake else 'H']) + ')')
        ver.append(slug)
    tpl = open(os.path.join(HERE, 'template_v3.sql'), encoding='utf-8').read().replace('{STATE}', state).replace('{ST}', abbr).replace('{STATENAME}', sname)
    for i in range(0, len(rows), 200):
        open(os.path.join(wd, f'{state}_v_{i // 200 + 1}.sql'), 'w', encoding='utf-8').write(tpl.replace('/*VALUES*/', ',\n'.join(rows[i:i + 200])))
    btpl = open(os.path.join(HERE, 'template_basic.sql'), encoding='utf-8').read().replace('{STATE}', state).replace('{ST}', abbr).replace('{STATENAME}', sname)
    open(os.path.join(wd, f'{state}_basic.sql'), 'w', encoding='utf-8').write(btpl)
    open(os.path.join(wd, f'{state}_verified.txt'), 'w').write(','.join(ver))
    open(os.path.join(wd, f'{state}_basic.txt'), 'w').write(','.join(basic))
    print(state, 'verified', len(ver), 'basic', len(basic), 'files', (len(rows) + 199) // 200)


if __name__ == '__main__':
    main()
