-- Re-roll intros (12 openings) and shuffle FAQ order for rows updated today in a state.
-- Run after each template_v2 batch. Replace 'michigan' / MI-specific wording for other states.
with s(slug,svc,items,hook) as (values
('junk-removal','junk removal','furniture, appliances, mattresses, yard debris and household clutter','Get your space back without renting a truck or waiting for bulk pickup day.'),
('couch-removal','couch removal','couches, sectionals, sleeper sofas, loveseats and recliners','Skip the struggle down the stairs and out the door. We carry it out for you.'),
('mattress-removal','mattress removal','mattresses, box springs, bed frames and headboards of every size','No more dragging a mattress to the curb or finding room for it in your car.'),
('appliance-removal','appliance removal','refrigerators, freezers, washers, dryers, stoves and water heaters','Heavy, awkward appliances out of your kitchen, laundry room or basement, without the back strain.'),
('furniture-removal','furniture removal','beds, dressers, tables, desks, bookshelves and office furniture','From one dresser to a full house of furniture, gone in one visit.')),
o(i,txt) as (values
(0,'{Svc} in {city}, MI, done for you. Junk Removals 365 hauls {items} from homes and businesses across {city}. {hook}'),
(1,'Need fast {svc} in {city}, Michigan? We remove {items} with upfront pricing and same-day pickup in most areas. {hook}'),
(2,'Book {svc} in {city}, MI in minutes. Our crews pick up {items} anywhere in town, and you never lift a thing. {hook}'),
(3,'Tired of looking at that pile? Junk Removals 365 offers {svc} in {city} for {items}. {hook}'),
(4,'{city} homeowners, renters and businesses trust Junk Removals 365 for {svc}. We take {items} and handle all the lifting. {hook}'),
(5,'Clearing out a home or office in {city}? Our {svc} crews load {items} and haul it all away in one trip. {hook}'),
(6,'Looking for {svc} near {city}, MI? We pick up {items} from any room, basement or garage. {hook}'),
(7,'Moving, downsizing or just decluttering in {city}? Let our team take care of the {svc}: {items}, gone fast. {hook}'),
(8,'Same-day {svc} is available in most of {city}. Tell us what you have, get an upfront price, and we haul away {items}. {hook}'),
(9,'Your {city} {svc} team is one booking away. We remove {items} and donate or recycle what we can. {hook}'),
(10,'Do not let old {items} take over your space. Junk Removals 365 handles {svc} across {city}, Michigan. {hook}'),
(11,'Affordable, hassle-free {svc} in {city}. Point to the {items} you want gone and our crew does the rest. {hook}'))
update city_pages cp set
  unique_intro = replace(replace(replace(replace(replace(o.txt,'{city}',cp.city_name),'{Svc}',initcap(left(s.svc,1))||substr(s.svc,2)),'{svc}',s.svc),'{items}',s.items),'{hook}',s.hook),
  faqs = (select jsonb_agg(e order by md5(cp.city_slug||cp.service_slug||(e->>'question')))::text from jsonb_array_elements(cp.faqs::jsonb) e)
from s, o
where cp.state_slug='michigan' and cp.seo_status='custom' and cp.updated_at > now() - interval '30 minutes'
  and s.slug=cp.service_slug and o.i = abs(hashtext(cp.city_slug||cp.service_slug||'v2')) % 12;
