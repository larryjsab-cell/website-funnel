"""Build city_pages UPDATE SQL for all 5 services from a facts JSON file.

Usage: python -I generate.py <facts.json> <state_slug> <state_name> <out.sql>
Writes one UPDATE per city+service and appends finished cities to city_log.csv
(the log is the record of what is done; never regenerate a city already in it).
"""
import csv
import datetime
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(HERE, 'city_log.csv')

SERVICES = {
    'junk-removal': {
        'name': 'junk removal', 'items': 'furniture, appliances, mattresses, yard debris and household clutter',
        'hook': 'Get your space back without renting a truck or waiting for bulk pickup day.',
        'includes': ['Removal from any room, basement, attic or garage', 'Furniture, appliances and mattresses', 'Yard debris and light renovation debris', 'Whole-home, estate and garage cleanouts', 'Sweep-up after loading', 'Donation and recycling of usable items'],
        'pricing': ['How much truck space your items fill', 'Heavy items such as appliances or hot tubs', 'Stairs, basements or long carries', 'Disassembly needed to get items out'],
        'faqs': [('What junk do you take in {city}?', 'Almost anything non-hazardous: furniture, appliances, mattresses, electronics, boxes, yard debris and renovation debris. Point to it and our crew loads it.'),
                 ('Do I have to move my junk to the curb?', 'No. Our crew removes items from inside your {city} home, basement, garage or business, so you never lift a thing.')],
    },
    'couch-removal': {
        'name': 'couch removal', 'items': 'couches, sectionals, sleeper sofas, loveseats and recliners',
        'hook': 'Skip the struggle down the stairs and out the door. We carry it out for you.',
        'includes': ['Couches, sofas and loveseats', 'Sectionals and sleeper sofas', 'Recliners and futons', 'Removal from any floor or basement', 'Disassembly when needed', 'Donation of couches in good condition'],
        'pricing': ['Size and number of pieces', 'Sleeper sofas and large sectionals', 'Stairs or tight doorways', 'Other items added to the same pickup'],
        'faqs': [('Can you get a sectional out of a {city} basement?', 'Yes. We separate sectional pieces and handle stairs and tight turns, which is common in {city} homes with basements.'),
                 ('What happens to my old couch?', 'Couches in good shape are donated when possible. The rest are recycled or disposed of properly.')],
    },
    'mattress-removal': {
        'name': 'mattress removal', 'items': 'mattresses, box springs, bed frames and headboards of every size',
        'hook': 'No more dragging a mattress to the curb or finding room for it in your car.',
        'includes': ['All mattress sizes, twin to California king', 'Box springs and bed frames', 'Headboards and bunk beds', 'Removal from any bedroom or floor', 'Mattress recycling where available', 'Same-day pickup in most areas'],
        'pricing': ['Number of mattresses and box springs', 'Bed frame disassembly', 'Stairs or long carries', 'Other furniture added to the pickup'],
        'faqs': [('Do you recycle mattresses in {city}?', 'Where a mattress recycler is available, we send mattresses there so foam, steel and wood are reused instead of landfilled.'),
                 ('Will you take the bed frame too?', 'Yes. We take the mattress, box spring, frame and headboard in one trip and disassemble the frame if needed.')],
    },
    'appliance-removal': {
        'name': 'appliance removal', 'items': 'refrigerators, freezers, washers, dryers, stoves, dishwashers and water heaters',
        'hook': 'Heavy, awkward appliances out of your kitchen, laundry room or basement, without the back strain.',
        'includes': ['Refrigerators and freezers', 'Washers and dryers', 'Stoves, ovens and dishwashers', 'Water heaters and dehumidifiers', 'Removal from basements and laundry rooms', 'Recycling of metal and refrigerants per regulations'],
        'pricing': ['Number and size of appliances', 'Basement or upstairs locations', 'Refrigerant-containing units', 'Disconnection needs'],
        'faqs': [('Can you take a washer and dryer out of a {city} basement?', 'Yes. Basement laundry rooms are common in {city}, and our crew carries appliances up the stairs safely.'),
                 ('Do you recycle old appliances?', 'Yes. Appliances are taken to scrap and recycling facilities, and refrigerators and freezers are handled so refrigerant is recovered properly.')],
    },
    'furniture-removal': {
        'name': 'furniture removal', 'items': 'beds, dressers, tables, desks, bookshelves, office furniture and full rooms of furniture',
        'hook': 'From one dresser to a full house of furniture, gone in one visit.',
        'includes': ['Beds, dressers and nightstands', 'Dining sets, desks and bookshelves', 'Office furniture and cubicles', 'Full-room and estate clearouts', 'Disassembly included when needed', 'Donation of usable furniture'],
        'pricing': ['Number and size of pieces', 'Full-room or whole-home volume', 'Stairs and long carries', 'Disassembly of large pieces'],
        'faqs': [('Do you remove office furniture in {city}?', 'Yes. We clear desks, chairs, cubicles and conference tables for {city} businesses of every size.'),
                 ('Can you clear a whole house of furniture?', 'Yes. Estate and whole-home furniture clearouts are done in one visit in most cases.')],
    },
}

INTROS = [
    '{Svc} in {city}, MI, done for you. Junk Removals 365 hauls {items} from homes and businesses across {city} and {county} County. {hook}',
    'Need fast {svc} in {city}, Michigan? Junk Removals 365 removes {items} with upfront pricing and same-day pickup in most areas. {hook}',
    'Book {svc} in {city}, MI in minutes. Our crews pick up {items} anywhere in {city}, and you never lift a thing. {hook}',
]

CONTEXTS = [
    '{city} is {area} in {county} County, with easy access along {roads}. We serve neighborhoods across {city}, from {lm0} to {lm1}, and nearby communities like {n0}, {n1} and {n2}. Common jobs here include {season}, and our crew works around driveways, alleys and parking so pickup is simple.',
    'From {lm0} to {lm1}, Junk Removals 365 provides {svc} throughout {city}, {area} in {county} County. Customers along {roads} book us for {season}. We also cover {n0}, {n1} and {n2}.',
]

RULES = ('Many {county} County communities limit what goes out on bulk pickup day, and some items, like appliances with refrigerant, '
         'need special handling. Check with your local {city} city or township office, or your trash hauler, for curbside rules. If you would rather not wait, '
         'Junk Removals 365 removes items from inside your property and takes them to the right donation, recycling or disposal facility. '
         'We do not take hazardous waste such as paint, chemicals or fuel.')

GENERIC_FAQS = [
    ('How much does {svc} cost in {city}?', 'Price depends on how much truck space your items take, the type of items, and access such as stairs. You get an upfront quote before any work begins, with no hidden fees.'),
    ('Do you offer same-day {svc} in {city}?', 'Same-day and next-day pickup is available in most of {city} and {county} County. Book online to see open time slots for your address.'),
    ('Which areas near {city} do you serve?', 'We serve all of {city} plus nearby communities including {n0}, {n1}, {n2} and {n3}.'),
]


def pick(options, key):
    return options[int(hashlib.md5(key.encode()).hexdigest(), 16) % len(options)]


def sql_text(s):
    return '$q$' + s + '$q$'


def build(city, state_slug, state_name, svc_slug, svc):
    city.setdefault('name', city['slug'].replace('-', ' ').title())
    n = city['nearby'] + ['nearby communities'] * 4
    v = dict(city=city['name'], county=city['county'], area=city['area'], roads=city['roads'],
             lm0=city['landmarks'][0], lm1=city['landmarks'][1], season=city['season'],
             n0=n[0], n1=n[1], n2=n[2], n3=n[3], svc=svc['name'], Svc=svc['name'].capitalize(),
             items=svc['items'], hook=svc['hook'])
    key = city['slug'] + svc_slug
    faqs = [{'question': q.format(**v), 'answer': a.format(**v)} for q, a in svc['faqs'] + GENERIC_FAQS]
    fields = {
        'unique_intro': pick(INTROS, key).format(**v),
        'city_context': pick(CONTEXTS, key + 'c').format(**v),
        'housing_type': f"{city['name']} has {city['homes']}. We handle {svc['name']} from all of them, including basements, upstairs rooms and garages.",
        'local_rules_note': RULES.format(**v),
        'service_includes': ';'.join(svc['includes']),
        'pricing_factors': ';'.join(svc['pricing']),
        'nearby_cities': '|'.join(city['nearby']),
        'landmarks': '|'.join(city['landmarks']),
        'faqs': json.dumps(faqs, ensure_ascii=False),
    }
    sets = ',\n  '.join(f'{k} = {sql_text(val)}' for k, val in fields.items())
    return (f"update city_pages set\n  {sets},\n  seo_status = 'custom', updated_at = now()\n"
            f"where state_slug = '{state_slug}' and city_slug = '{city['slug']}' and service_slug = '{svc_slug}';\n")


def main():
    facts_path, state_slug, state_name, out = sys.argv[1:5]
    cities = json.load(open(facts_path, encoding='utf-8'))
    done = set()
    if os.path.exists(LOG):
        done = {(r['state_slug'], r['city_slug']) for r in csv.DictReader(open(LOG, encoding='utf-8'))}
    todo = [c for c in cities if (state_slug, c['slug']) not in done]
    with open(out, 'w', encoding='utf-8') as f:
        for c in todo:
            for slug, svc in SERVICES.items():
                f.write(build(c, state_slug, state_name, slug, svc))
    print(f'{len(todo)} cities -> {out} (skipped {len(cities) - len(todo)} already in log)')


def log(facts_path, state_slug):
    cities = json.load(open(facts_path, encoding='utf-8'))
    for c in cities:
        c.setdefault('name', c['slug'].replace('-', ' ').title())
    new = not os.path.exists(LOG)
    done = set()
    if not new:
        done = {(r['state_slug'], r['city_slug']) for r in csv.DictReader(open(LOG, encoding='utf-8'))}
    with open(LOG, 'a', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        if new:
            w.writerow(['state_slug', 'city_slug', 'city_name', 'services', 'date', 'batch'])
        for c in cities:
            if (state_slug, c['slug']) not in done:
                w.writerow([state_slug, c['slug'], c['name'], 5, datetime.date.today().isoformat(), os.path.basename(facts_path)])


if __name__ == '__main__':
    if sys.argv[1] == '--log':
        log(sys.argv[2], sys.argv[3])
    else:
        main()
