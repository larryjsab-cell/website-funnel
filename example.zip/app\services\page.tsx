import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import SchemaMarkup from '@/components/SchemaMarkup';
import { SERVICE_LIST } from '@/lib/services';
import { ArrowRight, CircleCheck as CheckCircle } from 'lucide-react';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Junk Removal Services Nationwide | Couch, Furniture & More | Junk Removals 365',
  description: 'Couch, mattress, appliance, furniture, and junk removal services nationwide. Same-day pickup available. Licensed & insured crews. Upfront pricing.',
  alternates: { canonical: 'https://junkremovals365.com/services' },
  openGraph: {
    title: 'Junk Removal Services Nationwide | Couch, Furniture & More | Junk Removals 365',
    description: 'Couch, mattress, appliance, furniture, and junk removal services nationwide. Same-day pickup available. Licensed & insured crews. Upfront pricing.',
    url: 'https://junkremovals365.com/services',
    siteName: 'Junk Removals 365',
    type: 'website',
    images: [{ url: 'https://junkremovals365.com/image.png' }],
  },
};

const ACCEPTED_ITEMS = [
  'Couches, sofas, sectionals & recliners',
  'Mattresses & box springs (all sizes)',
  'Refrigerators, washers, dryers & other appliances',
  'Beds, dressers, desks & dining sets',
  'Office furniture & cubicles',
  'Electronics & TVs',
  'Garage, basement & attic clutter',
  'Yard waste & light renovation debris',
];

const STEPS = [
  { title: 'Get an upfront quote', description: 'Book online or request a quote. Tell us what needs to go and we give you a clear price before any work begins.' },
  { title: 'Pick a pickup window', description: 'Choose a time that suits you. Same-day and next-day pickup is available in most areas.' },
  { title: 'We do the heavy lifting', description: 'Our crew removes items from any room or floor, including stairs and tight spaces. You just point.' },
  { title: 'Donate, recycle, dispose', description: 'Usable items go to local charities, recyclable materials are recycled, and only the rest goes to the landfill.' },
];

const PREP_TIPS = [
  'Empty drawers, cabinets, and cushions of personal items.',
  'Make sure there is a clear path from the items to the door.',
  'Point out anything that must stay so it is not taken by mistake.',
  'Have someone 18+ present to approve the final price and the job.',
];

const PRICE_FACTORS = [
  'How much truck space your items fill',
  'The type of items (appliances and mattresses can have disposal fees)',
  'Stairs, long carries, or tight access',
  'Whether disassembly is needed',
];

const SERVICES_FAQS = [
  { question: 'What junk removal services do you offer?', answer: 'We offer full service junk removal, couch removal, mattress removal, appliance removal, and furniture removal for homes and businesses nationwide, from single items to full cleanouts.' },
  { question: 'How much do your removal services cost?', answer: 'Pricing depends on volume, item type, and access. Single items such as a couch start at $79, and most full service junk removal jobs range from $99 to $600+. You always get an upfront price before we start.' },
  { question: 'Do I need to sort or bag anything?', answer: 'No. We take mixed loads as they are. Our crew loads everything and separates donatable and recyclable items afterward.' },
  { question: 'What items can you not take?', answer: 'We cannot take hazardous materials such as paint, solvents, pesticides, asbestos, motor oil, or medical waste. Most other household and business items are accepted.' },
];

const accentColors: Record<string, string> = {
  green: 'bg-green-600',
  blue: 'bg-blue-600',
  orange: 'bg-orange-600',
  teal: 'bg-teal-600',
  red: 'bg-red-600',
};

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-white">
      <SchemaMarkup type="faq" id="faq-services" data={{ faqs: SERVICES_FAQS }} />
      <Header />

      <main>
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-16">
            <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Junk Removal <span className="text-green-600">Services</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From a single couch to a full estate cleanout — we remove it all. Licensed, insured, and available same-day across 19,000+ cities.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICE_LIST.map((service) => {
              const bgClass = accentColors[service.accentColor] ?? 'bg-green-600';
              return (
                <Link
                  key={service.slug}
                  href={`/services/${service.slug}`}
                  className="group block bg-white rounded-2xl shadow-md hover:shadow-xl border border-gray-100 overflow-hidden transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={service.heroImage}
                      alt={service.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/30" />
                    <div className={`absolute top-4 left-4 ${bgClass} text-white text-sm font-bold px-3 py-1 rounded-full`}>
                      {service.name}
                    </div>
                  </div>

                  <div className="p-6">
                    <h2 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-green-600 transition-colors">
                      {service.headline}
                    </h2>
                    <p className="text-gray-600 text-sm leading-relaxed mb-4">
                      {service.subheadline}
                    </p>

                    <ul className="space-y-1 mb-6">
                      {service.features.slice(0, 3).map((f, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm text-gray-700">
                          <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>

                    <div className={`inline-flex items-center gap-2 ${bgClass} text-white font-bold px-5 py-2.5 rounded-lg text-sm group-hover:opacity-90 transition-opacity`}>
                      Learn More
                      <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Junk Removal Services for Homes and Businesses</h2>
          <p className="text-lg text-gray-700 leading-relaxed mb-4">
            Junk Removals 365 is a nationwide junk removal service. We haul away the items you no longer want, from a
            single old couch to a full garage, basement, office, or estate cleanout. Our crews do all the lifting and
            loading, and we donate or recycle as much as we can.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed">
            Need help with one type of item? See our{' '}
            <Link href="/services/couch-removal" className="text-green-700 font-semibold underline">couch removal</Link>,{' '}
            <Link href="/services/mattress-removal" className="text-green-700 font-semibold underline">mattress removal</Link>,{' '}
            <Link href="/services/appliance-removal" className="text-green-700 font-semibold underline">appliance removal</Link>, and{' '}
            <Link href="/services/furniture-removal" className="text-green-700 font-semibold underline">furniture removal</Link>{' '}
            pages, or our full <Link href="/services/junk-removal" className="text-green-700 font-semibold underline">junk removal service</Link>{' '}
            for mixed loads.
          </p>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-5xl grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">What We Remove</h2>
            <ul className="space-y-2">
              {ACCEPTED_ITEMS.map((item) => (
                <li key={item} className="flex items-start gap-2 text-gray-700">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">How Collection Works</h2>
            <ol className="space-y-4">
              {STEPS.map((step, i) => (
                <li key={step.title}>
                  <p className="font-bold text-gray-900">{i + 1}. {step.title}</p>
                  <p className="text-gray-700">{step.description}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-5xl grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">How to Prepare for Pickup</h2>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              {PREP_TIPS.map((tip) => <li key={tip}>{tip}</li>)}
            </ul>
          </div>
          <div>
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">What Affects the Price</h2>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              {PRICE_FACTORS.map((f) => <li key={f}>{f}</li>)}
            </ul>
            <p className="text-gray-700 mt-4">
              You get an upfront quote before any work begins, with no hidden fees.{' '}
              <Link href="/book" className="text-green-700 font-semibold underline">Request a quote</Link>.
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-6">Removal Services FAQs</h2>
          <div className="space-y-6">
            {SERVICES_FAQS.map((faq) => (
              <div key={faq.question}>
                <h3 className="text-lg font-bold text-gray-900 mb-1">{faq.question}</h3>
                <p className="text-gray-700">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Ready to Clear It Out?</h2>
          <p className="text-xl text-gray-300 mb-8">Same-day service available. Book online in 60 seconds.</p>
          <Link
            href="/book"
            className="inline-flex items-center justify-center bg-green-600 text-white px-10 py-4 rounded-lg font-bold hover:bg-green-700 transition-colors text-lg shadow-lg"
          >
            Book Now — Get an Instant Quote
          </Link>
        </div>
      </section>

      </main>
      <Footer />
    </div>
  );
}
