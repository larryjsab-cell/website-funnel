import { sitemapNames, sitemapXml } from '@/lib/sitemaps';

export const revalidate = 86400;
export const dynamicParams = false;

export function generateStaticParams() {
  return sitemapNames().map((name) => ({ name: `${name}.xml` }));
}

export async function GET(_req: Request, { params }: { params: { name: string } }) {
  const xml = await sitemapXml(params.name.replace(/\.xml$/, ''));
  if (!xml) return new Response('Not found', { status: 404 });
  return new Response(xml, { headers: { 'Content-Type': 'application/xml' } });
}
