import Link from 'next/link';
import { Search, CircleCheck as CheckCircle, Calendar } from 'lucide-react';

interface HowItWorksProps {
  serviceName?: string;
}

const steps = (serviceName: string) => [
  {
    number: '01',
    title: 'Book Your Appointment Online',
    description: `Schedule your ${serviceName.toLowerCase()} service online at your convenience. Quick and easy booking process.`,
    icon: Search,
    color: 'bg-green-600',
    iconColor: 'text-white',
    backColor: 'bg-green-700',
  },
  {
    number: '02',
    title: 'Sit Back and Relax',
    description: 'Once booked, you can relax while we handle all the details and prepare for your service.',
    icon: CheckCircle,
    color: 'bg-yellow-600',
    iconColor: 'text-white',
    backColor: 'bg-amber-700',
  },
  {
    number: '03',
    title: 'We Haul It All Away',
    description: `Our team arrives on time, loads everything up, and hauls it away — furniture, appliances, mattresses, and more. Clean and done.`,
    icon: Calendar,
    color: 'bg-blue-600',
    iconColor: 'text-white',
    backColor: 'bg-blue-700',
  },
];

export default function HowItWorks({ serviceName = 'Junk Removal' }: HowItWorksProps) {
  const cards = steps(serviceName);

  return (
    <div className="bg-white py-8 sm:py-12 lg:py-16 overflow-hidden">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-12 lg:mb-16 w-full animate-fade-in-up">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-800 leading-tight mb-2 sm:mb-3 lg:mb-4 px-2 sm:px-4 break-words">
            How It Works — 3 Easy Steps
          </h2>

          <div className="flex items-center justify-center mb-3 sm:mb-4 lg:mb-6 w-full">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="w-4 sm:w-6 lg:w-8 h-0.5 bg-green-700"></div>
              <span className="text-green-700 font-semibold text-xs sm:text-sm tracking-widest uppercase whitespace-nowrap">
                HOW IT WORKS
              </span>
              <div className="w-4 sm:w-6 lg:w-8 h-0.5 bg-green-700"></div>
            </div>
          </div>

          <h3 className="text-base sm:text-lg md:text-xl lg:text-2xl text-gray-600 font-medium px-2 sm:px-4">
            Book online &bull; We show up &bull; Your junk is gone
          </h3>

          <div className="mt-8">
            <Link
              href="/how-it-works"
              className="inline-flex items-center space-x-2 bg-blue-700 text-white px-6 py-3 rounded-full font-semibold hover:bg-blue-800 transition-colors duration-200"
            >
              <span>LEARN MORE DETAILS</span>
              <Search className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
        </div>

        <div className="w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {cards.map((step) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.number}
                  className="relative w-full h-64 sm:h-72 lg:h-80 group [perspective:1000px]"
                >
                  <div className="relative w-full h-full transition-transform duration-700 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
                    {/* Back (duplicate of front, decorative) */}
                    <div aria-hidden="true" className={`absolute inset-0 w-full h-full [backface-visibility:hidden] [transform:rotateY(180deg)] rounded-xl sm:rounded-2xl lg:rounded-3xl p-4 sm:p-6 lg:p-8 text-center shadow-lg ${step.backColor}`}>
                      <div className="absolute top-2 sm:top-4 lg:top-6 left-2 sm:left-4 lg:left-6 text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-white/20 leading-none select-none before:content-[attr(data-n)]" data-n={step.number} aria-hidden="true" />
                      <div className="bg-white/20 w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 xl:w-20 xl:h-20 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 lg:mb-8 relative z-10 shadow-lg backdrop-blur-sm">
                        <Icon className="h-5 w-5 sm:h-6 sm:w-6 lg:h-7 lg:w-7 xl:h-8 xl:w-8 text-white" aria-hidden="true" />
                      </div>
                      <div className="relative z-10 w-full">
                        <h4 className="text-sm sm:text-base md:text-lg lg:text-xl xl:text-2xl font-bold text-white mb-2 sm:mb-3 lg:mb-4 leading-tight break-words px-1">
                          {step.title}
                        </h4>
                        <p className="text-xs sm:text-sm md:text-base text-white leading-relaxed break-words px-1">
                          {step.description}
                        </p>
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20"></div>
                    </div>

                    {/* Front */}
                    <div className="absolute inset-0 w-full h-full [backface-visibility:hidden] bg-white border border-gray-200 rounded-xl sm:rounded-2xl lg:rounded-3xl p-4 sm:p-6 lg:p-8 text-center shadow-lg">
                      <div className="absolute top-2 sm:top-4 lg:top-6 left-2 sm:left-4 lg:left-6 text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-gray-100 leading-none select-none before:content-[attr(data-n)]" data-n={step.number} aria-hidden="true" />
                      <div className={`${step.color} w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 xl:w-20 xl:h-20 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 lg:mb-8 relative z-10 shadow-lg`}>
                        <Icon className={`h-5 w-5 sm:h-6 sm:w-6 lg:h-7 lg:w-7 xl:h-8 xl:w-8 ${step.iconColor}`} aria-hidden="true" />
                      </div>
                      <div className="relative z-10 w-full">
                        <h4 className="text-sm sm:text-base md:text-lg lg:text-xl xl:text-2xl font-bold text-gray-800 mb-2 sm:mb-3 lg:mb-4 leading-tight break-words px-1">
                          {step.title}
                        </h4>
                        <p className="text-xs sm:text-sm md:text-base text-gray-600 leading-relaxed break-words px-1">
                          {step.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
